"use client";

import { useState } from "react";
import { useFormStatus } from "react-dom";
import { addToCart } from "@/app/actions/cart";
import styles from "./add-to-cart.module.css";

type Props = { slug: string; stock: number };

function SubmitButton() {
  const { pending } = useFormStatus();
  return (
    <button className={styles.add} type="submit" disabled={pending}>
      {pending ? "Đang thêm..." : "Thêm vào giỏ"}
    </button>
  );
}

export default function AddToCart({ slug, stock }: Props) {
  const [quantity, setQuantity] = useState(1);

  if (stock === 0) {
    return <p className={styles.soldOut}>Hết hàng</p>;
  }

  return (
    <form action={addToCart} className={styles.box}>
      <input type="hidden" name="slug" value={slug} />
      <input type="hidden" name="quantity" value={quantity} />
      <div className={styles.picker}>
        <button type="button" onClick={() => setQuantity(Math.max(1, quantity - 1))} aria-label="Giảm">−</button>
        <span>{quantity}</span>
        <button type="button" onClick={() => setQuantity(Math.min(stock, quantity + 1))} aria-label="Tăng">+</button>
      </div>
      <SubmitButton />
    </form>
  );
}
