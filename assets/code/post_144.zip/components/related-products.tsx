import ProductCard from "@/components/product-card";
import { getRelatedProducts, type Product } from "@/lib/products";

export default async function RelatedProducts({ product }: { product: Product }) {
  const related = await getRelatedProducts(product);

  if (related.length === 0) return null;

  return (
    <section style={{ marginTop: 64 }}>
      <h2 style={{ fontSize: "1.25rem", fontWeight: 800, marginBottom: 16 }}>Sản phẩm cùng loại</h2>
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fill, minmax(220px, 1fr))", gap: 20 }}>
        {related.map((p) => (
          <ProductCard key={p.slug} product={p} />
        ))}
      </div>
    </section>
  );
}
