"use client";

import { useActionState } from "react";
import { placeOrder, type CheckoutState } from "@/app/actions/order";
import styles from "./checkout-form.module.css";

const initialState: CheckoutState = {};

export default function CheckoutForm() {
  const [state, formAction, pending] = useActionState(placeOrder, initialState);
  const values = state.values ?? {};

  return (
    <form action={formAction} className={styles.form} noValidate>
      {state.message && <p className={styles.alert}>{state.message}</p>}

      <label className={styles.field}>
        Họ tên
        <input name="customerName" defaultValue={values.customerName} aria-invalid={!!state.errors?.customerName} />
        {state.errors?.customerName && <span className={styles.error}>{state.errors.customerName}</span>}
      </label>

      <label className={styles.field}>
        Số điện thoại
        <input name="phone" type="tel" defaultValue={values.phone} aria-invalid={!!state.errors?.phone} />
        {state.errors?.phone && <span className={styles.error}>{state.errors.phone}</span>}
      </label>

      <label className={styles.field}>
        Địa chỉ giao hàng
        <input name="address" defaultValue={values.address} aria-invalid={!!state.errors?.address} />
        {state.errors?.address && <span className={styles.error}>{state.errors.address}</span>}
      </label>

      <label className={styles.field}>
        Ghi chú (không bắt buộc)
        <textarea name="note" rows={3} defaultValue={values.note} />
      </label>

      <button className={styles.submit} type="submit" disabled={pending}>
        {pending ? "Đang đặt hàng..." : "Xác nhận đặt hàng"}
      </button>
    </form>
  );
}
