import Link from "next/link";
import { formatPrice, type Product } from "@/lib/products";
import styles from "./product-card.module.css";

export default function ProductCard({ product }: { product: Product }) {
  return (
    <Link href={`/products/${product.slug}`} className={styles.card}>
      <div className={styles.media}>
        {product.oldPrice && <span className={styles.badge}>Giảm giá</span>}
        <span className={styles.emoji}>{product.emoji}</span>
      </div>
      <div className={styles.body}>
        <p className={styles.brand}>{product.brand}</p>
        <h2 className={styles.name}>{product.name}</h2>
        <p className={styles.price}>
          {formatPrice(product.price)}
          {product.oldPrice && <s className={styles.old}>{formatPrice(product.oldPrice)}</s>}
        </p>
      </div>
    </Link>
  );
}
