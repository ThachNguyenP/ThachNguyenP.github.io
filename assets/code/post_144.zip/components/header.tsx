import Link from "next/link";
import NavLinks from "./nav-links";
import styles from "./header.module.css";

export default function Header() {
  console.log("Header render ở server");

  return (
    <header className={styles.header}>
      <div className={`container ${styles.inner}`}>
        <Link href="/" className={styles.logo}>TechShop</Link>
        <NavLinks />
      </div>
    </header>
  );
}
