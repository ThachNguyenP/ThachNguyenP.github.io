import Link from "next/link";

export default function NotFound() {
  return (
    <main className="container" style={{ padding: "96px 24px", textAlign: "center" }}>
      <h1 style={{ fontSize: "3rem" }}>404</h1>
      <p style={{ marginTop: 8 }}>Không tìm thấy trang hoặc sản phẩm này.</p>
      <Link href="/" style={{ color: "var(--color-primary)", fontWeight: 600, display: "inline-block", marginTop: 16 }}>Về trang chủ</Link>
    </main>
  );
}
