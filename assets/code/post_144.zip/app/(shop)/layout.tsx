import Header from "@/components/header";

export default function ShopLayout({ children }: { children: React.ReactNode }) {
  return (
    <>
      <Header />
      <main className="container" style={{ paddingTop: 32, paddingBottom: 64 }}>
        {children}
      </main>
      <footer className="container" style={{ padding: 24, color: "var(--color-muted)", fontSize: 14 }}>
        © 2026 TechShop
      </footer>
    </>
  );
}
