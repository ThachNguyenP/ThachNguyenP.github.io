"use client";

export default function ProductsError({ error, reset }: { error: Error; reset: () => void }) {
  return (
    <div style={{ padding: 48, textAlign: "center" }}>
      <h2>Không tải được danh sách sản phẩm</h2>
      <p style={{ color: "var(--color-muted)", margin: "8px 0 16px" }}>{error.message}</p>
      <button onClick={reset} style={{ padding: "10px 20px", borderRadius: 10, border: 0, background: "var(--color-primary)", color: "#fff", cursor: "pointer" }}>
        Thử lại
      </button>
    </div>
  );
}
