import styles from "./loading.module.css";

export default function Loading() {
  return (
    <>
      <div className={`${styles.bar} ${styles.skeleton}`} />
      <div className={styles.grid}>
        {Array.from({ length: 8 }).map((_, i) => (
          <div key={i} className={`${styles.card} ${styles.skeleton}`} />
        ))}
      </div>
    </>
  );
}
