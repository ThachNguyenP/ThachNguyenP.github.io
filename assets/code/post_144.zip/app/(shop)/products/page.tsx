import ProductCard from "@/components/product-card";
import { getProducts } from "@/lib/products";
import styles from "./page.module.css";

export default async function ProductsPage({ searchParams }: { searchParams: Promise<{ q?: string }> }) {
  const { q } = await searchParams;
  const products = await getProducts(q);

  return (
    <>
      <form className={styles.search}>
        <input name="q" type="search" defaultValue={q} placeholder="Tìm theo tên hoặc hãng..." />
        <button type="submit">Tìm</button>
      </form>

      <h1 className={styles.title}>
        {q ? `Kết quả cho "${q}"` : "Tất cả sản phẩm"} ({products.length})
      </h1>

      {products.length === 0 ? (
        <p>Không có sản phẩm nào khớp.</p>
      ) : (
        <div className={styles.grid}>
          {products.map((product) => (
            <ProductCard key={product.slug} product={product} />
          ))}
        </div>
      )}
    </>
  );
}
