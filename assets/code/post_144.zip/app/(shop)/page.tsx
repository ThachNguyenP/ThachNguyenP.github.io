import Link from "next/link";
import ProductCard from "@/components/product-card";
import { getProducts } from "@/lib/products";
import styles from "./page.module.css";

// Trang tĩnh nhưng tự làm mới tối đa mỗi 60 giây (ISR)
export const revalidate = 60;

export default async function HomePage() {
  const products = await getProducts();
  const featured = products.filter((p) => p.oldPrice).slice(0, 3);

  return (
    <>
      <section className={styles.hero}>
        <h1 className={styles.title}>Phụ kiện công nghệ, giao trong ngày</h1>
        <p className={styles.text}>Chính hãng, bảo hành 24 tháng, đổi trả 7 ngày.</p>
        <Link href="/products" className={styles.cta}>Xem tất cả sản phẩm</Link>
      </section>

      <h2 className={styles.heading}>Đang giảm giá</h2>
      <div className={styles.grid}>
        {featured.map((product) => (
          <ProductCard key={product.slug} product={product} />
        ))}
      </div>
    </>
  );
}
