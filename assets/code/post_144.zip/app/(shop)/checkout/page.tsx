import { redirect } from "next/navigation";
import CheckoutForm from "@/components/checkout-form";
import { getCartItems } from "@/lib/cart";
import { formatPrice } from "@/lib/products";
import styles from "./page.module.css";

export default async function CheckoutPage() {
  const items = await getCartItems();
  if (items.length === 0) redirect("/cart");

  const total = items.reduce((sum, i) => sum + i.product.price * i.quantity, 0);

  return (
    <div className={styles.layout}>
      <section>
        <h1 className={styles.title}>Thông tin giao hàng</h1>
        <CheckoutForm />
      </section>

      <aside className={styles.summary}>
        <h2 className={styles.summaryTitle}>Đơn hàng</h2>
        <ul className={styles.items}>
          {items.map(({ product, quantity }) => (
            <li key={product.slug} className={styles.item}>
              <span>{product.emoji} {product.name} × {quantity}</span>
              <span>{formatPrice(product.price * quantity)}</span>
            </li>
          ))}
        </ul>
        <p className={styles.total}>Tổng cộng <strong>{formatPrice(total)}</strong></p>
      </aside>
    </div>
  );
}
