export default function AboutPage() {
  return (
    <>
      <h1>Về chúng tôi</h1>
      <p style={{ marginTop: 12, maxWidth: 600 }}>
        TechShop bán phụ kiện công nghệ chính hãng từ 2026. Trang này là một trang tĩnh: không có dữ liệu động, Next.js sẽ tạo sẵn HTML lúc build.
      </p>
    </>
  );
}
