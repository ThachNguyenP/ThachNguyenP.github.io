import Link from "next/link";
import { removeFromCart, updateQuantity } from "@/app/actions/cart";
import { getCartItems } from "@/lib/cart";
import { formatPrice } from "@/lib/products";
import styles from "./page.module.css";

export default async function CartPage() {
  const items = await getCartItems();
  const total = items.reduce((sum, item) => sum + item.product.price * item.quantity, 0);

  if (items.length === 0) {
    return (
      <div className={styles.empty}>
        <p>Giỏ hàng trống.</p>
        <Link href="/products" className={styles.link}>Xem sản phẩm</Link>
      </div>
    );
  }

  return (
    <>
      <h1 className={styles.title}>Giỏ hàng ({items.length} sản phẩm)</h1>

      <ul className={styles.list}>
        {items.map(({ product, quantity }) => (
          <li key={product.slug} className={styles.item}>
            <span className={styles.emoji}>{product.emoji}</span>
            <div className={styles.info}>
              <Link href={`/products/${product.slug}`} className={styles.name}>{product.name}</Link>
              <p className={styles.price}>{formatPrice(product.price)}</p>
            </div>

            <form action={updateQuantity} className={styles.qty}>
              <input type="hidden" name="slug" value={product.slug} />
              <input type="number" name="quantity" defaultValue={quantity} min={0} max={product.stock} />
              <button type="submit">Cập nhật</button>
            </form>

            <p className={styles.subtotal}>{formatPrice(product.price * quantity)}</p>

            <form action={removeFromCart}>
              <input type="hidden" name="slug" value={product.slug} />
              <button type="submit" className={styles.remove} aria-label="Xóa">✕</button>
            </form>
          </li>
        ))}
      </ul>

      <div className={styles.summary}>
        <p>Tổng cộng: <strong>{formatPrice(total)}</strong></p>
        <Link href="/checkout" className={styles.checkout}>Đặt hàng</Link>
      </div>
    </>
  );
}
