// app/actions/cart.ts
"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { readCart, writeCart } from "@/lib/cart";

export async function addToCart(formData: FormData) {
  const slug = String(formData.get("slug"));
  const quantity = Math.max(1, Number(formData.get("quantity")) || 1);

  const cart = await readCart();
  cart[slug] = (cart[slug] ?? 0) + quantity;
  await writeCart(cart);

  redirect("/cart");
}

export async function updateQuantity(formData: FormData) {
  const slug = String(formData.get("slug"));
  const quantity = Number(formData.get("quantity"));

  const cart = await readCart();
  if (quantity > 0) cart[slug] = quantity;
  else delete cart[slug];
  await writeCart(cart);

  revalidatePath("/cart");
}

export async function removeFromCart(formData: FormData) {
  const slug = String(formData.get("slug"));

  const cart = await readCart();
  delete cart[slug];
  await writeCart(cart);

  revalidatePath("/cart");
}
