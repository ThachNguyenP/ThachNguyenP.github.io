// lib/validation.ts
import { z } from "zod";

export const checkoutSchema = z.object({
  customerName: z.string().trim().min(2, "Tên cần ít nhất 2 ký tự"),
  phone: z.string().trim().regex(/^0\d{9}$/, "Số điện thoại gồm 10 số, bắt đầu bằng 0"),
  address: z.string().trim().min(10, "Địa chỉ cần ít nhất 10 ký tự"),
  note: z.string().trim().max(500, "Ghi chú tối đa 500 ký tự").optional(),
});

export type CheckoutInput = z.infer<typeof checkoutSchema>;
