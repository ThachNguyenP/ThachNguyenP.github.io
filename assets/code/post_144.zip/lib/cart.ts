// lib/cart.ts
import { cookies } from "next/headers";
import { prisma } from "./db";

export type Cart = Record<string, number>; // { "galaxy-s24": 2, "flip-7": 1 }

const COOKIE_NAME = "cart";

export async function readCart(): Promise<Cart> {
  const store = await cookies();
  const raw = store.get(COOKIE_NAME)?.value;
  if (!raw) return {};
  try {
    return JSON.parse(raw);
  } catch {
    return {};
  }
}

// Chỉ gọi được từ Server Action hoặc Route Handler (nơi được phép ghi cookie)
export async function writeCart(cart: Cart) {
  const store = await cookies();
  store.set(COOKIE_NAME, JSON.stringify(cart), {
    httpOnly: true,
    path: "/",
    maxAge: 60 * 60 * 24 * 7, // 7 ngày
  });
}

export async function getCartItems() {
  const cart = await readCart();
  const slugs = Object.keys(cart);
  if (slugs.length === 0) return [];

  const products = await prisma.product.findMany({ where: { slug: { in: slugs } } });
  return products.map((product) => ({ product, quantity: cart[product.slug] }));
}
