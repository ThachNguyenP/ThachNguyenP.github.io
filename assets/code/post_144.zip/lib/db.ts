// lib/db.ts
import { PrismaClient } from "@prisma/client";

// Ở development, Next.js tải lại module liên tục; nếu mỗi lần tạo PrismaClient mới
// sẽ mở quá nhiều kết nối. Giữ một instance duy nhất trên biến global.
const globalForPrisma = globalThis as unknown as { prisma?: PrismaClient };

export const prisma = globalForPrisma.prisma ?? new PrismaClient();

if (process.env.NODE_ENV !== "production") globalForPrisma.prisma = prisma;
