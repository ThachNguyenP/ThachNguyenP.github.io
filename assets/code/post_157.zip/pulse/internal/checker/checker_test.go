package checker

import (
	"context"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"
)

// newFakeServer dựng một web server trong bộ nhớ, chỉ sống trong lúc test.
func newFakeServer(t *testing.T) *httptest.Server {
	t.Helper()
	mux := http.NewServeMux()
	mux.HandleFunc("/ok", func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("ok"))
	})
	mux.HandleFunc("/error", func(w http.ResponseWriter, r *http.Request) {
		http.Error(w, "boom", http.StatusInternalServerError)
	})
	mux.HandleFunc("/slow", func(w http.ResponseWriter, r *http.Request) {
		time.Sleep(200 * time.Millisecond)
	})
	srv := httptest.NewServer(mux)
	t.Cleanup(srv.Close)
	return srv
}

func TestCheck(t *testing.T) {
	srv := newFakeServer(t)
	c := New(100 * time.Millisecond)

	tests := []struct {
		name       string
		url        string
		wantStatus Status
		wantCode   int
	}{
		{"trang ok", srv.URL + "/ok", StatusUp, 200},
		{"server lỗi 500", srv.URL + "/error", StatusDown, 500},
		{"quá chậm", srv.URL + "/slow", StatusDown, 0},
		{"không kết nối được", "http://127.0.0.1:1", StatusDown, 0},
		{"url sai", "::không phải url", StatusDown, 0},
	}

	for _, tt := range tests {
		t.Run(tt.name, func(t *testing.T) {
			got := c.Check(context.Background(), tt.url)
			if got.Status != tt.wantStatus {
				t.Errorf("Status = %q, muốn %q (error: %s)", got.Status, tt.wantStatus, got.Error)
			}
			if got.StatusCode != tt.wantCode {
				t.Errorf("StatusCode = %d, muốn %d", got.StatusCode, tt.wantCode)
			}
			if got.Status == StatusDown && got.Error == "" {
				t.Error("down thì phải có Error")
			}
		})
	}
}

func TestCheckAll(t *testing.T) {
	srv := newFakeServer(t)
	c := New(time.Second)

	urls := []string{srv.URL + "/ok", srv.URL + "/error", srv.URL + "/ok"}
	results := c.CheckAll(context.Background(), urls, 2)

	if len(results) != 3 {
		t.Fatalf("có %d kết quả, muốn 3", len(results))
	}
	for i, r := range results {
		if r.URL != urls[i] {
			t.Errorf("kết quả %d là %s, muốn %s (sai thứ tự)", i, r.URL, urls[i])
		}
	}
	if results[1].Status != StatusDown {
		t.Errorf("/error phải down")
	}
}

func TestCheckAllCancel(t *testing.T) {
	srv := newFakeServer(t)
	c := New(time.Second)

	ctx, cancel := context.WithCancel(context.Background())
	cancel() // hủy ngay từ đầu, giống bấm Ctrl+C trước khi chạy

	results := c.CheckAll(ctx, []string{srv.URL + "/ok", srv.URL + "/ok"}, 1)
	for _, r := range results {
		if r.Status != StatusDown {
			t.Errorf("%s phải down vì đã hủy, nhận %s", r.URL, r.Status)
		}
	}
}
