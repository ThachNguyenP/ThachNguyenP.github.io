// Package api là HTTP API của pulsed.
package api

import (
	"net/http"

	"github.com/thachnguyenp/pulse/internal/auth"
	"github.com/thachnguyenp/pulse/internal/checker"
	"github.com/thachnguyenp/pulse/internal/monitor"
	"github.com/thachnguyenp/pulse/internal/user"
)

// Server gom mọi thứ handler cần: store, checker, bộ ký token...
type Server struct {
	monitors monitor.Store
	users    user.Store
	checker  *checker.Checker
	tokens   *auth.Tokens
}

// New tạo Server với các phụ thuộc được truyền vào.
func New(monitors monitor.Store, users user.Store, checker *checker.Checker, tokens *auth.Tokens) *Server {
	return &Server{monitors: monitors, users: users, checker: checker, tokens: tokens}
}

// Handler trả về http.Handler với toàn bộ route và middleware.
func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()

	mux.HandleFunc("GET /healthz", s.healthz)
	mux.HandleFunc("POST /auth/register", s.register)
	mux.HandleFunc("POST /auth/login", s.login)

	// Các route dưới đây bắt buộc đăng nhập.
	protected := func(pattern string, h http.HandlerFunc) {
		mux.Handle(pattern, s.requireAuth(h))
	}
	protected("GET /me", s.me)
	protected("GET /monitors", s.listMonitors)
	protected("POST /monitors", s.createMonitor)
	protected("GET /monitors/{id}", s.getMonitor)
	protected("DELETE /monitors/{id}", s.deleteMonitor)
	protected("POST /monitors/{id}/check", s.checkMonitor)
	protected("GET /monitors/{id}/checks", s.listChecks)
	protected("GET /monitors/{id}/stats", s.monitorStats)

	return recoverPanic(logging(mux))
}

func (s *Server) healthz(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}
