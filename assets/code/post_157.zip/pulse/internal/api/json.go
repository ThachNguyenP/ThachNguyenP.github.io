package api

import (
	"encoding/json"
	"errors"
	"fmt"
	"io"
	"net/http"
)

// writeJSON trả về JSON với mã HTTP cho trước.
func writeJSON(w http.ResponseWriter, status int, v any) {
	w.Header().Set("Content-Type", "application/json")
	w.WriteHeader(status)
	json.NewEncoder(w).Encode(v)
}

// writeError trả về lỗi dạng {"error": "..."} để client nào cũng đọc giống nhau.
func writeError(w http.ResponseWriter, status int, msg string) {
	writeJSON(w, status, map[string]string{"error": msg})
}

// writeValidation trả về 422 kèm lỗi của từng trường.
func writeValidation(w http.ResponseWriter, problems map[string]string) {
	writeJSON(w, http.StatusUnprocessableEntity, map[string]any{
		"error":  "dữ liệu không hợp lệ",
		"fields": problems,
	})
}

// readJSON đọc body JSON vào v. Giới hạn 1MB và không cho phép trường lạ.
func readJSON(r *http.Request, v any) error {
	dec := json.NewDecoder(io.LimitReader(r.Body, 1<<20))
	dec.DisallowUnknownFields()
	if err := dec.Decode(v); err != nil {
		var syntaxErr *json.SyntaxError
		switch {
		case errors.As(err, &syntaxErr):
			return fmt.Errorf("JSON sai cú pháp ở vị trí %d", syntaxErr.Offset)
		case errors.Is(err, io.EOF):
			return errors.New("body trống")
		default:
			return fmt.Errorf("JSON không đúng: %v", err)
		}
	}
	return nil
}
