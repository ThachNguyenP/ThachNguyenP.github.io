package api

import (
	"errors"
	"net/http"
	"strconv"
	"time"

	"github.com/thachnguyenp/pulse/internal/auth"
	"github.com/thachnguyenp/pulse/internal/monitor"
)

func (s *Server) listMonitors(w http.ResponseWriter, r *http.Request) {
	userID, _ := auth.UserID(r.Context())
	list, err := s.monitors.List(r.Context(), userID)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "không lấy được danh sách")
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) createMonitor(w http.ResponseWriter, r *http.Request) {
	var m monitor.Monitor
	if err := readJSON(r, &m); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	if problems := m.Validate(); len(problems) > 0 {
		writeValidation(w, problems)
		return
	}
	m.UserID, _ = auth.UserID(r.Context())
	if err := s.monitors.Create(r.Context(), &m); err != nil {
		writeError(w, http.StatusInternalServerError, "không lưu được")
		return
	}
	writeJSON(w, http.StatusCreated, m)
}

func (s *Server) getMonitor(w http.ResponseWriter, r *http.Request) {
	m, ok := s.findMonitor(w, r)
	if !ok {
		return
	}
	writeJSON(w, http.StatusOK, m)
}

func (s *Server) deleteMonitor(w http.ResponseWriter, r *http.Request) {
	m, ok := s.findMonitor(w, r)
	if !ok {
		return
	}
	if err := s.monitors.Delete(r.Context(), m.UserID, m.ID); err != nil {
		writeError(w, http.StatusInternalServerError, "không xóa được")
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// checkMonitor kiểm tra ngay lập tức, không chờ lịch, và lưu kết quả như bình thường.
func (s *Server) checkMonitor(w http.ResponseWriter, r *http.Request) {
	m, ok := s.findMonitor(w, r)
	if !ok {
		return
	}
	result := s.checker.Check(r.Context(), m.URL)
	c := monitor.CheckFromResult(m.ID, result)
	if err := s.monitors.SaveCheck(r.Context(), &c); err != nil {
		writeError(w, http.StatusInternalServerError, "không lưu được kết quả")
		return
	}
	writeJSON(w, http.StatusOK, c)
}

// listChecks trả về các lần kiểm tra gần nhất, mới nhất trước. ?limit=20 (tối đa 500).
func (s *Server) listChecks(w http.ResponseWriter, r *http.Request) {
	m, ok := s.findMonitor(w, r)
	if !ok {
		return
	}
	limit := 20
	if v, err := strconv.Atoi(r.URL.Query().Get("limit")); err == nil && v > 0 && v <= 500 {
		limit = v
	}
	checks, err := s.monitors.ListChecks(r.Context(), m.ID, limit)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "lỗi đọc dữ liệu")
		return
	}
	writeJSON(w, http.StatusOK, checks)
}

// monitorStats trả về uptime và độ trễ trung bình 24 giờ qua.
func (s *Server) monitorStats(w http.ResponseWriter, r *http.Request) {
	m, ok := s.findMonitor(w, r)
	if !ok {
		return
	}
	stats, err := s.monitors.Stats(r.Context(), m.ID, time.Now().Add(-24*time.Hour))
	if err != nil {
		writeError(w, http.StatusInternalServerError, "lỗi đọc dữ liệu")
		return
	}
	writeJSON(w, http.StatusOK, stats)
}

// findMonitor đọc {id} trên URL và tìm monitor. Tự trả lỗi 400/404 nếu cần.
func (s *Server) findMonitor(w http.ResponseWriter, r *http.Request) (monitor.Monitor, bool) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		writeError(w, http.StatusBadRequest, "id phải là số")
		return monitor.Monitor{}, false
	}
	userID, _ := auth.UserID(r.Context())
	m, err := s.monitors.Get(r.Context(), userID, id)
	if errors.Is(err, monitor.ErrNotFound) {
		writeError(w, http.StatusNotFound, "không có monitor này")
		return monitor.Monitor{}, false
	}
	if err != nil {
		writeError(w, http.StatusInternalServerError, "lỗi đọc dữ liệu")
		return monitor.Monitor{}, false
	}
	return m, true
}
