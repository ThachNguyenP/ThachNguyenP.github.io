package api

import (
	"errors"
	"net/http"
	"strings"

	"github.com/thachnguyenp/pulse/internal/auth"
	"github.com/thachnguyenp/pulse/internal/user"
)

func (s *Server) register(w http.ResponseWriter, r *http.Request) {
	var creds user.Credentials
	if err := readJSON(r, &creds); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	if problems := creds.Validate(); len(problems) > 0 {
		writeValidation(w, problems)
		return
	}

	hash, err := auth.HashPassword(creds.Password)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "không tạo được tài khoản")
		return
	}
	u := user.User{Email: creds.Email, PasswordHash: hash}
	err = s.users.Create(r.Context(), &u)
	if errors.Is(err, user.ErrEmailTaken) {
		writeError(w, http.StatusConflict, "email đã được đăng ký")
		return
	}
	if err != nil {
		writeError(w, http.StatusInternalServerError, "không tạo được tài khoản")
		return
	}
	writeJSON(w, http.StatusCreated, u)
}

func (s *Server) login(w http.ResponseWriter, r *http.Request) {
	var creds user.Credentials
	if err := readJSON(r, &creds); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	creds.Email = strings.ToLower(strings.TrimSpace(creds.Email))

	u, err := s.users.GetByEmail(r.Context(), creds.Email)
	// Sai email hay sai mật khẩu đều báo giống nhau, để không lộ email nào đã đăng ký.
	if err != nil || !auth.CheckPassword(u.PasswordHash, creds.Password) {
		writeError(w, http.StatusUnauthorized, "email hoặc mật khẩu không đúng")
		return
	}

	token, err := s.tokens.Issue(u.ID)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "không tạo được token")
		return
	}
	writeJSON(w, http.StatusOK, map[string]string{"token": token})
}

func (s *Server) me(w http.ResponseWriter, r *http.Request) {
	id, _ := auth.UserID(r.Context())
	u, err := s.users.Get(r.Context(), id)
	if err != nil {
		writeError(w, http.StatusUnauthorized, "tài khoản không còn tồn tại")
		return
	}
	writeJSON(w, http.StatusOK, u)
}

// requireAuth đọc header "Authorization: Bearer <token>", đặt user id vào context.
func (s *Server) requireAuth(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		token, ok := strings.CutPrefix(r.Header.Get("Authorization"), "Bearer ")
		if !ok || token == "" {
			writeError(w, http.StatusUnauthorized, "cần đăng nhập")
			return
		}
		id, err := s.tokens.Parse(token)
		if err != nil {
			writeError(w, http.StatusUnauthorized, "token không hợp lệ hoặc đã hết hạn")
			return
		}
		next.ServeHTTP(w, r.WithContext(auth.WithUserID(r.Context(), id)))
	})
}
