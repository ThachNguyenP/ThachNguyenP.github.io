package sites

import (
	"slices"
	"strings"
	"testing"
)

func TestRead(t *testing.T) {
	input := `
# ghi chú
https://a.com
b.com

https://a.com
`
	got, err := Read(strings.NewReader(input))
	if err != nil {
		t.Fatal(err)
	}
	want := []string{"https://a.com", "https://b.com"}
	if !slices.Equal(got, want) {
		t.Errorf("got %v, want %v", got, want)
	}
}

func TestReadEmpty(t *testing.T) {
	_, err := Read(strings.NewReader("# chỉ có ghi chú\n"))
	if err == nil {
		t.Error("danh sách rỗng phải báo lỗi")
	}
}
