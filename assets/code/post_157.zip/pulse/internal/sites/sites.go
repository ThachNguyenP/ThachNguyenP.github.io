// Package sites đọc danh sách URL cần kiểm tra.
package sites

import (
	"bufio"
	"fmt"
	"io"
	"os"
	"strings"
)

// ReadFile đọc danh sách URL từ file, mỗi dòng một URL.
func ReadFile(path string) ([]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("đọc danh sách: %w", err)
	}
	defer f.Close()
	return Read(f)
}

// Read đọc danh sách URL từ bất kỳ nguồn nào (file, stdin, chuỗi...).
// Bỏ qua dòng trống, dòng bắt đầu bằng # và URL trùng.
func Read(r io.Reader) ([]string, error) {
	var urls []string
	seen := map[string]bool{}

	scanner := bufio.NewScanner(r)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if !strings.HasPrefix(line, "http://") && !strings.HasPrefix(line, "https://") {
			line = "https://" + line
		}
		if seen[line] {
			continue
		}
		seen[line] = true
		urls = append(urls, line)
	}
	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("đọc danh sách: %w", err)
	}
	if len(urls) == 0 {
		return nil, fmt.Errorf("danh sách không có URL nào")
	}
	return urls, nil
}
