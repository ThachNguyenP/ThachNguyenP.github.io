package store

import (
	"context"
	"errors"

	"github.com/jackc/pgx/v5"

	"github.com/thachnguyenp/pulse/internal/monitor"
)

// Monitors lưu monitor vào bảng monitors.
type Monitors struct {
	db *DB
}

func NewMonitors(db *DB) *Monitors {
	return &Monitors{db: db}
}

const monitorColumns = `id, user_id, name, url, interval_seconds, last_status, next_check_at, created_at`

func scanMonitor(row pgx.Row) (monitor.Monitor, error) {
	var m monitor.Monitor
	err := row.Scan(&m.ID, &m.UserID, &m.Name, &m.URL, &m.Interval, &m.LastStatus, &m.NextCheckAt, &m.CreatedAt)
	return m, err
}

func (s *Monitors) Create(ctx context.Context, m *monitor.Monitor) error {
	created, err := scanMonitor(s.db.pool.QueryRow(ctx, `
		INSERT INTO monitors (user_id, name, url, interval_seconds)
		VALUES ($1, $2, $3, $4)
		RETURNING `+monitorColumns,
		m.UserID, m.Name, m.URL, m.Interval,
	))
	if err != nil {
		return err
	}
	*m = created
	return nil
}

func (s *Monitors) List(ctx context.Context, userID int64) ([]monitor.Monitor, error) {
	rows, err := s.db.pool.Query(ctx, `SELECT `+monitorColumns+` FROM monitors WHERE user_id = $1 ORDER BY id`, userID)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	list := []monitor.Monitor{}
	for rows.Next() {
		m, err := scanMonitor(rows)
		if err != nil {
			return nil, err
		}
		list = append(list, m)
	}
	return list, rows.Err()
}

// Get tìm theo id VÀ user_id: người này không bao giờ đọc được monitor của người khác.
func (s *Monitors) Get(ctx context.Context, userID, id int64) (monitor.Monitor, error) {
	m, err := scanMonitor(s.db.pool.QueryRow(ctx,
		`SELECT `+monitorColumns+` FROM monitors WHERE id = $1 AND user_id = $2`, id, userID))
	if errors.Is(err, pgx.ErrNoRows) {
		return monitor.Monitor{}, monitor.ErrNotFound
	}
	return m, err
}

func (s *Monitors) Delete(ctx context.Context, userID, id int64) error {
	tag, err := s.db.pool.Exec(ctx, `DELETE FROM monitors WHERE id = $1 AND user_id = $2`, id, userID)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return monitor.ErrNotFound
	}
	return nil
}

// ClaimDue lấy tối đa `limit` monitor đã tới giờ kiểm tra và dời lịch của chúng
// sang lần sau ngay trong cùng một câu lệnh. Nhờ FOR UPDATE SKIP LOCKED, nhiều
// pulsed chạy cùng lúc cũng không lấy trùng monitor.
func (s *Monitors) ClaimDue(ctx context.Context, limit int) ([]monitor.Monitor, error) {
	rows, err := s.db.pool.Query(ctx, `
		UPDATE monitors
		SET next_check_at = now() + interval_seconds * interval '1 second'
		WHERE id IN (
			SELECT id FROM monitors
			WHERE next_check_at <= now()
			ORDER BY next_check_at
			LIMIT $1
			FOR UPDATE SKIP LOCKED
		)
		RETURNING `+monitorColumns, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []monitor.Monitor
	for rows.Next() {
		m, err := scanMonitor(rows)
		if err != nil {
			return nil, err
		}
		list = append(list, m)
	}
	return list, rows.Err()
}
