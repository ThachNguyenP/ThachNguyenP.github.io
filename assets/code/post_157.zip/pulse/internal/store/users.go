package store

import (
	"context"
	"errors"

	"github.com/jackc/pgx/v5"
	"github.com/jackc/pgx/v5/pgconn"

	"github.com/thachnguyenp/pulse/internal/user"
)

// Users lưu người dùng vào bảng users.
type Users struct {
	db *DB
}

func NewUsers(db *DB) *Users {
	return &Users{db: db}
}

func (s *Users) Create(ctx context.Context, u *user.User) error {
	err := s.db.pool.QueryRow(ctx, `
		INSERT INTO users (email, password_hash)
		VALUES ($1, $2)
		RETURNING id, created_at`,
		u.Email, u.PasswordHash,
	).Scan(&u.ID, &u.CreatedAt)

	// 23505 là mã lỗi "unique_violation" của PostgreSQL: email đã có người dùng.
	var pgErr *pgconn.PgError
	if errors.As(err, &pgErr) && pgErr.Code == "23505" {
		return user.ErrEmailTaken
	}
	return err
}

func (s *Users) GetByEmail(ctx context.Context, email string) (user.User, error) {
	var u user.User
	err := s.db.pool.QueryRow(ctx, `
		SELECT id, email, password_hash, created_at FROM users WHERE email = $1`, email,
	).Scan(&u.ID, &u.Email, &u.PasswordHash, &u.CreatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return user.User{}, user.ErrNotFound
	}
	return u, err
}

func (s *Users) Get(ctx context.Context, id int64) (user.User, error) {
	var u user.User
	err := s.db.pool.QueryRow(ctx, `
		SELECT id, email, password_hash, created_at FROM users WHERE id = $1`, id,
	).Scan(&u.ID, &u.Email, &u.PasswordHash, &u.CreatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return user.User{}, user.ErrNotFound
	}
	return u, err
}
