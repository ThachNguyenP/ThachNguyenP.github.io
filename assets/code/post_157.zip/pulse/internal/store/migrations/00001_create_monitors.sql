-- +goose Up
CREATE TABLE monitors (
    id               BIGSERIAL PRIMARY KEY,
    name             TEXT        NOT NULL,
    url              TEXT        NOT NULL,
    interval_seconds INTEGER     NOT NULL DEFAULT 60,
    created_at       TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- +goose Down
DROP TABLE monitors;
