-- +goose Up
ALTER TABLE monitors
    ADD COLUMN last_status   TEXT        NOT NULL DEFAULT 'pending',
    ADD COLUMN next_check_at TIMESTAMPTZ NOT NULL DEFAULT now();

CREATE TABLE checks (
    id          BIGSERIAL PRIMARY KEY,
    monitor_id  BIGINT      NOT NULL REFERENCES monitors(id) ON DELETE CASCADE,
    status      TEXT        NOT NULL,
    status_code INTEGER     NOT NULL DEFAULT 0,
    latency_ms  INTEGER     NOT NULL DEFAULT 0,
    error       TEXT        NOT NULL DEFAULT '',
    checked_at  TIMESTAMPTZ NOT NULL DEFAULT now()
);

CREATE INDEX checks_monitor_id_checked_at_idx ON checks (monitor_id, checked_at DESC);

-- +goose Down
DROP TABLE checks;
ALTER TABLE monitors DROP COLUMN last_status, DROP COLUMN next_check_at;
