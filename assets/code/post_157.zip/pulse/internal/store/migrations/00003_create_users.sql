-- +goose Up
CREATE TABLE users (
    id            BIGSERIAL PRIMARY KEY,
    email         TEXT        NOT NULL UNIQUE,
    password_hash TEXT        NOT NULL,
    created_at    TIMESTAMPTZ NOT NULL DEFAULT now()
);

-- Monitor từ bài trước chưa có chủ, xóa đi rồi mới bắt buộc user_id.
DELETE FROM monitors;

ALTER TABLE monitors
    ADD COLUMN user_id BIGINT NOT NULL REFERENCES users(id) ON DELETE CASCADE;

CREATE INDEX monitors_user_id_idx ON monitors (user_id);

-- +goose Down
ALTER TABLE monitors DROP COLUMN user_id;
DROP TABLE users;
