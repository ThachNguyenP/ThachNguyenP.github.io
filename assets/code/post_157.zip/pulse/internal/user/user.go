// Package user định nghĩa người dùng của hệ thống.
package user

import (
	"context"
	"errors"
	"net/mail"
	"strings"
	"time"
)

var (
	ErrNotFound   = errors.New("user not found")
	ErrEmailTaken = errors.New("email already registered")
)

// User là một tài khoản. PasswordHash không bao giờ trả ra JSON.
type User struct {
	ID           int64     `json:"id"`
	Email        string    `json:"email"`
	PasswordHash string    `json:"-"`
	CreatedAt    time.Time `json:"created_at"`
}

// Credentials là dữ liệu đăng ký / đăng nhập gửi lên.
type Credentials struct {
	Email    string `json:"email"`
	Password string `json:"password"`
}

// Validate kiểm tra email và mật khẩu. Trả về map rỗng nếu hợp lệ.
func (c *Credentials) Validate() map[string]string {
	problems := map[string]string{}

	c.Email = strings.ToLower(strings.TrimSpace(c.Email))
	if _, err := mail.ParseAddress(c.Email); err != nil || len(c.Email) > 254 {
		problems["email"] = "email không hợp lệ"
	}
	if len(c.Password) < 8 {
		problems["password"] = "ít nhất 8 ký tự"
	} else if len(c.Password) > 72 {
		problems["password"] = "tối đa 72 ký tự"
	}
	return problems
}

// Store là nơi lưu người dùng.
type Store interface {
	Create(ctx context.Context, u *User) error
	GetByEmail(ctx context.Context, email string) (User, error)
	Get(ctx context.Context, id int64) (User, error)
}
