// Package scheduler chạy nền, tới giờ thì kiểm tra monitor và lưu kết quả.
package scheduler

import (
	"context"
	"log/slog"
	"sync"
	"time"

	"github.com/thachnguyenp/pulse/internal/checker"
	"github.com/thachnguyenp/pulse/internal/monitor"
)

// Store chỉ gồm hai việc scheduler cần. Interface nhỏ, đặt ở nơi dùng.
type Store interface {
	ClaimDue(ctx context.Context, limit int) ([]monitor.Monitor, error)
	SaveCheck(ctx context.Context, c *monitor.Check) error
}

// Scheduler cứ mỗi giây hỏi database "có monitor nào tới giờ chưa" rồi kiểm tra.
type Scheduler struct {
	store   Store
	checker *checker.Checker
	workers int
}

// New tạo Scheduler chạy tối đa `workers` kiểm tra song song.
func New(store Store, c *checker.Checker, workers int) *Scheduler {
	return &Scheduler{store: store, checker: c, workers: workers}
}

// Run chạy cho tới khi ctx bị hủy. Trước khi trả về, chờ các kiểm tra dở dang lưu xong.
func (s *Scheduler) Run(ctx context.Context) error {
	ticker := time.NewTicker(time.Second)
	defer ticker.Stop()

	sem := make(chan struct{}, s.workers) // giới hạn số goroutine chạy cùng lúc
	var wg sync.WaitGroup

	slog.Info("scheduler đang chạy", "workers", s.workers)
	for {
		select {
		case <-ctx.Done():
			wg.Wait()
			slog.Info("scheduler đã dừng")
			return nil
		case <-ticker.C:
		}

		due, err := s.store.ClaimDue(ctx, 100)
		if err != nil {
			if ctx.Err() != nil {
				continue // đang tắt, lỗi do ctx hủy là bình thường
			}
			slog.Error("không lấy được monitor tới giờ", "error", err)
			continue
		}

		for _, m := range due {
			sem <- struct{}{} // đầy thì đứng chờ ở đây
			wg.Add(1)
			go func() {
				defer wg.Done()
				defer func() { <-sem }()
				s.runOne(ctx, m)
			}()
		}
	}
}

func (s *Scheduler) runOne(ctx context.Context, m monitor.Monitor) {
	result := s.checker.Check(ctx, m.URL)
	c := monitor.CheckFromResult(m.ID, result)

	// Dù đang tắt (ctx bị hủy) vẫn cố lưu kết quả vừa có, tối đa 5 giây.
	saveCtx, cancel := context.WithTimeout(context.WithoutCancel(ctx), 5*time.Second)
	defer cancel()
	if err := s.store.SaveCheck(saveCtx, &c); err != nil {
		slog.Error("không lưu được kết quả", "monitor", m.ID, "error", err)
		return
	}
	slog.Info("đã kiểm tra", "monitor", m.ID, "name", m.Name, "status", c.Status, "latency_ms", c.LatencyMS)
}
