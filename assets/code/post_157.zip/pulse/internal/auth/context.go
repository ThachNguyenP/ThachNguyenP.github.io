package auth

import "context"

// ctxKey là kiểu riêng để không đụng key của package khác trong context.
type ctxKey struct{}

// WithUserID gắn id người dùng vào context.
func WithUserID(ctx context.Context, id int64) context.Context {
	return context.WithValue(ctx, ctxKey{}, id)
}

// UserID lấy id người dùng từ context. ok = false nếu chưa đăng nhập.
func UserID(ctx context.Context) (int64, bool) {
	id, ok := ctx.Value(ctxKey{}).(int64)
	return id, ok
}
