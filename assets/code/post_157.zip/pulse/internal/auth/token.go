package auth

import (
	"errors"
	"fmt"
	"strconv"
	"time"

	"github.com/golang-jwt/jwt/v5"
)

// Tokens ký và đọc JWT.
type Tokens struct {
	secret []byte
	ttl    time.Duration
}

// NewTokens tạo bộ ký token với khóa bí mật và thời hạn.
func NewTokens(secret string, ttl time.Duration) *Tokens {
	return &Tokens{secret: []byte(secret), ttl: ttl}
}

// Issue tạo token cho người dùng có id cho trước.
func (t *Tokens) Issue(userID int64) (string, error) {
	now := time.Now()
	claims := jwt.RegisteredClaims{
		Subject:   strconv.FormatInt(userID, 10),
		IssuedAt:  jwt.NewNumericDate(now),
		ExpiresAt: jwt.NewNumericDate(now.Add(t.ttl)),
	}
	return jwt.NewWithClaims(jwt.SigningMethodHS256, claims).SignedString(t.secret)
}

// Parse kiểm tra chữ ký và hạn, trả về id người dùng trong token.
func (t *Tokens) Parse(token string) (int64, error) {
	var claims jwt.RegisteredClaims
	_, err := jwt.ParseWithClaims(token, &claims, func(tok *jwt.Token) (any, error) {
		if tok.Method != jwt.SigningMethodHS256 {
			return nil, errors.New("sai thuật toán ký")
		}
		return t.secret, nil
	})
	if err != nil {
		return 0, fmt.Errorf("token không hợp lệ: %w", err)
	}
	return strconv.ParseInt(claims.Subject, 10, 64)
}
