// Package auth lo mật khẩu và token đăng nhập.
package auth

import "golang.org/x/crypto/bcrypt"

// HashPassword băm mật khẩu bằng bcrypt. Mỗi lần băm cho ra chuỗi khác nhau (có salt).
func HashPassword(password string) (string, error) {
	hash, err := bcrypt.GenerateFromPassword([]byte(password), bcrypt.DefaultCost)
	return string(hash), err
}

// CheckPassword so mật khẩu người dùng gõ với hash đã lưu.
func CheckPassword(hash, password string) bool {
	return bcrypt.CompareHashAndPassword([]byte(hash), []byte(password)) == nil
}
