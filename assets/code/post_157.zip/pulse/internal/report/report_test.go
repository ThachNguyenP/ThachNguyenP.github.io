package report

import (
	"bytes"
	"encoding/json"
	"strings"
	"testing"

	"github.com/thachnguyenp/pulse/internal/checker"
)

var sample = []checker.Result{
	{URL: "https://a.com", Status: checker.StatusUp, StatusCode: 200, LatencyMS: 120},
	{URL: "https://b.com", Status: checker.StatusDown, Error: "connection refused"},
}

func TestTable(t *testing.T) {
	var buf bytes.Buffer
	if err := (Table{}).Write(&buf, sample); err != nil {
		t.Fatal(err)
	}
	out := buf.String()
	for _, want := range []string{"https://a.com", "connection refused", "1 up, 1 down"} {
		if !strings.Contains(out, want) {
			t.Errorf("thiếu %q trong:\n%s", want, out)
		}
	}
}

func TestJSON(t *testing.T) {
	var buf bytes.Buffer
	if err := (JSON{}).Write(&buf, sample); err != nil {
		t.Fatal(err)
	}
	var back []checker.Result
	if err := json.Unmarshal(buf.Bytes(), &back); err != nil {
		t.Fatalf("JSON không hợp lệ: %v", err)
	}
	if len(back) != 2 || back[1].Error != "connection refused" {
		t.Errorf("đọc lại được %+v", back)
	}
}

func TestCSV(t *testing.T) {
	var buf bytes.Buffer
	if err := (CSV{}).Write(&buf, sample); err != nil {
		t.Fatal(err)
	}
	lines := strings.Split(strings.TrimSpace(buf.String()), "\n")
	if len(lines) != 3 {
		t.Errorf("CSV có %d dòng, muốn 3 (1 header + 2 dữ liệu)", len(lines))
	}
}
