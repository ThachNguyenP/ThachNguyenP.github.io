// Package report in kết quả kiểm tra ra nhiều định dạng.
package report

import (
	"encoding/csv"
	"encoding/json"
	"fmt"
	"io"
	"strconv"

	"github.com/thachnguyenp/pulse/internal/checker"
)

// Reporter ghi danh sách kết quả ra một nơi nào đó (màn hình, file...).
type Reporter interface {
	Write(w io.Writer, results []checker.Result) error
}

// Formats ánh xạ tên định dạng sang Reporter tương ứng.
var Formats = map[string]Reporter{
	"table": Table{},
	"json":  JSON{},
	"csv":   CSV{},
}

// Table in dạng bảng dễ đọc cho người.
type Table struct{}

func (Table) Write(w io.Writer, results []checker.Result) error {
	fmt.Fprintf(w, "%-6s %-5s %7s  %s\n", "STATUS", "CODE", "LATENCY", "URL")
	up := 0
	for _, r := range results {
		code := "-"
		if r.StatusCode != 0 {
			code = strconv.Itoa(r.StatusCode)
		}
		fmt.Fprintf(w, "%-6s %-5s %5dms  %s", r.Status, code, r.LatencyMS, r.URL)
		if r.Error != "" {
			fmt.Fprintf(w, "  (%s)", r.Error)
		}
		fmt.Fprintln(w)
		if r.Status == checker.StatusUp {
			up++
		}
	}
	_, err := fmt.Fprintf(w, "\n%d sites: %d up, %d down\n", len(results), up, len(results)-up)
	return err
}

// JSON in dạng JSON cho máy đọc.
type JSON struct{}

func (JSON) Write(w io.Writer, results []checker.Result) error {
	enc := json.NewEncoder(w)
	enc.SetIndent("", "  ")
	return enc.Encode(results)
}

// CSV in dạng CSV, mở được bằng Excel.
type CSV struct{}

func (CSV) Write(w io.Writer, results []checker.Result) error {
	cw := csv.NewWriter(w)
	cw.Write([]string{"url", "status", "status_code", "latency_ms", "error", "checked_at"})
	for _, r := range results {
		cw.Write([]string{
			r.URL,
			string(r.Status),
			strconv.Itoa(r.StatusCode),
			strconv.FormatInt(r.LatencyMS, 10),
			r.Error,
			r.CheckedAt.Format("2006-01-02 15:04:05"),
		})
	}
	cw.Flush()
	return cw.Error()
}
