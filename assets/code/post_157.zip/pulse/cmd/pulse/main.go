// pulse: kiểm tra một danh sách URL, in kết quả.
package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"io"
	"io/fs"
	"os"
	"os/signal"
	"time"

	"github.com/thachnguyenp/pulse/internal/checker"
	"github.com/thachnguyenp/pulse/internal/report"
	"github.com/thachnguyenp/pulse/internal/sites"
)

func main() {
	if err := run(); err != nil {
		fmt.Fprintln(os.Stderr, "Lỗi:", err)
		os.Exit(1)
	}
}

func run() error {
	file := flag.String("file", "sites.txt", "file chứa danh sách URL")
	timeout := flag.Duration("timeout", 5*time.Second, "thời gian chờ tối đa mỗi request")
	workers := flag.Int("workers", 10, "số request chạy song song")
	format := flag.String("format", "table", "định dạng kết quả: table, json, csv")
	out := flag.String("out", "", "ghi kết quả ra file này thay vì màn hình")
	flag.Parse()

	reporter, ok := report.Formats[*format]
	if !ok {
		return fmt.Errorf("không có định dạng %q", *format)
	}

	urls, err := sites.ReadFile(*file)
	if errors.Is(err, fs.ErrNotExist) {
		return fmt.Errorf("không thấy file %s, tạo file với mỗi dòng một URL rồi chạy lại", *file)
	}
	if err != nil {
		return err
	}

	// ctx bị hủy khi người dùng bấm Ctrl+C.
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()

	c := checker.New(*timeout)
	results := c.CheckAll(ctx, urls, *workers)

	var w io.Writer = os.Stdout
	if *out != "" {
		f, err := os.Create(*out)
		if err != nil {
			return err
		}
		defer f.Close()
		w = f
	}
	return reporter.Write(w, results)
}
