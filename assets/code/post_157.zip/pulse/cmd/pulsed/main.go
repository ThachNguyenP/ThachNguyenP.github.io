// pulsed: server của Pulse, cung cấp HTTP API.
package main

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"golang.org/x/sync/errgroup"

	"github.com/thachnguyenp/pulse/internal/api"
	"github.com/thachnguyenp/pulse/internal/auth"
	"github.com/thachnguyenp/pulse/internal/checker"
	"github.com/thachnguyenp/pulse/internal/config"
	"github.com/thachnguyenp/pulse/internal/scheduler"
	"github.com/thachnguyenp/pulse/internal/store"
)

func main() {
	if err := run(); err != nil {
		slog.Error("server dừng vì lỗi", "error", err)
		os.Exit(1)
	}
}

func run() error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	db, err := store.Connect(ctx, cfg.DatabaseURL)
	if err != nil {
		return err
	}
	defer db.Close()

	if err := db.Migrate(ctx); err != nil {
		return err
	}
	slog.Info("database sẵn sàng")

	chk := checker.New(cfg.CheckTimeout)
	monitors := store.NewMonitors(db)
	tokens := auth.NewTokens(cfg.JWTSecret, cfg.TokenTTL)
	server := api.New(monitors, store.NewUsers(db), chk, tokens)
	sched := scheduler.New(monitors, chk, cfg.Workers)

	srv := &http.Server{
		Addr:              cfg.Addr,
		Handler:           server.Handler(),
		ReadHeaderTimeout: 5 * time.Second,
	}

	// errgroup chạy nhiều việc song song; một việc lỗi thì ctx của cả nhóm bị hủy.
	g, ctx := errgroup.WithContext(ctx)

	g.Go(func() error {
		return sched.Run(ctx)
	})

	g.Go(func() error {
		slog.Info("pulsed đang chạy", "addr", cfg.Addr)
		if err := srv.ListenAndServe(); !errors.Is(err, http.ErrServerClosed) {
			return err
		}
		return nil
	})

	g.Go(func() error {
		<-ctx.Done() // chờ Ctrl+C hoặc một việc khác lỗi
		slog.Info("đang tắt, chờ request dở dang...")
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		return srv.Shutdown(shutdownCtx)
	})

	err = g.Wait()
	slog.Info("đã tắt")
	return err
}
