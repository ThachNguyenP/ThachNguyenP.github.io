// fakeweb là một web server giả để thử pulse mà không cần Internet.
// Chạy: go run ./fakeweb
package main

import (
	"fmt"
	"math/rand"
	"net/http"
	"time"
)

func main() {
	http.HandleFunc("/fast", func(w http.ResponseWriter, r *http.Request) {
		fmt.Fprintln(w, "ok")
	})
	http.HandleFunc("/slow", func(w http.ResponseWriter, r *http.Request) {
		time.Sleep(3 * time.Second)
		fmt.Fprintln(w, "ok, nhưng chậm")
	})
	http.HandleFunc("/flaky", func(w http.ResponseWriter, r *http.Request) {
		if rand.Intn(2) == 0 {
			http.Error(w, "lúc được lúc không", http.StatusInternalServerError)
			return
		}
		fmt.Fprintln(w, "ok")
	})
	http.HandleFunc("/down", func(w http.ResponseWriter, r *http.Request) {
		http.Error(w, "bảo trì", http.StatusServiceUnavailable)
	})
	// /site/1, /site/2, ... mỗi site trả lời sau 100-500ms, giống web thật.
	http.HandleFunc("/site/", func(w http.ResponseWriter, r *http.Request) {
		time.Sleep(time.Duration(100+rand.Intn(400)) * time.Millisecond)
		fmt.Fprintln(w, "ok")
	})

	fmt.Println("fakeweb chạy ở http://localhost:8080")
	http.ListenAndServe(":8080", nil)
}
