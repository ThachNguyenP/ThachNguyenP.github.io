# Cổng thanh toán giả lập (thay cho Stripe/VNPay khi test). Có "công tắc hỏng hóc" để test khả năng chịu lỗi:
#   POST /charge            -> 200 {"ok":true}   (hoặc hỏng/chậm tùy mode)
#   POST /mode  mode=ok|down|slow   -> đổi cách hành xử (chỉ dùng trong môi trường test)
# Chạy: bundle exec ruby services/payment.rb   (cổng 8083)
require "sinatra"
require "json"

set :server, :puma
set :port, ENV.fetch("PORT", 8083)
set :logging, false

MODE = { value: "ok" }

post "/charge" do
  case MODE[:value]
  when "down" then halt 500, "payment gateway error"
  when "slow" then sleep 5
  end
  content_type :json
  JSON.generate(ok: true, amount: params[:amount].to_i)
end

post "/mode" do
  MODE[:value] = params[:mode] if %w[ok down slow].include?(params[:mode])
  "mode=#{MODE[:value]}"
end

get("/healthz") { MODE[:value] == "down" ? halt(500, "down") : "ok" }
