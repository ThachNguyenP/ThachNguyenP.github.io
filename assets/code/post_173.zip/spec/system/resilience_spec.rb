# Test chịu lỗi: cố tình làm dịch vụ phụ thuộc (cổng thanh toán) hỏng hoặc chậm, rồi xem app phản ứng thế nào.
# Cần PAYMENT_ADMIN_URL trỏ tới cổng thanh toán giả lập (services/payment.rb) để bật/tắt hỏng hóc.
#   PAYMENT_ADMIN_URL=http://localhost:8083 BASE_URL=http://localhost:8080 bundle exec rspec spec/system/resilience_spec.rb
require_relative "system_helper"

RSpec.describe "Chịu lỗi khi cổng thanh toán có vấn đề", if: ENV["PAYMENT_ADMIN_URL"] do
  def payment_mode(mode)
    Net::HTTP.post_form(URI("#{ENV['PAYMENT_ADMIN_URL']}/mode"), mode: mode)
  end

  before { register }
  after { payment_mode("ok") }   # dù test đỏ hay xanh cũng trả cổng thanh toán về bình thường

  it "cổng thanh toán hỏng: báo 503 rõ ràng, tồn kho KHÔNG mất, không có đơn treo" do
    before = product(5)
    payment_mode("down")
    buy(5, 1)
    expect(client.last.code).to eq("503")
    expect(client.last.body).to include("thanh toán")
    expect(product(5)["stock"]).to eq(before["stock"])
    client.get("/orders")
    expect(client.last.body).not_to include("paid")
  end

  it "cổng thanh toán treo: app trả lời trong vòng 3 giây thay vì treo theo" do
    payment_mode("slow")
    t = Process.clock_gettime(Process::CLOCK_MONOTONIC)
    buy(5, 1)
    elapsed = Process.clock_gettime(Process::CLOCK_MONOTONIC) - t
    expect(client.last.code).to eq("503")
    expect(elapsed).to be < 3
  end

  it "cổng thanh toán hồi phục: mua lại được ngay, không cần restart app" do
    payment_mode("down")
    buy(5, 1)
    expect(client.last.code).to eq("503")
    payment_mode("ok")
    buy(5, 1)
    expect(client.last).to be_a(Net::HTTPRedirection)
  end

  it "/healthz vẫn 200 khi cổng thanh toán hỏng (app còn sống), nhưng nói rõ phụ thuộc nào đang hỏng" do
    payment_mode("down")
    client.get("/healthz")
    expect(client.last.code).to eq("200")
    expect(client.json["payment"]).to eq("down")
  end
end
