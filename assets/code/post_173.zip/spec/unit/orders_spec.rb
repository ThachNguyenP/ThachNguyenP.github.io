# Unit test: gọi thẳng Shop::Orders, không qua HTTP. Nhanh, và chỉ ra chính xác nghiệp vụ nào hỏng.
require_relative "../spec_helper"

RSpec.describe Shop::Orders do
  let!(:user_id) { create_user }
  let!(:product_id) { create_product(stock: 5, price: 100_000) }
  # Cổng thanh toán giả: unit test không gọi mạng. Ghi lại số tiền được gọi để kiểm tra.
  let(:charged) { [] }
  let(:payment_ok) { double("payment").tap { |p| allow(p).to receive(:charge) { |amount| charged << amount } } }
  let(:payment_down) { double("payment").tap { |p| allow(p).to receive(:charge).and_raise(Payment::Down, "hỏng") } }

  it "trừ kho, thanh toán đúng số tiền, đơn thành paid" do
    id = described_class.create(user_id: user_id, product_id: product_id, qty: 2, payment: payment_ok)
    expect(described_class.get(id)).to include("total" => 200_000, "status" => "paid")
    expect(charged).to eq([200_000])
    expect(Shop::Products.get(product_id)["stock"]).to eq(3)
  end

  it "thanh toán thất bại: trả lại kho, đơn thành failed, lỗi được ném ra" do
    expect { described_class.create(user_id: user_id, product_id: product_id, qty: 2, payment: payment_down) }
      .to raise_error(Payment::Down)
    expect(Shop::Products.get(product_id)["stock"]).to eq(5)
    expect(described_class.all.map { |o| o["status"] }).to eq(["failed"])
  end

  it "từ chối khi không đủ hàng và KHÔNG trừ kho" do
    expect { described_class.create(user_id: user_id, product_id: product_id, qty: 6, payment: payment_ok) }
      .to raise_error(Shop::OutOfStock, /chỉ còn 5/)
    expect(Shop::Products.get(product_id)["stock"]).to eq(5)
    expect(described_class.all).to be_empty
  end

  it "từ chối số lượng 0 hoặc âm" do
    expect { described_class.create(user_id: user_id, product_id: product_id, qty: 0, payment: payment_ok) }.to raise_error(Shop::Invalid)
    expect { described_class.create(user_id: user_id, product_id: product_id, qty: -1, payment: payment_ok) }.to raise_error(Shop::Invalid)
  end

  it "báo NotFound với sản phẩm không tồn tại" do
    expect { described_class.create(user_id: user_id, product_id: 999, qty: 1, payment: payment_ok) }.to raise_error(Shop::NotFound)
  end
end
