# Toàn bộ nghiệp vụ của shop: user, sản phẩm, đơn hàng. Không có gì liên quan tới HTTP ở đây.
require "bcrypt"
require_relative "db"
require_relative "payment"

module Shop
  SCHEMA = <<~SQL
    CREATE TABLE IF NOT EXISTS users (
      id INTEGER PRIMARY KEY, email TEXT NOT NULL UNIQUE, password_digest TEXT NOT NULL,
      role TEXT NOT NULL DEFAULT 'customer');
    CREATE TABLE IF NOT EXISTS products (
      id INTEGER PRIMARY KEY, name TEXT NOT NULL, price INTEGER NOT NULL, stock INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS orders (
      id INTEGER PRIMARY KEY, user_id INTEGER NOT NULL REFERENCES users(id),
      status TEXT NOT NULL DEFAULT 'paid', total INTEGER NOT NULL,
      created_at TEXT NOT NULL DEFAULT (datetime('now')));
    CREATE TABLE IF NOT EXISTS order_items (
      id INTEGER PRIMARY KEY, order_id INTEGER NOT NULL REFERENCES orders(id),
      product_id INTEGER NOT NULL REFERENCES products(id), qty INTEGER NOT NULL, price INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS health (id INTEGER PRIMARY KEY CHECK (id = 1), checked_at TEXT);
    INSERT OR IGNORE INTO health (id) VALUES (1);
    CREATE INDEX IF NOT EXISTS idx_orders_user ON orders(user_id);
    CREATE INDEX IF NOT EXISTS idx_order_items_order ON order_items(order_id);
  SQL

  class Error < StandardError; end
  class NotFound < Error; end
  class OutOfStock < Error; end
  class Invalid < Error; end

  def self.db = @db
  def self.db=(db)
    @db = db
  end

  module Users
    def self.create(email:, password:, role: "customer")
      raise Invalid, "email không hợp lệ" unless email.to_s.match?(/\A[^@\s]+@[^@\s]+\z/)
      raise Invalid, "mật khẩu phải từ 8 ký tự" if password.to_s.length < 8
      Shop.db.execute("INSERT INTO users (email, password_digest, role) VALUES (?, ?, ?)",
                      [email, BCrypt::Password.create(password, cost: 4), role])
      Shop.db.last_insert_row_id
    rescue SQLite3::ConstraintException
      raise Invalid, "email đã tồn tại"
    end

    def self.authenticate(email, password)
      u = Shop.db.get_first_row("SELECT * FROM users WHERE email = ?", [email])
      u if u && BCrypt::Password.new(u["password_digest"]) == password.to_s
    end

    def self.get(id) = Shop.db.get_first_row("SELECT * FROM users WHERE id = ?", [id])
  end

  module Products
    def self.list(q = nil)
      return Shop.db.execute("SELECT * FROM products ORDER BY id") if q.to_s.empty?
      Shop.db.execute("SELECT * FROM products WHERE name LIKE ? ORDER BY id", ["%#{q}%"])
    end

    def self.get(id)
      Shop.db.get_first_row("SELECT * FROM products WHERE id = ?", [id]) or raise NotFound, "không có sản phẩm #{id}"
    end
  end

  module Orders
    # Tạo đơn một sản phẩm: (1) trừ kho + ghi đơn "pending" trong một transaction, (2) gọi thanh toán BÊN NGOÀI
    # transaction (không giữ khóa ghi trong lúc chờ mạng), (3) thành công -> "paid"; thất bại -> trả kho, đánh dấu "failed".
    # `payment` truyền vào được để unit test không phải gọi HTTP.
    def self.create(user_id:, product_id:, qty:, payment: Payment, attempt: 1)
      qty = qty.to_i
      raise Invalid, "số lượng phải lớn hơn 0" if qty <= 0
      order_id = reserve(user_id, product_id, qty)
      begin
        payment.charge(Shop.db.get_first_value("SELECT total FROM orders WHERE id = ?", [order_id]))
      rescue Payment::Down
        release(order_id)
        raise
      end
      Shop.db.execute("UPDATE orders SET status = 'paid' WHERE id = ?", [order_id])
      order_id
    rescue SQLite3::BusyException
      # SQLite chỉ cho một bên ghi tại một thời điểm; hiếm khi hết busy_timeout mà vẫn chưa tới lượt. Thử lại tối đa 3 lần.
      raise if attempt >= 3
      create(user_id: user_id, product_id: product_id, qty: qty, attempt: attempt + 1)
    end

    # :immediate = lấy khóa ghi ngay từ đầu. Transaction mặc định bắt đầu bằng đọc, lúc chuyển sang ghi
    # mà gặp kết nối khác đang ghi thì SQLite trả "database is locked" ngay, không chờ busy_timeout.
    def self.reserve(user_id, product_id, qty)
      Shop.db.transaction(:immediate) do
        product = Products.get(product_id)
        Shop.db.execute("UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?", [qty, product_id, qty])
        raise OutOfStock, "#{product['name']} chỉ còn #{product['stock']}" unless Shop.db.changes == 1
        Shop.db.execute("INSERT INTO orders (user_id, status, total) VALUES (?, 'pending', ?)", [user_id, product["price"] * qty])
        order_id = Shop.db.last_insert_row_id
        Shop.db.execute("INSERT INTO order_items (order_id, product_id, qty, price) VALUES (?, ?, ?, ?)",
                        [order_id, product_id, qty, product["price"]])
        order_id
      end
    end

    # Bước bù trừ khi thanh toán thất bại: trả kho và giữ lại đơn với trạng thái "failed" để còn dấu vết.
    def self.release(order_id)
      Shop.db.transaction(:immediate) do
        Shop.db.execute("UPDATE products SET stock = stock + oi.qty FROM order_items oi WHERE oi.order_id = ? AND products.id = oi.product_id", [order_id])
        Shop.db.execute("UPDATE orders SET status = 'failed' WHERE id = ?", [order_id])
      end
    end

    def self.get(id)
      Shop.db.get_first_row("SELECT * FROM orders WHERE id = ?", [id]) or raise NotFound, "không có đơn #{id}"
    end

    # Khách chỉ thấy đơn của mình; admin thấy tất cả. Trả 404 (không phải 403) để không lộ việc đơn đó tồn tại.
    def self.get_for_user(id, user)
      order = get(id)
      raise NotFound, "không có đơn #{id}" unless user["role"] == "admin" || order["user_id"] == user["id"]
      order
    end

    PER_PAGE = 50

    def self.for_user(user_id, page: 1)
      Shop.db.execute("SELECT * FROM orders WHERE user_id = ? AND status = 'paid' ORDER BY id DESC LIMIT ? OFFSET ?",
                      [user_id, PER_PAGE, (page - 1) * PER_PAGE])
    end

    # Đơn của một khách (một trang) kèm tên sản phẩm, trong ĐÚNG HAI câu SQL dù có bao nhiêu đơn (thay cho N+1).
    def self.for_user_with_items(user_id, page: 1)
      orders = for_user(user_id, page: page)
      return orders if orders.empty?
      ids = orders.map { |o| o["id"] }
      items = Shop.db.execute(<<~SQL, ids)
        SELECT oi.order_id, oi.qty, p.name FROM order_items oi JOIN products p ON p.id = oi.product_id
        WHERE oi.order_id IN (#{ids.map { '?' }.join(',')})
      SQL
      by_order = items.group_by { |it| it["order_id"] }
      orders.each { |o| o["items"] = by_order.fetch(o["id"], []) }
    end

    def self.items(order_id)
      Shop.db.execute("SELECT * FROM order_items WHERE order_id = ?", [order_id]).map do |it|
        it.merge("product" => Products.get(it["product_id"]))
      end
    end

    def self.all
      Shop.db.execute("SELECT * FROM orders ORDER BY id DESC")
    end
  end
end
