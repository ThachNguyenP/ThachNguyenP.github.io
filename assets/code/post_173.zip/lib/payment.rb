# Client gọi cổng thanh toán. Hai thứ quan trọng: TIMEOUT (không được treo theo dịch vụ bên ngoài)
# và một lỗi duy nhất (PaymentDown) để app xử lý, bất kể nguyên nhân là mạng, timeout hay HTTP 500.
require "net/http"
require "json"

module Payment
  URL = ENV.fetch("PAYMENT_URL", "http://localhost:8083/charge")
  TIMEOUT = 2

  class Down < StandardError; end

  def self.charge(amount)
    uri = URI(URL)
    res = Net::HTTP.start(uri.host, uri.port, open_timeout: TIMEOUT, read_timeout: TIMEOUT) do |http|
      http.post(uri.path, URI.encode_www_form(amount: amount))
    end
    raise Down, "cổng thanh toán trả #{res.code}" unless res.code == "200"
    JSON.parse(res.body)
  rescue SystemCallError, Net::OpenTimeout, Net::ReadTimeout, IOError => e
    raise Down, "không gọi được cổng thanh toán (#{e.class})"
  end

  # Cho /healthz: còn gọi được không, nhưng chỉ chờ 1 giây và không bao giờ raise.
  def self.reachable?
    uri = URI(URL)
    Net::HTTP.start(uri.host, uri.port, open_timeout: 1, read_timeout: 1) { |h| h.get("/healthz").code == "200" }
  rescue StandardError
    false
  end
end
