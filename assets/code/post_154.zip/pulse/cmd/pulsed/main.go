// pulsed: server của Pulse, cung cấp HTTP API.
package main

import (
	"context"
	"errors"
	"flag"
	"log/slog"
	"net/http"
	"os"
	"os/signal"
	"syscall"
	"time"

	"github.com/thachnguyenp/pulse/internal/api"
	"github.com/thachnguyenp/pulse/internal/checker"
	"github.com/thachnguyenp/pulse/internal/store"
)

func main() {
	addr := flag.String("addr", ":3000", "địa chỉ lắng nghe")
	flag.Parse()

	if err := run(*addr); err != nil {
		slog.Error("server dừng vì lỗi", "error", err)
		os.Exit(1)
	}
}

func run(addr string) error {
	monitors := store.NewMemory()
	server := api.New(monitors, checker.New(10*time.Second))

	srv := &http.Server{
		Addr:              addr,
		Handler:           server.Handler(),
		ReadHeaderTimeout: 5 * time.Second,
	}

	// Chạy server trong goroutine riêng để main còn chờ tín hiệu tắt.
	errCh := make(chan error, 1)
	go func() {
		slog.Info("pulsed đang chạy", "addr", addr)
		errCh <- srv.ListenAndServe()
	}()

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	select {
	case err := <-errCh:
		return err
	case <-ctx.Done():
		slog.Info("đang tắt, chờ request dở dang...")
	}

	// Cho request đang chạy tối đa 10 giây để xong, rồi mới tắt hẳn.
	shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
	defer cancel()
	if err := srv.Shutdown(shutdownCtx); err != nil && !errors.Is(err, context.DeadlineExceeded) {
		return err
	}
	slog.Info("đã tắt")
	return nil
}
