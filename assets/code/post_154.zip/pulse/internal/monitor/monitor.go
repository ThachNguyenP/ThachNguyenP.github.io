// Package monitor định nghĩa "monitor": một URL cần theo dõi định kỳ.
package monitor

import (
	"context"
	"errors"
	"net/url"
	"strings"
	"time"
)

// ErrNotFound trả về khi không có monitor với id đó.
var ErrNotFound = errors.New("monitor not found")

// Monitor là một URL cần kiểm tra mỗi Interval giây.
type Monitor struct {
	ID        int64     `json:"id"`
	Name      string    `json:"name"`
	URL       string    `json:"url"`
	Interval  int       `json:"interval_seconds"`
	CreatedAt time.Time `json:"created_at"`
}

// Validate kiểm tra dữ liệu người dùng gửi lên. Trả về map rỗng nếu hợp lệ.
func (m *Monitor) Validate() map[string]string {
	problems := map[string]string{}

	m.Name = strings.TrimSpace(m.Name)
	if m.Name == "" {
		problems["name"] = "không được để trống"
	} else if len(m.Name) > 100 {
		problems["name"] = "tối đa 100 ký tự"
	}

	m.URL = strings.TrimSpace(m.URL)
	u, err := url.ParseRequestURI(m.URL)
	if err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Host == "" {
		problems["url"] = "phải là URL đầy đủ, bắt đầu bằng http:// hoặc https://"
	}

	if m.Interval == 0 {
		m.Interval = 60
	}
	if m.Interval < 10 || m.Interval > 3600 {
		problems["interval_seconds"] = "từ 10 đến 3600 giây"
	}
	return problems
}

// Store là nơi lưu monitor. Bài này lưu trong bộ nhớ, bài sau lưu PostgreSQL.
type Store interface {
	Create(ctx context.Context, m *Monitor) error
	List(ctx context.Context) ([]Monitor, error)
	Get(ctx context.Context, id int64) (Monitor, error)
	Delete(ctx context.Context, id int64) error
}
