package api

import (
	"errors"
	"net/http"
	"strconv"

	"github.com/thachnguyenp/pulse/internal/monitor"
)

func (s *Server) listMonitors(w http.ResponseWriter, r *http.Request) {
	list, err := s.monitors.List(r.Context())
	if err != nil {
		writeError(w, http.StatusInternalServerError, "không lấy được danh sách")
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) createMonitor(w http.ResponseWriter, r *http.Request) {
	var m monitor.Monitor
	if err := readJSON(r, &m); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	if problems := m.Validate(); len(problems) > 0 {
		writeValidation(w, problems)
		return
	}
	if err := s.monitors.Create(r.Context(), &m); err != nil {
		writeError(w, http.StatusInternalServerError, "không lưu được")
		return
	}
	writeJSON(w, http.StatusCreated, m)
}

func (s *Server) getMonitor(w http.ResponseWriter, r *http.Request) {
	m, ok := s.findMonitor(w, r)
	if !ok {
		return
	}
	writeJSON(w, http.StatusOK, m)
}

func (s *Server) deleteMonitor(w http.ResponseWriter, r *http.Request) {
	m, ok := s.findMonitor(w, r)
	if !ok {
		return
	}
	if err := s.monitors.Delete(r.Context(), m.ID); err != nil {
		writeError(w, http.StatusInternalServerError, "không xóa được")
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// checkMonitor kiểm tra ngay lập tức, không chờ lịch.
func (s *Server) checkMonitor(w http.ResponseWriter, r *http.Request) {
	m, ok := s.findMonitor(w, r)
	if !ok {
		return
	}
	result := s.checker.Check(r.Context(), m.URL)
	writeJSON(w, http.StatusOK, result)
}

// findMonitor đọc {id} trên URL và tìm monitor. Tự trả lỗi 400/404 nếu cần.
func (s *Server) findMonitor(w http.ResponseWriter, r *http.Request) (monitor.Monitor, bool) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		writeError(w, http.StatusBadRequest, "id phải là số")
		return monitor.Monitor{}, false
	}
	m, err := s.monitors.Get(r.Context(), id)
	if errors.Is(err, monitor.ErrNotFound) {
		writeError(w, http.StatusNotFound, "không có monitor này")
		return monitor.Monitor{}, false
	}
	if err != nil {
		writeError(w, http.StatusInternalServerError, "lỗi đọc dữ liệu")
		return monitor.Monitor{}, false
	}
	return m, true
}
