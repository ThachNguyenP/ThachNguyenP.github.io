// Package store chứa các cách lưu dữ liệu.
package store

import (
	"context"
	"sort"
	"sync"
	"time"

	"github.com/thachnguyenp/pulse/internal/monitor"
)

// Memory lưu monitor trong một map. Mất hết khi tắt chương trình.
type Memory struct {
	mu     sync.Mutex
	nextID int64
	items  map[int64]monitor.Monitor
}

// NewMemory tạo store rỗng.
func NewMemory() *Memory {
	return &Memory{nextID: 1, items: map[int64]monitor.Monitor{}}
}

func (s *Memory) Create(ctx context.Context, m *monitor.Monitor) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	m.ID = s.nextID
	m.CreatedAt = time.Now()
	s.nextID++
	s.items[m.ID] = *m
	return nil
}

func (s *Memory) List(ctx context.Context) ([]monitor.Monitor, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	list := make([]monitor.Monitor, 0, len(s.items))
	for _, m := range s.items {
		list = append(list, m)
	}
	sort.Slice(list, func(i, j int) bool { return list[i].ID < list[j].ID })
	return list, nil
}

func (s *Memory) Get(ctx context.Context, id int64) (monitor.Monitor, error) {
	s.mu.Lock()
	defer s.mu.Unlock()

	m, ok := s.items[id]
	if !ok {
		return monitor.Monitor{}, monitor.ErrNotFound
	}
	return m, nil
}

func (s *Memory) Delete(ctx context.Context, id int64) error {
	s.mu.Lock()
	defer s.mu.Unlock()

	if _, ok := s.items[id]; !ok {
		return monitor.ErrNotFound
	}
	delete(s.items, id)
	return nil
}
