import { ConflictException, UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { Test } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import * as bcrypt from 'bcrypt';
import { AuthService } from './auth.service';
import { User } from './user.entity';

const mockRepository = () => ({
  findOne: jest.fn(),
  create: jest.fn((data: Partial<User>) => data),
  save: jest.fn(),
});
const mockJwt = () => ({ signAsync: jest.fn().mockResolvedValue('signed.jwt.token') });

describe('AuthService', () => {
  let service: AuthService;
  let repo: ReturnType<typeof mockRepository>;
  let jwt: ReturnType<typeof mockJwt>;

  beforeEach(async () => {
    const module = await Test.createTestingModule({
      providers: [
        AuthService,
        { provide: getRepositoryToken(User), useFactory: mockRepository },
        { provide: JwtService, useFactory: mockJwt },
      ],
    }).compile();
    service = module.get(AuthService);
    repo = module.get(getRepositoryToken(User));
    jwt = module.get(JwtService);
  });

  describe('signUp', () => {
    it('stores a bcrypt hash, never the password', async () => {
      repo.save.mockImplementation((u: User) => Promise.resolve(Object.assign(u, { id: 1 })));

      await service.signUp({ username: 'nolan', password: 'Secret123' });

      const saved = repo.save.mock.calls[0][0] as User;
      expect(saved.passwordHash).not.toBe('Secret123');
      expect(await bcrypt.compare('Secret123', saved.passwordHash)).toBe(true);
    });

    it('maps the Postgres unique violation to 409 Conflict', async () => {
      repo.save.mockRejectedValue({ code: '23505' });

      await expect(service.signUp({ username: 'nolan', password: 'Secret123' })).rejects.toThrow(
        ConflictException,
      );
    });
  });

  describe('signIn', () => {
    it('returns a token for the right password', async () => {
      repo.findOne.mockResolvedValue({
        id: 1,
        username: 'nolan',
        passwordHash: await bcrypt.hash('Secret123', 4),
      });

      const result = await service.signIn({ username: 'nolan', password: 'Secret123' });

      expect(result).toEqual({ accessToken: 'signed.jwt.token' });
      expect(jwt.signAsync).toHaveBeenCalledWith({ sub: 1, username: 'nolan' });
    });

    it('rejects a wrong password and an unknown user with the same error', async () => {
      repo.findOne.mockResolvedValueOnce({
        id: 1,
        username: 'nolan',
        passwordHash: await bcrypt.hash('Secret123', 4),
      });
      await expect(service.signIn({ username: 'nolan', password: 'Wrong1234' })).rejects.toThrow(
        UnauthorizedException,
      );

      repo.findOne.mockResolvedValueOnce(null);
      await expect(service.signIn({ username: 'ghost', password: 'Secret123' })).rejects.toThrow(
        UnauthorizedException,
      );
    });
  });
});
