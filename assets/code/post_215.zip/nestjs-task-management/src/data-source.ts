import { config } from 'dotenv';
import { DataSource } from 'typeorm';

// Used by the TypeORM CLI only (migration:generate / migration:run).
// It reads the same .env files as the app, so both always point at the same database.
if (process.env.NODE_ENV) config({ path: `.env.${process.env.NODE_ENV}` });
config(); // .env fills in whatever is still missing (dotenv never overrides)
export const AppDataSource = new DataSource({
  type: 'postgres',
  host: process.env.DB_HOST,
  port: Number(process.env.DB_PORT ?? 5432),
  username: process.env.DB_USERNAME,
  password: process.env.DB_PASSWORD,
  database: process.env.DB_NAME,
  entities: ['src/**/*.entity.ts'],
  migrations: ['src/migrations/**/*.ts'],
  synchronize: false,
});
