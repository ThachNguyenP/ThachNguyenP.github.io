import { NestFactory } from '@nestjs/core';
import { Logger } from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { DocumentBuilder, SwaggerModule } from '@nestjs/swagger';
import helmet from 'helmet';
import { AppModule } from './app.module';
import { configureApp } from './app.setup';

async function bootstrap() {
  const app = configureApp(await NestFactory.create(AppModule));
  const config = app.get(ConfigService);

  // Security headers (no sniffing, no framing, strict transport, ...).
  app.use(helmet());
  // Which browser origins may call this API. "*" is fine for a public API or local dev.
  app.enableCors({ origin: config.get<string>('CORS_ORIGIN', '*') });
  // On SIGTERM (docker stop, Kubernetes), finish in-flight requests and close the DB pool.
  app.enableShutdownHooks();

  // Interactive API docs at /docs, generated from controllers and DTOs.
  const document = SwaggerModule.createDocument(
    app,
    new DocumentBuilder()
      .setTitle('Task Management API')
      .setDescription('NestJS series on thachnguyenp.github.io')
      .setVersion('1.0')
      .addBearerAuth() // the "Authorize" button for JWT
      .build(),
  );
  SwaggerModule.setup('docs', app, document);

  const port = config.get<number>('PORT', 3000);
  await app.listen(port);
  Logger.log(
    `Listening on http://localhost:${port} (${config.get('NODE_ENV')}), docs at /docs`,
    'Bootstrap',
  );
}
void bootstrap();
