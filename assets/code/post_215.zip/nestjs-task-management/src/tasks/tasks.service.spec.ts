import { NotFoundException } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { Test } from '@nestjs/testing';
import { getRepositoryToken } from '@nestjs/typeorm';
import { Task } from './task.entity';
import { TaskStatus } from './task.model';
import { TasksService } from './tasks.service';
import { User } from '../auth/user.entity';

// A fake repository: every method is a jest.fn() we control per test.
// No database, so these tests run in milliseconds.
const mockRepository = () => ({
  findOne: jest.fn(),
  create: jest.fn(),
  save: jest.fn(),
  remove: jest.fn(),
  createQueryBuilder: jest.fn(),
});
const mockEvents = () => ({ emit: jest.fn() });

const user = { id: 7, username: 'nolan' } as User;
const task: Task = {
  id: 1,
  title: 'Học NestJS',
  description: 'bài 214',
  status: TaskStatus.OPEN,
  userId: user.id,
  user,
};

describe('TasksService', () => {
  let service: TasksService;
  let repo: ReturnType<typeof mockRepository>;
  let events: ReturnType<typeof mockEvents>;

  beforeEach(async () => {
    const module = await Test.createTestingModule({
      providers: [
        TasksService,
        { provide: getRepositoryToken(Task), useFactory: mockRepository },
        { provide: EventEmitter2, useFactory: mockEvents },
      ],
    }).compile();

    service = module.get(TasksService);
    repo = module.get(getRepositoryToken(Task));
    events = module.get(EventEmitter2);
  });

  describe('getTaskById', () => {
    it('returns the task when it belongs to the user', async () => {
      repo.findOne.mockResolvedValue(task);

      await expect(service.getTaskById(1, user)).resolves.toEqual(task);
      // the query must always be scoped to the current user
      expect(repo.findOne).toHaveBeenCalledWith({ where: { id: 1, userId: 7 } });
    });

    it('throws NotFoundException when nothing matches', async () => {
      repo.findOne.mockResolvedValue(null);

      await expect(service.getTaskById(99, user)).rejects.toThrow(NotFoundException);
    });
  });

  describe('createTask', () => {
    it('saves with status OPEN and the owner id, then publishes task.created', async () => {
      repo.create.mockImplementation((data: Partial<Task>) => data);
      repo.save.mockImplementation((data: Task) => Promise.resolve({ ...data, id: 5 }));

      const result = await service.createTask({ title: 'A', description: 'B' }, user);

      expect(repo.create).toHaveBeenCalledWith({
        title: 'A',
        description: 'B',
        status: TaskStatus.OPEN,
        userId: 7,
      });
      expect(result.id).toBe(5);
      expect(events.emit).toHaveBeenCalledWith('task.created', {
        name: 'task.created',
        task: result,
      });
    });
  });

  describe('updateTaskStatus', () => {
    it('changes the status and publishes task.updated', async () => {
      repo.findOne.mockResolvedValue({ ...task });
      repo.save.mockImplementation((data: Task) => Promise.resolve(data));

      const result = await service.updateTaskStatus(1, { status: TaskStatus.DONE }, user);

      expect(result.status).toBe(TaskStatus.DONE);
      expect(events.emit).toHaveBeenCalledWith('task.updated', expect.objectContaining({ name: 'task.updated' }));
    });

    it('does not touch the database when the task is not ours', async () => {
      repo.findOne.mockResolvedValue(null);

      await expect(
        service.updateTaskStatus(1, { status: TaskStatus.DONE }, user),
      ).rejects.toThrow(NotFoundException);
      expect(repo.save).not.toHaveBeenCalled();
      expect(events.emit).not.toHaveBeenCalled();
    });
  });

  describe('getTasks', () => {
    it('always filters by the current user and adds status/search when given', async () => {
      // createQueryBuilder returns a chainable object; every method returns itself.
      const qb = {
        where: jest.fn().mockReturnThis(),
        andWhere: jest.fn().mockReturnThis(),
        orderBy: jest.fn().mockReturnThis(),
        getMany: jest.fn().mockResolvedValue([task]),
      };
      repo.createQueryBuilder.mockReturnValue(qb);

      const result = await service.getTasks({ status: TaskStatus.OPEN, search: 'nest' }, user);

      expect(result).toEqual([task]);
      expect(qb.where).toHaveBeenCalledWith('task.userId = :userId', { userId: 7 });
      expect(qb.andWhere).toHaveBeenCalledWith('task.status = :status', { status: 'OPEN' });
      expect(qb.andWhere).toHaveBeenCalledWith('task.title ILIKE :search', { search: '%nest%' });
    });
  });
});
