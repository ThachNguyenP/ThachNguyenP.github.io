import { INestApplication } from '@nestjs/common';
import { Test } from '@nestjs/testing';
import request from 'supertest';
import { App } from 'supertest/types';
import { DataSource } from 'typeorm';
import { AppModule } from '../src/app.module';
import { configureApp } from '../src/app.setup';

// Boots the whole app (real modules, real Postgres from .env.test) and talks
// to it over HTTP, exactly like a frontend would.
describe('Tasks (e2e)', () => {
  let app: INestApplication<App>;
  let http: App;

  const signUpAndIn = async (username: string, password = 'Secret123') => {
    await request(http).post('/auth/signup').send({ username, password }).expect(201);
    const res = await request(http).post('/auth/signin').send({ username, password }).expect(200);
    return `Bearer ${res.body.accessToken as string}`;
  };

  beforeAll(async () => {
    const moduleRef = await Test.createTestingModule({ imports: [AppModule] }).compile();
    app = configureApp(moduleRef.createNestApplication<INestApplication<App>>());
    await app.init();
    http = app.getHttpServer();

    // Start from an empty database every run (schema comes from migrations, see pretest:e2e).
    await app.get(DataSource).query('TRUNCATE "tasks", "users" RESTART IDENTITY CASCADE');
  });

  afterAll(async () => {
    await app.close();
  });

  it('rejects requests without a token', async () => {
    const res = await request(http).get('/tasks').expect(401);
    expect(res.body).toMatchObject({ statusCode: 401, error: 'Unauthorized', path: '/tasks' });
    expect(res.body.requestId).toBeDefined();
  });

  it('validates the body and names every problem', async () => {
    const token = await signUpAndIn('nolan');
    const res = await request(http)
      .post('/tasks')
      .set('Authorization', token)
      .send({ title: '', isAdmin: true })
      .expect(400);

    expect(res.body.message).toEqual(
      expect.arrayContaining([
        'title should not be empty',
        'description should not be empty',
        'property isAdmin should not exist',
      ]),
    );
  });

  it('lets a user create, list, update and delete their own tasks', async () => {
    const token = await signUpAndIn('alice');

    const created = await request(http)
      .post('/tasks')
      .set('Authorization', token)
      .send({ title: 'Write tests', description: 'post 214' })
      .expect(201);
    expect(created.body).toMatchObject({ title: 'Write tests', status: 'OPEN', userId: 2 });

    const list = await request(http).get('/tasks').set('Authorization', token).expect(200);
    expect(list.body).toHaveLength(1);

    const updated = await request(http)
      .put(`/tasks/${created.body.id}`)
      .set('Authorization', token)
      .send({ status: 'DONE' })
      .expect(200);
    expect(updated.body.status).toBe('DONE');

    await request(http).delete(`/tasks/${created.body.id}`).set('Authorization', token).expect(200);
    await request(http).get(`/tasks/${created.body.id}`).set('Authorization', token).expect(404);
  });

  it('never shows one user the tasks of another', async () => {
    const bob = await signUpAndIn('bobby');
    const carol = await signUpAndIn('carol');

    const bobsTask = await request(http)
      .post('/tasks')
      .set('Authorization', bob)
      .send({ title: 'Secret plan', description: 'bob only' })
      .expect(201);

    const carolsList = await request(http).get('/tasks').set('Authorization', carol).expect(200);
    expect(carolsList.body).toEqual([]);

    await request(http).get(`/tasks/${bobsTask.body.id}`).set('Authorization', carol).expect(404);
    await request(http).delete(`/tasks/${bobsTask.body.id}`).set('Authorization', carol).expect(404);

    // still there for its owner
    await request(http).get(`/tasks/${bobsTask.body.id}`).set('Authorization', bob).expect(200);
  });

  it('never leaks the password hash', async () => {
    const token = await signUpAndIn('dave1');
    const me = await request(http).get('/auth/me').set('Authorization', token).expect(200);
    expect(me.body.username).toBe('dave1');
    expect(me.body.passwordHash).toBeUndefined();
  });
});
