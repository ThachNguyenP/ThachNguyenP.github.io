package store

import (
	"context"
	"errors"

	"github.com/jackc/pgx/v5"

	"github.com/thachnguyenp/pulse/internal/monitor"
)

func (s *Postgres) Create(ctx context.Context, m *monitor.Monitor) error {
	return s.pool.QueryRow(ctx, `
		INSERT INTO monitors (name, url, interval_seconds)
		VALUES ($1, $2, $3)
		RETURNING id, created_at`,
		m.Name, m.URL, m.Interval,
	).Scan(&m.ID, &m.CreatedAt)
}

func (s *Postgres) List(ctx context.Context) ([]monitor.Monitor, error) {
	rows, err := s.pool.Query(ctx, `
		SELECT id, name, url, interval_seconds, created_at
		FROM monitors
		ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	list := []monitor.Monitor{}
	for rows.Next() {
		var m monitor.Monitor
		if err := rows.Scan(&m.ID, &m.Name, &m.URL, &m.Interval, &m.CreatedAt); err != nil {
			return nil, err
		}
		list = append(list, m)
	}
	return list, rows.Err()
}

func (s *Postgres) Get(ctx context.Context, id int64) (monitor.Monitor, error) {
	var m monitor.Monitor
	err := s.pool.QueryRow(ctx, `
		SELECT id, name, url, interval_seconds, created_at
		FROM monitors
		WHERE id = $1`, id,
	).Scan(&m.ID, &m.Name, &m.URL, &m.Interval, &m.CreatedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return monitor.Monitor{}, monitor.ErrNotFound
	}
	return m, err
}

func (s *Postgres) Delete(ctx context.Context, id int64) error {
	tag, err := s.pool.Exec(ctx, `DELETE FROM monitors WHERE id = $1`, id)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return monitor.ErrNotFound
	}
	return nil
}
