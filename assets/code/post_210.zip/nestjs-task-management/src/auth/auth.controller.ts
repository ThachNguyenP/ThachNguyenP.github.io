import { Body, Controller, HttpCode, Post } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthCredentialsDto } from './dto/auth-credentials.dto';

@Controller('auth')
export class AuthController {
  constructor(private authService: AuthService) {}

  @Post('signup')
  signUp(@Body() dto: AuthCredentialsDto) {
    return this.authService.signUp(dto);
  }

  @Post('signin')
  @HttpCode(200) // nothing is created, so 200 instead of the POST default 201
  signIn(@Body() dto: AuthCredentialsDto) {
    return this.authService.signIn(dto);
  }
}
