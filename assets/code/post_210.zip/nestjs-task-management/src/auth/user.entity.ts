import {
  Column,
  CreateDateColumn,
  Entity,
  PrimaryGeneratedColumn,
} from 'typeorm';

@Entity('users')
export class User {
  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  username: string;

  // Never the raw password: only the bcrypt hash is stored.
  @Column()
  passwordHash: string;

  @CreateDateColumn()
  createdAt: Date;
}
