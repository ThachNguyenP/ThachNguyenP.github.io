// lib/session.ts
import { headers } from "next/headers";
import { auth } from "./auth";

// Đọc phiên đăng nhập ở Server Component / Server Action. Trả về null nếu chưa đăng nhập.
export async function getSession() {
  return auth.api.getSession({ headers: await headers() });
}
