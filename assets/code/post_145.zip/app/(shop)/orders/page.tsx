import Link from "next/link";
import { redirect } from "next/navigation";
import { prisma } from "@/lib/db";
import { formatPrice } from "@/lib/products";
import { getSession } from "@/lib/session";
import styles from "./page.module.css";

const STATUS_LABEL: Record<string, string> = { pending: "Chờ xác nhận", shipping: "Đang giao", done: "Đã giao", cancelled: "Đã hủy" };

export default async function OrdersPage() {
  const session = await getSession();
  if (!session) redirect("/login");

  const orders = await prisma.order.findMany({
    where: { userId: session.user.id },
    orderBy: { createdAt: "desc" },
    include: { items: true },
  });

  return (
    <>
      <h1 className={styles.title}>Đơn hàng của {session.user.name}</h1>
      {orders.length === 0 ? (
        <p className={styles.empty}>Bạn chưa có đơn nào. <Link href="/products">Mua sắm ngay</Link></p>
      ) : (
        <ul className={styles.list}>
          {orders.map((order) => (
            <li key={order.id} className={styles.item}>
              <div>
                <Link href={`/orders/${order.id}`} className={styles.code}>Đơn #{order.id}</Link>
                <p className={styles.meta}>{order.createdAt.toLocaleDateString("vi-VN")} · {order.items.length} sản phẩm</p>
              </div>
              <span className={`${styles.status} ${styles[order.status]}`}>{STATUS_LABEL[order.status] ?? order.status}</span>
              <strong>{formatPrice(order.total)}</strong>
            </li>
          ))}
        </ul>
      )}
    </>
  );
}
