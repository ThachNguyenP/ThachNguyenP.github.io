# API gateway: cửa duy nhất cho bên ngoài. Chỉ mở những route công khai, gắn request id,
# chia tải vòng tròn (round-robin) lên nhiều instance, và GET lỗi kết nối thì thử instance khác.
# Chạy: ruby services/gateway.rb
require "sinatra"
require "net/http"
require_relative "../lib/web"

Log.service = "gateway"
set :server, :puma
set :port, ENV.fetch("PORT", 8080).to_i
set :server_settings, { Threads: "0:16" } # gateway chỉ chờ mạng, cần nhiều thread hơn mặc định (5) của Puma
set :logging, false
use Web::RequestLog
helpers Web::Helpers

# Một service phía sau với một hoặc nhiều địa chỉ, ví dụ
# CATALOG_URL=http://localhost:8081,http://localhost:8091,http://localhost:8092
class Backend
  attr_reader :name, :urls

  def initialize(name, urls)
    @name = name
    @urls = urls.split(",")
    @counter = 0
    @mutex = Mutex.new
  end

  # Thứ tự instance để thử cho request này: bắt đầu từ instance kế tiếp (round-robin), rồi vòng qua các instance còn lại.
  def candidates
    start = @mutex.synchronize { @counter += 1 }
    @urls.rotate(start % @urls.size)
  end
end

CATALOG = Backend.new("catalog", ENV.fetch("CATALOG_URL", "http://localhost:8081"))
ORDER = Backend.new("order", ENV.fetch("ORDER_URL", "http://localhost:8082"))
REPORT = Backend.new("report", ENV.fetch("REPORT_URL", "http://localhost:8085"))

helpers do
  # Kết nối keep-alive tới từng instance, mỗi thread một bộ. Mở kết nối mới cho mỗi request
  # thì vài nghìn request/giây là cạn cổng TCP của máy.
  def http_for(uri)
    key = "http:#{uri.host}:#{uri.port}"
    http = Thread.current[key]
    return http if http&.started?

    Thread.current[key] = Net::HTTP.start(uri.host, uri.port, open_timeout: 2, read_timeout: 10)
  end

  def drop_http(uri)
    Thread.current["http:#{uri.host}:#{uri.port}"]&.finish
  rescue StandardError
    nil
  ensure
    Thread.current["http:#{uri.host}:#{uri.port}"] = nil
  end

  def forward(backend)
    body = request.body.read # đọc sẵn để có thể gửi lại cho instance khác
    backend.candidates.each_with_index do |base, i|
      uri = URI(base + request.fullpath)
      req = (request.get? ? Net::HTTP::Get : Net::HTTP::Post).new(uri)
      req["Content-Type"] = request.content_type if request.content_type
      req["X-Request-ID"] = env["HTTP_X_REQUEST_ID"]
      req.body = body if request.post?
      begin
        res = http_for(uri).request(req)
      rescue SystemCallError, IOError, Net::OpenTimeout, Net::ReadTimeout => e
        # Không kết nối được: với GET thì thử instance kế tiếp. POST thì KHÔNG, vì không biết
        # instance kia đã xử lý tới đâu.
        drop_http(uri)
        Log.warn("instance lỗi", backend: backend.name, url: base, err: e.message)
        next if request.get? && i < backend.urls.size - 1
        json_error 502, "#{backend.name} không trả lời"
      end
      content_type :json
      halt res.code.to_i, res.body
    end
  end
end

get "/healthz" do
  json_body 200, status: "ok"
end

# Chỉ những route này ra ngoài. /products/:id/reserve hay /events là chuyện nội bộ.
get("/products") { forward CATALOG }
get("/products/:id") { forward CATALOG }
post("/orders") { forward ORDER }
get("/orders/:id") { forward ORDER }
get("/report") { forward REPORT }

not_found do
  json_error 404, "không có route này"
end

Log.info("gateway chạy", catalog: CATALOG.urls.join(","))
