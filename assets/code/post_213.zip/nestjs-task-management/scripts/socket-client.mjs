// A tiny "frontend": signs in, opens a socket with the token, prints every task event.
//   node scripts/socket-client.mjs <username> <password> [http://localhost:3100]
import { io } from 'socket.io-client';

const [username, password, base = 'http://localhost:3100'] = process.argv.slice(2);

const res = await fetch(`${base}/auth/signin`, {
  method: 'POST',
  headers: { 'content-type': 'application/json' },
  body: JSON.stringify({ username, password }),
});
if (!res.ok) {
  console.error('sign in failed', res.status, await res.text());
  process.exit(1);
}
const { accessToken } = await res.json();

const socket = io(base, { auth: { token: accessToken } });

socket.on('connect', () => console.log(`[${username}] connected as ${socket.id}`));
socket.on('error', (e) => console.log(`[${username}] error`, e));
socket.on('disconnect', (reason) => console.log(`[${username}] disconnected: ${reason}`));

for (const name of ['task.created', 'task.updated', 'task.deleted']) {
  socket.on(name, (task) =>
    console.log(`[${username}] ${name}: #${task.id} "${task.title}" ${task.status}`),
  );
}
