// What we put inside the token. Keep it small: it travels with every request.
export interface JwtPayload {
  sub: number; // user id ("subject" is the JWT standard name)
  username: string;
}
