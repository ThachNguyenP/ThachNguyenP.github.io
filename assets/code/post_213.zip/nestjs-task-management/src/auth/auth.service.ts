import {
  ConflictException,
  Injectable,
  UnauthorizedException,
} from '@nestjs/common';
import { InjectRepository } from '@nestjs/typeorm';
import { JwtService } from '@nestjs/jwt';
import { Repository } from 'typeorm';
import * as bcrypt from 'bcrypt';
import { User } from './user.entity';
import { AuthCredentialsDto } from './dto/auth-credentials.dto';
import { JwtPayload } from './jwt-payload.interface';

@Injectable()
export class AuthService {
  constructor(
    @InjectRepository(User)
    private usersRepository: Repository<User>,
    private jwtService: JwtService,
  ) {}

  async signUp(dto: AuthCredentialsDto): Promise<{ id: number; username: string }> {
    const passwordHash = await bcrypt.hash(dto.password, 10);
    const user = this.usersRepository.create({ username: dto.username, passwordHash });
    try {
      await this.usersRepository.save(user);
    } catch (error) {
      // 23505 = unique_violation in Postgres: the username is taken
      if ((error as { code?: string }).code === '23505') {
        throw new ConflictException('Username already exists');
      }
      throw error;
    }
    return { id: user.id, username: user.username };
  }

  async signIn(dto: AuthCredentialsDto): Promise<{ accessToken: string }> {
    const user = await this.usersRepository.findOne({ where: { username: dto.username } });
    // Same message for "no such user" and "wrong password": don't help attackers
    // find out which usernames exist.
    if (!user || !(await bcrypt.compare(dto.password, user.passwordHash))) {
      throw new UnauthorizedException('Please check your login credentials');
    }
    const payload: JwtPayload = { sub: user.id, username: user.username };
    return { accessToken: await this.jwtService.signAsync(payload) };
  }
}
