import { createParamDecorator, ExecutionContext } from '@nestjs/common';
import { User } from './user.entity';

// JwtStrategy.validate() put the User on request.user.
// @GetUser() hands it to a handler parameter, like @Body() or @Param() do.
export const GetUser = createParamDecorator(
  (_data: unknown, ctx: ExecutionContext): User => {
    const request = ctx.switchToHttp().getRequest<{ user: User }>();
    return request.user;
  },
);
