import { MigrationInterface, QueryRunner } from "typeorm";

export class AddUserToTasks1793966794813 implements MigrationInterface {
    name = 'AddUserToTasks1793966794813'

    public async up(queryRunner: QueryRunner): Promise<void> {
        // 1. add the column as NULLABLE first: the table already has rows
        await queryRunner.query(`ALTER TABLE "tasks" ADD "userId" integer`);
        // 2. give the old rows an owner (the first user), drop any that still have none
        await queryRunner.query(`UPDATE "tasks" SET "userId" = (SELECT MIN("id") FROM "users") WHERE "userId" IS NULL`);
        await queryRunner.query(`DELETE FROM "tasks" WHERE "userId" IS NULL`);
        // 3. now every row has a value, so the constraint can be enforced
        await queryRunner.query(`ALTER TABLE "tasks" ALTER COLUMN "userId" SET NOT NULL`);
        await queryRunner.query(`ALTER TABLE "tasks" ADD CONSTRAINT "FK_166bd96559cb38595d392f75a35" FOREIGN KEY ("userId") REFERENCES "users"("id") ON DELETE CASCADE ON UPDATE NO ACTION`);
    }

    public async down(queryRunner: QueryRunner): Promise<void> {
        await queryRunner.query(`ALTER TABLE "tasks" DROP CONSTRAINT "FK_166bd96559cb38595d392f75a35"`);
        await queryRunner.query(`ALTER TABLE "tasks" DROP COLUMN "userId"`);
    }

}
