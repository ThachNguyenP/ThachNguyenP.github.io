import { Task } from './task.entity';

// Published by TasksService after each write, consumed by TasksGateway.
// The service never knows about sockets: it only says "this happened".
export type TaskEventName = 'task.created' | 'task.updated' | 'task.deleted';

export interface TaskEvent {
  name: TaskEventName;
  task: Task;
}
