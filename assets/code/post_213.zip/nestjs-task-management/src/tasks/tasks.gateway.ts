import { Logger } from '@nestjs/common';
import { OnEvent } from '@nestjs/event-emitter';
import { JwtService } from '@nestjs/jwt';
import {
  OnGatewayConnection,
  OnGatewayDisconnect,
  WebSocketGateway,
  WebSocketServer,
} from '@nestjs/websockets';
import { Server, Socket } from 'socket.io';
import { JwtPayload } from '../auth/jwt-payload.interface';
// "import type": the type is only used in a decorated method signature,
// and TypeScript must not try to emit it as runtime metadata.
import type { TaskEvent } from './task-events';

// One Socket.IO server shared with the HTTP server, on the same port.
@WebSocketGateway({ cors: { origin: '*' } })
export class TasksGateway implements OnGatewayConnection, OnGatewayDisconnect {
  @WebSocketServer() server: Server;
  private readonly logger = new Logger(TasksGateway.name);

  constructor(private jwtService: JwtService) {}

  // Guards do not run on the connection itself, so we check the token here.
  handleConnection(client: Socket) {
    const token = client.handshake.auth?.token as string | undefined;
    try {
      if (!token) throw new Error('missing token');
      const payload = this.jwtService.verify<JwtPayload>(token);
      // Each user gets a private "room": every tab/device of that user joins it.
      void client.join(this.room(payload.sub));
      client.data.username = payload.username;
      this.logger.log(`${payload.username} connected (${client.id})`);
    } catch (err) {
      this.logger.warn(`rejected ${client.id}: ${(err as Error).message}`);
      client.emit('error', { message: 'Unauthorized' });
      client.disconnect(true);
    }
  }

  handleDisconnect(client: Socket) {
    this.logger.log(`${client.data.username ?? 'unknown'} disconnected (${client.id})`);
  }

  // TasksService emits these after each write; we forward them to the owner only.
  @OnEvent('task.*')
  onTaskEvent(event: TaskEvent) {
    this.server.to(this.room(event.task.userId)).emit(event.name, event.task);
  }

  private room(userId: number) {
    return `user:${userId}`;
  }
}
