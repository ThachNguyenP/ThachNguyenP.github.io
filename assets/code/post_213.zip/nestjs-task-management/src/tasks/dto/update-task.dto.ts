import { IsEnum } from 'class-validator';
import { TaskStatus } from '../task.model';

export class UpdateTaskDto {
  // Reject anything that is not OPEN / IN_PROGRESS / DONE before it reaches the database.
  @IsEnum(TaskStatus)
  status: TaskStatus;
}
