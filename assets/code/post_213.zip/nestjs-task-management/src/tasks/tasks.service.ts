import { Injectable, NotFoundException } from '@nestjs/common';
import { EventEmitter2 } from '@nestjs/event-emitter';
import { InjectRepository } from '@nestjs/typeorm';
import { Repository } from 'typeorm';
import { Task } from './task.entity';
import { TaskStatus } from './task.model';
import { TaskEvent } from './task-events';
import { User } from '../auth/user.entity';
import { CreateTaskDto } from './dto/create-task.dto';
import { UpdateTaskDto } from './dto/update-task.dto';
import { FilterTaskDto } from './dto/filter-task.dto';

@Injectable()
export class TasksService {
  constructor(
    @InjectRepository(Task)
    private tasksRepository: Repository<Task>,
    private events: EventEmitter2,
  ) {}

  // Every method receives the current user and only ever touches that user's rows.
  async getTasks(filterTaskDto: FilterTaskDto, user: User): Promise<Task[]> {
    const { status, search } = filterTaskDto;
    const query = this.tasksRepository
      .createQueryBuilder('task')
      .where('task.userId = :userId', { userId: user.id });

    if (status) {
      query.andWhere('task.status = :status', { status });
    }
    if (search) {
      query.andWhere('task.title ILIKE :search', { search: `%${search}%` });
    }

    return query.orderBy('task.id', 'DESC').getMany();
  }

  async getTaskById(id: number, user: User): Promise<Task> {
    const task = await this.tasksRepository.findOne({
      where: { id, userId: user.id },
    });
    if (!task) {
      // 404, not 403: don't reveal that someone else's task exists.
      throw new NotFoundException(`Task with ID "${id}" not found`);
    }
    return task;
  }

  async createTask(createTaskDto: CreateTaskDto, user: User): Promise<Task> {
    const task = this.tasksRepository.create({
      ...createTaskDto,
      status: TaskStatus.OPEN,
      userId: user.id, // the id only, so the response does not carry the user object
    });
    const saved = await this.tasksRepository.save(task);
    this.publish('task.created', saved);
    return saved;
  }

  async deleteTaskById(id: number, user: User): Promise<void> {
    const task = await this.getTaskById(id, user); // 404 if not ours
    await this.tasksRepository.remove(task);
    this.publish('task.deleted', { ...task, id }); // remove() clears id, put it back
  }

  async updateTaskStatus(
    id: number,
    updateTaskDto: UpdateTaskDto,
    user: User,
  ): Promise<Task> {
    const task = await this.getTaskById(id, user); // 404 if not ours
    task.status = updateTaskDto.status;
    const saved = await this.tasksRepository.save(task);
    this.publish('task.updated', saved);
    return saved;
  }

  // Fire and forget: listeners (the gateway today, maybe email tomorrow)
  // run after this method returns, and a failing listener cannot break the request.
  private publish(name: TaskEvent['name'], task: Task) {
    this.events.emit(name, { name, task } satisfies TaskEvent);
  }
}
