import { NestFactory, Reflector } from '@nestjs/core';
import {
  ClassSerializerInterceptor,
  Logger,
  ValidationPipe,
} from '@nestjs/common';
import { ConfigService } from '@nestjs/config';
import { AppModule } from './app.module';
import { AllExceptionsFilter } from './common/filters/all-exceptions.filter';
import { LoggingInterceptor } from './common/interceptors/logging.interceptor';

async function bootstrap() {
  const app = await NestFactory.create(AppModule);

  // Pipes: validate and clean every incoming body / query / param.
  app.useGlobalPipes(
    new ValidationPipe({
      whitelist: true, // drop properties that are not in the DTO
      forbidNonWhitelisted: true, // ...or rather, reject the request if any are present
      transform: true, // "3" in a query string becomes 3 when the DTO says number
    }),
  );

  // Interceptors: run around every handler.
  app.useGlobalInterceptors(
    new ClassSerializerInterceptor(app.get(Reflector)), // honours @Exclude()
    new LoggingInterceptor(),
  );

  // Filters: turn every thrown error into one JSON shape.
  app.useGlobalFilters(new AllExceptionsFilter());

  const config = app.get(ConfigService);
  const port = config.get<number>('PORT', 3000);
  await app.listen(port);
  Logger.log(
    `Listening on http://localhost:${port} (${config.get('NODE_ENV')})`,
    'Bootstrap',
  );
}
void bootstrap();
