import {
  CallHandler,
  ExecutionContext,
  Injectable,
  Logger,
  NestInterceptor,
} from '@nestjs/common';
import { Observable, tap } from 'rxjs';

// Runs around the handler, after guards and pipes. Unlike middleware it knows
// WHICH controller method is running, so it can time the business logic itself.
@Injectable()
export class LoggingInterceptor implements NestInterceptor {
  private readonly logger = new Logger('Handler');

  intercept(context: ExecutionContext, next: CallHandler): Observable<unknown> {
    const handler = `${context.getClass().name}.${context.getHandler().name}`;
    const startedAt = Date.now();
    return next.handle().pipe(
      tap({
        next: () => this.logger.debug(`${handler} ok in ${Date.now() - startedAt}ms`),
        error: (err: Error) =>
          this.logger.debug(`${handler} threw ${err.constructor.name} in ${Date.now() - startedAt}ms`),
      }),
    );
  }
}
