import {
  ArgumentsHost,
  Catch,
  ExceptionFilter,
  HttpException,
  HttpStatus,
  Logger,
} from '@nestjs/common';
import { Request, Response } from 'express';

// One JSON shape for every error, whatever threw it.
export interface ErrorBody {
  statusCode: number;
  error: string;
  message: string | string[];
  path: string;
  timestamp: string;
  requestId?: string;
}

@Catch() // no argument = catch everything, not only HttpException
export class AllExceptionsFilter implements ExceptionFilter {
  private readonly logger = new Logger(AllExceptionsFilter.name);

  catch(exception: unknown, host: ArgumentsHost) {
    const ctx = host.switchToHttp();
    const res = ctx.getResponse<Response>();
    const req = ctx.getRequest<Request>();
    const requestId = res.locals.requestId as string | undefined;

    let statusCode = HttpStatus.INTERNAL_SERVER_ERROR;
    let error = 'Internal Server Error';
    let message: string | string[] = 'Something went wrong';

    if (exception instanceof HttpException) {
      // Thrown on purpose (NotFoundException, ValidationPipe...): safe to show.
      statusCode = exception.getStatus();
      const body = exception.getResponse();
      if (typeof body === 'string') {
        message = body;
      } else {
        const b = body as { error?: string; message?: string | string[] };
        // "UnauthorizedException" -> "Unauthorized" when the body has no error field
        error = b.error ?? exception.name.replace(/Exception$/, '');
        message = b.message ?? exception.message;
      }
    } else {
      // A real bug or an infrastructure failure: log everything, show nothing.
      const err = exception as Error;
      this.logger.error(`${req.method} ${req.originalUrl} [${requestId}] ${err.message}`, err.stack);
    }

    const payload: ErrorBody = {
      statusCode,
      error,
      message,
      path: req.originalUrl,
      timestamp: new Date().toISOString(),
      requestId,
    };
    res.status(statusCode).json(payload);
  }
}
