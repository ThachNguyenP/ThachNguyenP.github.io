"use client";

import { useState } from "react";
import styles from "./add-to-cart.module.css";

type Props = { productName: string; stock: number };

export default function AddToCart({ productName, stock }: Props) {
  const [quantity, setQuantity] = useState(1);
  const [message, setMessage] = useState("");

  console.log("AddToCart render ở trình duyệt");

  if (stock === 0) {
    return <p className={styles.soldOut}>Hết hàng</p>;
  }

  return (
    <div className={styles.box}>
      <div className={styles.picker}>
        <button onClick={() => setQuantity(Math.max(1, quantity - 1))} aria-label="Giảm">−</button>
        <span>{quantity}</span>
        <button onClick={() => setQuantity(Math.min(stock, quantity + 1))} aria-label="Tăng">+</button>
      </div>
      <button className={styles.add} onClick={() => setMessage(`Đã chọn ${quantity} × ${productName} (bài 143 sẽ lưu vào giỏ thật)`)}>
        Thêm vào giỏ
      </button>
      {message && <p className={styles.message}>{message}</p>}
    </div>
  );
}
