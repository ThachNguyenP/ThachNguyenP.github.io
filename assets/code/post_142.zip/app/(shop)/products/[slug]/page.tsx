import Link from "next/link";
import { Suspense } from "react";
import { notFound } from "next/navigation";
import AddToCart from "@/components/add-to-cart";
import RelatedProducts from "@/components/related-products";
import { formatPrice, getProduct, getProducts } from "@/lib/products";
import styles from "./page.module.css";

export async function generateStaticParams() {
  const products = await getProducts();
  return products.map((p) => ({ slug: p.slug }));
}

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await getProduct(slug);

  if (!product) notFound();

  return (
    <>
      <article className={styles.product}>
        <div className={styles.media}>{product.emoji}</div>
        <div>
          <Link href="/products" className={styles.back}>← Tất cả sản phẩm</Link>
          <p className={styles.brand}>{product.brand}</p>
          <h1 className={styles.name}>{product.name}</h1>
          <p className={styles.price}>
            {formatPrice(product.price)}
            {product.oldPrice && <s className={styles.old}>{formatPrice(product.oldPrice)}</s>}
          </p>
          <p className={styles.desc}>{product.description}</p>
          <p className={styles.stock}>{product.stock > 0 ? `Còn ${product.stock} sản phẩm` : "Hết hàng"}</p>
          <AddToCart productName={product.name} stock={product.stock} />
        </div>
      </article>

      <Suspense fallback={<p style={{ marginTop: 64, color: "var(--color-muted)" }}>Đang tìm sản phẩm cùng loại...</p>}>
        <RelatedProducts product={product} />
      </Suspense>
    </>
  );
}
