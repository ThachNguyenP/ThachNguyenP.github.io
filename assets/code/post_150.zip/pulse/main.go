package main

import (
	"fmt"
	"net/http"
	"os"
	"time"
)

func main() {
	if len(os.Args) < 2 {
		fmt.Println("Cách dùng: pulse <url>")
		os.Exit(1)
	}
	url := os.Args[1]

	client := http.Client{Timeout: 5 * time.Second}

	start := time.Now()
	resp, err := client.Get(url)
	if err != nil {
		fmt.Println("DOWN", url, err)
		os.Exit(1)
	}
	defer resp.Body.Close()
	elapsed := time.Since(start)

	fmt.Println("UP", url, resp.StatusCode, elapsed.Round(time.Millisecond))
}
