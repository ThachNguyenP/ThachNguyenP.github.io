# Tạo dữ liệu mẫu: một admin, một khách, 30 sản phẩm. Chạy: bundle exec ruby db/seed.rb
require_relative "../lib/shop"

Shop.db = DB.new(ENV.fetch("DB", "shop.db"), Shop::SCHEMA)
%w[users products orders order_items].each { |t| Shop.db.execute("DELETE FROM #{t}") }

Shop::Users.create(email: "admin@example.com", password: "admin-pass-1", role: "admin")
Shop::Users.create(email: "an@example.com", password: "an-pass-123")

names = %w[Bàn Ghế Đèn Tủ Kệ Gương Thảm Rèm Gối Chăn]
30.times do |i|
  Shop.db.execute("INSERT INTO products (name, price, stock) VALUES (?, ?, ?)",
                  ["#{names[i % 10]} #{%w[gỗ sắt vải][i / 10]} #{i + 1}", (i + 1) * 50_000, 10 + i])
end
puts "Đã tạo #{Shop.db.get_first_value('SELECT COUNT(*) FROM users')} user, #{Shop.db.get_first_value('SELECT COUNT(*) FROM products')} sản phẩm"
