# App web của shop: trang HTML cho người mua, một API JSON nhỏ, và /healthz cho hệ thống giám sát.
require "sinatra"
require "json"
require_relative "lib/shop"

set :server, :puma
set :port, ENV.fetch("PORT", 8080)
set :show_exceptions, :after_handler
enable :sessions
set :session_secret, ENV.fetch("SESSION_SECRET") { "dev-secret-" * 8 }

Shop.db = DB.new(ENV.fetch("DB", "shop.db"), Shop::SCHEMA)

helpers do
  def current_user
    @current_user ||= Shop::Users.get(session[:user_id]) if session[:user_id]
  end

  def require_login!
    redirect "/login?next=#{request.path}" unless current_user
  end

  def require_admin!
    require_login!
    halt 403, erb(:error, locals: { message: "Chỉ admin mới xem được trang này" }) unless current_user["role"] == "admin"
  end

  def money(n) = n.to_s.reverse.scan(/\d{1,3}/).join(".").reverse + " đ"
end

# ---- Trang cho người mua ----
get "/" do
  @q = params[:q]
  @products = Shop::Products.list(@q)
  erb :index
end

get "/products/:id" do
  @product = Shop::Products.get(params[:id])
  erb :product
end

# ---- Đăng ký, đăng nhập ----
get("/register") { erb :register }
post "/register" do
  id = Shop::Users.create(email: params[:email], password: params[:password])
  session[:user_id] = id
  redirect "/"
end

get("/login") { erb :login, locals: { login_error: nil } }
post "/login" do
  user = Shop::Users.authenticate(params[:email], params[:password])
  halt 401, erb(:login, locals: { login_error: "Sai email hoặc mật khẩu" }) unless user
  session[:user_id] = user["id"]
  redirect(params[:next].to_s.start_with?("/") ? params[:next] : "/")
end

post "/logout" do
  session.clear
  redirect "/"
end

# ---- Đơn hàng ----
post "/orders" do
  require_login!
  id = Shop::Orders.create(user_id: current_user["id"], product_id: params[:product_id], qty: params[:qty])
  redirect "/orders/#{id}"
end

get "/orders" do
  require_login!
  @orders = Shop::Orders.for_user(current_user["id"])
  erb :orders
end

get "/orders/:id" do
  require_login!
  @order = Shop::Orders.get(params[:id])
  @items = Shop::Orders.items(@order["id"])
  erb :order
end

get "/admin/orders" do
  require_admin!
  @orders = Shop::Orders.all.map { |o| o.merge("user" => Shop::Users.get(o["user_id"])) }
  erb :admin_orders
end

# ---- API JSON và health check ----
get "/api/products" do
  content_type :json
  JSON.generate(Shop::Products.list(params[:q]))
end

get "/healthz" do
  content_type :json
  Shop.db.get_first_value("SELECT 1")
  JSON.generate(status: "ok", products: Shop.db.get_first_value("SELECT COUNT(*) FROM products"))
end

# ---- Lỗi ----
error Shop::NotFound do |e| halt 404, erb(:error, locals: { message: e.message }) end
error Shop::Invalid, Shop::OutOfStock do |e| halt 422, erb(:error, locals: { message: e.message }) end
not_found { erb :error, locals: { message: "Không có trang này" } }
