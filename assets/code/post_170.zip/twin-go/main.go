// Bản Go của cùng shop (lưu trong bộ nhớ, chỉ dùng thư viện chuẩn) để chứng minh system test không phụ thuộc ngôn ngữ.
// Chạy: cd twin-go && go run . (cổng 8090)
package main

import (
	"crypto/rand"
	"encoding/hex"
	"encoding/json"
	"fmt"
	"net/http"
	"strconv"
	"strings"
	"sync"
)

type Product struct {
	ID    int    `json:"id"`
	Name  string `json:"name"`
	Price int    `json:"price"`
	Stock int    `json:"stock"`
}
type User struct {
	ID              int
	Email, Password string
	Role            string
}
type Order struct {
	ID, UserID, ProductID, Qty, Total int
}

var (
	mu       sync.Mutex
	products []*Product
	users    = map[string]*User{}
	sessions = map[string]*User{}
	orders   []*Order
	nextUser = 1
)

func seed() {
	names := []string{"Bàn", "Ghế", "Đèn", "Tủ", "Kệ", "Gương", "Thảm", "Rèm", "Gối", "Chăn"}
	kinds := []string{"gỗ", "sắt", "vải"}
	for i := 0; i < 30; i++ {
		products = append(products, &Product{i + 1, fmt.Sprintf("%s %s %d", names[i%10], kinds[i/10], i+1), (i + 1) * 50000, 10 + i})
	}
	addUser("admin@example.com", "admin-pass-1", "admin")
	addUser("an@example.com", "an-pass-123", "customer")
}

func addUser(email, pass, role string) *User {
	u := &User{nextUser, email, pass, role}
	nextUser++
	users[email] = u
	return u
}

func money(n int) string {
	s := strconv.Itoa(n)
	var parts []string
	for len(s) > 3 {
		parts = append([]string{s[len(s)-3:]}, parts...)
		s = s[:len(s)-3]
	}
	return strings.Join(append([]string{s}, parts...), ".") + " đ"
}

func page(w http.ResponseWriter, status int, body string) {
	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	w.WriteHeader(status)
	fmt.Fprintf(w, "<!doctype html><html lang=\"vi\"><body><nav><a href=\"/\">Sản phẩm</a></nav><hr>%s</body></html>", body)
}

func currentUser(r *http.Request) *User {
	c, err := r.Cookie("sid")
	if err != nil {
		return nil
	}
	return sessions[c.Value]
}

func setSession(w http.ResponseWriter, u *User) {
	b := make([]byte, 16)
	rand.Read(b)
	sid := hex.EncodeToString(b)
	sessions[sid] = u
	http.SetCookie(w, &http.Cookie{Name: "sid", Value: sid, Path: "/", HttpOnly: true})
}

func main() {
	seed()
	mux := http.NewServeMux()

	mux.HandleFunc("GET /{$}", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		defer mu.Unlock()
		q := strings.ToLower(r.URL.Query().Get("q"))
		var rows strings.Builder
		for _, p := range products {
			if q == "" || strings.Contains(strings.ToLower(p.Name), q) {
				fmt.Fprintf(&rows, "<tr><td><a href=\"/products/%d\">%s</a></td><td>%s</td><td>%d</td></tr>", p.ID, p.Name, money(p.Price), p.Stock)
			}
		}
		page(w, 200, "<h1>Sản phẩm</h1><table>"+rows.String()+"</table>")
	})

	mux.HandleFunc("GET /products/{id}", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		defer mu.Unlock()
		id, _ := strconv.Atoi(r.PathValue("id"))
		if id < 1 || id > len(products) {
			page(w, 404, fmt.Sprintf("<p class=\"error\">không có sản phẩm %d</p>", id))
			return
		}
		p := products[id-1]
		page(w, 200, fmt.Sprintf("<h1>%s</h1><p>Giá: <strong>%s</strong>, còn %d cái</p><form method=\"post\" action=\"/orders\"><input type=\"hidden\" name=\"product_id\" value=\"%d\"><input type=\"number\" name=\"qty\" value=\"1\"><button>Mua</button></form>", p.Name, money(p.Price), p.Stock, p.ID))
	})

	mux.HandleFunc("GET /login", func(w http.ResponseWriter, r *http.Request) {
		page(w, 200, "<h1>Đăng nhập</h1><form method=\"post\" action=\"/login\"><input name=\"email\"><input name=\"password\" type=\"password\"><button>Đăng nhập</button></form>")
	})
	mux.HandleFunc("POST /login", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		defer mu.Unlock()
		u := users[r.FormValue("email")]
		if u == nil || u.Password != r.FormValue("password") {
			page(w, 401, "<p class=\"error\">Sai email hoặc mật khẩu</p>")
			return
		}
		setSession(w, u)
		http.Redirect(w, r, "/", http.StatusSeeOther)
	})
	mux.HandleFunc("POST /register", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		defer mu.Unlock()
		email, pass := r.FormValue("email"), r.FormValue("password")
		if !strings.Contains(email, "@") || len(pass) < 8 {
			page(w, 422, "<p class=\"error\">email hoặc mật khẩu không hợp lệ</p>")
			return
		}
		if users[email] != nil {
			page(w, 422, "<p class=\"error\">email đã tồn tại</p>")
			return
		}
		setSession(w, addUser(email, pass, "customer"))
		http.Redirect(w, r, "/", http.StatusSeeOther)
	})
	mux.HandleFunc("POST /logout", func(w http.ResponseWriter, r *http.Request) {
		http.SetCookie(w, &http.Cookie{Name: "sid", Value: "", Path: "/", MaxAge: -1})
		http.Redirect(w, r, "/", http.StatusSeeOther)
	})

	mux.HandleFunc("POST /orders", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		defer mu.Unlock()
		u := currentUser(r)
		if u == nil {
			http.Redirect(w, r, "/login?next=/orders", http.StatusFound)
			return
		}
		id, _ := strconv.Atoi(r.FormValue("product_id"))
		qty, _ := strconv.Atoi(r.FormValue("qty"))
		if id < 1 || id > len(products) {
			page(w, 404, "<p class=\"error\">không có sản phẩm</p>")
			return
		}
		if qty <= 0 {
			page(w, 422, "<p class=\"error\">số lượng phải lớn hơn 0</p>")
			return
		}
		p := products[id-1]
		if p.Stock < qty {
			page(w, 422, fmt.Sprintf("<p class=\"error\">%s chỉ còn %d</p>", p.Name, p.Stock))
			return
		}
		p.Stock -= qty
		o := &Order{len(orders) + 1, u.ID, p.ID, qty, p.Price * qty}
		orders = append(orders, o)
		http.Redirect(w, r, fmt.Sprintf("/orders/%d", o.ID), http.StatusSeeOther)
	})
	mux.HandleFunc("GET /orders", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		defer mu.Unlock()
		u := currentUser(r)
		if u == nil {
			http.Redirect(w, r, "/login?next=/orders", http.StatusFound)
			return
		}
		var rows strings.Builder
		for _, o := range orders {
			if o.UserID == u.ID {
				fmt.Fprintf(&rows, "<tr><td><a href=\"/orders/%d\">#%d</a></td><td>%s x%d</td><td>%s</td></tr>", o.ID, o.ID, products[o.ProductID-1].Name, o.Qty, money(o.Total))
			}
		}
		body := "<h1>Đơn của tôi</h1>"
		if rows.Len() == 0 {
			body += "<p>Chưa có đơn nào.</p>"
		}
		page(w, 200, body+"<table>"+rows.String()+"</table>")
	})
	mux.HandleFunc("GET /orders/{id}", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		defer mu.Unlock()
		if currentUser(r) == nil {
			http.Redirect(w, r, "/login?next="+r.URL.Path, http.StatusFound)
			return
		}
		id, _ := strconv.Atoi(r.PathValue("id"))
		if id < 1 || id > len(orders) {
			page(w, 404, "<p class=\"error\">không có đơn</p>")
			return
		}
		o := orders[id-1]
		page(w, 200, fmt.Sprintf("<h1>Đơn #%d</h1><table><tr><td>%s</td><td>%d</td></tr></table><p>Tổng: <strong>%s</strong></p>", o.ID, products[o.ProductID-1].Name, o.Qty, money(o.Total)))
	})
	mux.HandleFunc("GET /admin/orders", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		defer mu.Unlock()
		u := currentUser(r)
		if u == nil {
			http.Redirect(w, r, "/login?next=/admin/orders", http.StatusFound)
			return
		}
		if u.Role != "admin" {
			page(w, 403, "<p class=\"error\">Chỉ admin mới xem được trang này</p>")
			return
		}
		page(w, 200, fmt.Sprintf("<h1>Tất cả đơn hàng</h1><p>%d đơn</p>", len(orders)))
	})

	mux.HandleFunc("GET /api/products", func(w http.ResponseWriter, r *http.Request) {
		mu.Lock()
		defer mu.Unlock()
		q := strings.ToLower(r.URL.Query().Get("q"))
		out := []*Product{}
		for _, p := range products {
			if q == "" || strings.Contains(strings.ToLower(p.Name), q) {
				out = append(out, p)
			}
		}
		w.Header().Set("Content-Type", "application/json")
		json.NewEncoder(w).Encode(out)
	})
	mux.HandleFunc("GET /healthz", func(w http.ResponseWriter, r *http.Request) {
		w.Header().Set("Content-Type", "application/json")
		fmt.Fprintf(w, `{"status":"ok","products":%d}`, len(products))
	})
	mux.HandleFunc("/", func(w http.ResponseWriter, r *http.Request) {
		page(w, 404, "<p class=\"error\">Không có trang này</p>")
	})

	fmt.Println("twin-go listening on :8090")
	http.ListenAndServe(":8090", mux)
}
