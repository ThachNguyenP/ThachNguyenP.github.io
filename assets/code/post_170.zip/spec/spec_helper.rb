# Cấu hình cho UNIT test: nạp thẳng code Ruby của app, DB riêng, xóa sạch dữ liệu trước mỗi example.
# (Unit test là loại test duy nhất trong series phụ thuộc ngôn ngữ của hệ thống; các loại còn lại đi qua HTTP.)
ENV["RACK_ENV"] = "test"
ENV["DB"] = "test.db"
File.delete("test.db") if File.exist?("test.db")

require_relative "../lib/shop"
Shop.db = DB.new(ENV["DB"], Shop::SCHEMA)

module UnitHelpers
  def create_user(email: "an@example.com", password: "an-pass-123", role: "customer")
    Shop::Users.create(email: email, password: password, role: role)
  end

  def create_product(name: "Bàn gỗ", price: 100_000, stock: 5)
    Shop.db.execute("INSERT INTO products (name, price, stock) VALUES (?, ?, ?)", [name, price, stock])
    Shop.db.last_insert_row_id
  end
end

RSpec.configure do |c|
  c.include UnitHelpers
  c.before(:each) do
    %w[order_items orders products users].each { |t| Shop.db.execute("DELETE FROM #{t}") }
  end
end
