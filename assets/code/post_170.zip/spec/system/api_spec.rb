# API contract: hình dạng JSON mà client (app mobile, frontend) đang dựa vào. Đổi là vỡ, nên phải có test.
require_relative "system_helper"

RSpec.describe "API /api/products" do
  it "trả JSON, mỗi sản phẩm có đủ id, name, price, stock đúng kiểu" do
    client.get("/api/products")
    expect(client.last.code).to eq("200")
    expect(client.last["content-type"]).to include("application/json")
    list = client.json
    expect(list).not_to be_empty
    list.each do |p|
      expect(p).to include("id" => Integer, "name" => String, "price" => Integer, "stock" => Integer)
    end
  end

  it "?q= lọc theo tên, không phân biệt hoa thường" do
    name = product(1)["name"]
    client.get("/api/products?q=#{URI.encode_www_form_component(name.downcase)}")
    expect(client.json.map { |p| p["id"] }).to include(1)
    client.get("/api/products?q=khong-co-san-pham-nao-ten-nay")
    expect(client.json).to eq([])
  end
end
