# Smoke: những trang mà nếu hỏng thì không cần test gì thêm nữa.
require_relative "system_helper"

RSpec.describe "Smoke" do
  it "/healthz trả ok" do
    client.get("/healthz")
    expect(client.last.code).to eq("200")
    expect(client.json["status"]).to eq("ok")
  end

  it "trang chủ liệt kê sản phẩm" do
    client.get("/")
    expect(client.last.code).to eq("200")
    expect(client.last.body).to include("<h1>Sản phẩm</h1>")
    expect(client.last.body).to include("/products/1")
  end

  it "trang sản phẩm có nút Mua" do
    client.get("/products/1")
    expect(client.last.body).to include("Mua")
  end

  it "đường dẫn lạ trả 404 bằng trang lỗi của app, không phải trang mặc định của server" do
    client.get("/khong-co")
    expect(client.last.code).to eq("404")
    expect(client.last.body).to include("Không có trang này")
  end

  it "sản phẩm không tồn tại trả 404" do
    client.get("/products/999999")
    expect(client.last.code).to eq("404")
  end
end
