# Luồng mua hàng, nghiệp vụ quan trọng nhất của shop: đặt đơn, xem đơn, tồn kho giảm, không mua quá tồn kho.
require_relative "system_helper"

RSpec.describe "Mua hàng" do
  before { register }

  it "mua 2 cái: đơn hiện đúng sản phẩm và tổng tiền, tồn kho giảm 2" do
    before = product(1)
    client.post("/orders", product_id: 1, qty: 2)
    expect(client.last).to be_a(Net::HTTPRedirection)
    order_path = URI(client.last["location"]).path
    expect(order_path).to match(%r{\A/orders/\d+\z})

    client.get(order_path)
    expect(client.last.code).to eq("200")
    expect(client.last.body).to include(before["name"])
    expect(client.last.body).to include(money(before["price"] * 2))

    client.get("/orders")
    expect(client.last.body).to include("#{before['name']} x2")

    expect(product(1)["stock"]).to eq(before["stock"] - 2)
  end

  it "mua quá tồn kho: 422, có thông báo, tồn kho KHÔNG đổi" do
    before = product(2)
    client.post("/orders", product_id: 2, qty: before["stock"] + 1)
    expect(client.last.code).to eq("422")
    expect(client.last.body).to include("chỉ còn #{before['stock']}")
    expect(product(2)["stock"]).to eq(before["stock"])
  end

  it "số lượng 0 bị từ chối" do
    client.post("/orders", product_id: 1, qty: 0)
    expect(client.last.code).to eq("422")
  end

  def money(n) = n.to_s.reverse.scan(/\d{1,3}/).join(".").reverse + " đ"
end
