# Unit test: gọi thẳng Shop::Orders, không qua HTTP. Nhanh, và chỉ ra chính xác nghiệp vụ nào hỏng.
require_relative "../spec_helper"

RSpec.describe Shop::Orders do
  let!(:user_id) { create_user }
  let!(:product_id) { create_product(stock: 5, price: 100_000) }

  it "trừ kho và ghi đúng tổng tiền" do
    id = described_class.create(user_id: user_id, product_id: product_id, qty: 2)
    expect(described_class.get(id)["total"]).to eq(200_000)
    expect(Shop::Products.get(product_id)["stock"]).to eq(3)
  end

  it "từ chối khi không đủ hàng và KHÔNG trừ kho" do
    expect { described_class.create(user_id: user_id, product_id: product_id, qty: 6) }
      .to raise_error(Shop::OutOfStock, /chỉ còn 5/)
    expect(Shop::Products.get(product_id)["stock"]).to eq(5)
    expect(described_class.all).to be_empty
  end

  it "từ chối số lượng 0 hoặc âm" do
    expect { described_class.create(user_id: user_id, product_id: product_id, qty: 0) }.to raise_error(Shop::Invalid)
    expect { described_class.create(user_id: user_id, product_id: product_id, qty: -1) }.to raise_error(Shop::Invalid)
  end

  it "báo NotFound với sản phẩm không tồn tại" do
    expect { described_class.create(user_id: user_id, product_id: 999, qty: 1) }.to raise_error(Shop::NotFound)
  end
end
