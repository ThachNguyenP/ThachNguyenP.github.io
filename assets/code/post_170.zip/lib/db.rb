# DB mở một file SQLite, chạy câu lệnh tạo bảng, và cấp cho MỖI THREAD một kết nối riêng
# (Puma chạy nhiều thread; một kết nối SQLite không nên bị hai thread dùng cùng lúc).
require "sqlite3"

class DB
  def initialize(path, schema)
    @path = path
    @key = "db:#{path}:#{object_id}"
    connection.execute_batch(schema)
  end

  def connection
    Thread.current[@key] ||= SQLite3::Database.new(@path).tap do |c|
      c.busy_timeout = 5000               # chờ tối đa 5 giây khi file đang bị khóa
      c.execute("PRAGMA journal_mode = WAL")
      c.execute("PRAGMA foreign_keys = ON")
      c.results_as_hash = true
    end
  end

  # Những hàm hay dùng, chuyển thẳng sang kết nối của thread hiện tại.
  %i[execute get_first_row get_first_value transaction last_insert_row_id changes].each do |m|
    define_method(m) { |*args, &blk| connection.public_send(m, *args, &blk) }
  end
end
