package main

import (
	"errors"
	"flag"
	"fmt"
	"io/fs"
	"net/http"
	"os"
	"time"
)

func main() {
	file := flag.String("file", "sites.txt", "file chứa danh sách URL")
	timeout := flag.Duration("timeout", 5*time.Second, "thời gian chờ tối đa mỗi request")
	jsonOut := flag.String("json", "", "ghi kết quả ra file JSON")
	csvOut := flag.String("csv", "", "ghi kết quả ra file CSV")
	flag.Parse()

	urls, err := readSites(*file)
	if err != nil {
		if errors.Is(err, fs.ErrNotExist) {
			fmt.Printf("Không thấy file %s. Tạo file với mỗi dòng một URL rồi chạy lại.\n", *file)
		} else {
			fmt.Println("Lỗi:", err)
		}
		os.Exit(1)
	}

	client := &http.Client{Timeout: *timeout}

	var results []Result
	for _, url := range urls {
		results = append(results, check(client, url))
	}

	printTable(results)
	printSummary(results)

	if *jsonOut != "" {
		if err := writeJSON(*jsonOut, results); err != nil {
			fmt.Println("Lỗi ghi JSON:", err)
			os.Exit(1)
		}
	}
	if *csvOut != "" {
		if err := writeCSV(*csvOut, results); err != nil {
			fmt.Println("Lỗi ghi CSV:", err)
			os.Exit(1)
		}
	}
}
