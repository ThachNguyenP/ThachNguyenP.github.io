package main

import (
	"net/http"
	"time"
)

// Status là kết quả của một lần kiểm tra.
type Status string

const (
	StatusUp   Status = "up"
	StatusDown Status = "down"
)

// Result là mọi thứ ta biết sau khi gọi vào một URL.
type Result struct {
	URL        string    `json:"url"`
	Status     Status    `json:"status"`
	StatusCode int       `json:"status_code"`
	LatencyMS  int64     `json:"latency_ms"`
	Error      string    `json:"error,omitempty"`
	CheckedAt  time.Time `json:"checked_at"`
}

// check gọi vào url và trả về Result. Không bao giờ panic, lỗi nằm trong Result.
func check(client *http.Client, url string) Result {
	r := Result{URL: url, CheckedAt: time.Now()}

	start := time.Now()
	resp, err := client.Get(url)
	r.LatencyMS = time.Since(start).Milliseconds()
	if err != nil {
		r.Status = StatusDown
		r.Error = err.Error()
		return r
	}
	defer resp.Body.Close()

	r.StatusCode = resp.StatusCode
	if resp.StatusCode >= 200 && resp.StatusCode < 400 {
		r.Status = StatusUp
	} else {
		r.Status = StatusDown
		r.Error = "HTTP " + resp.Status
	}
	return r
}
