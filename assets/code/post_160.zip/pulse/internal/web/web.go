// Package web phục vụ trang status công khai bằng html/template.
package web

import (
	"context"
	"embed"
	"errors"
	"html/template"
	"io/fs"
	"log/slog"
	"net/http"
	"time"

	"github.com/thachnguyenp/pulse/internal/cache"
	"github.com/thachnguyenp/pulse/internal/monitor"
)

//go:embed templates/*.html static/*
var files embed.FS

// Store là những gì trang status cần đọc.
type Store interface {
	GetBySlug(ctx context.Context, slug string) (monitor.Monitor, error)
	Stats(ctx context.Context, monitorID int64, since time.Time) (monitor.Stats, error)
	DailyUptime(ctx context.Context, monitorID int64, days int) ([]monitor.DayStat, error)
	ListIncidents(ctx context.Context, monitorID int64, limit int) ([]monitor.Incident, error)
}

// Handler render trang status.
type Handler struct {
	store Store
	cache *cache.Cache
	tmpl  *template.Template
}

func New(store Store, c *cache.Cache) *Handler {
	funcs := template.FuncMap{
		"barClass": barClass,
		"date":     func(t time.Time) string { return t.Format("02/01/2006") },
		"datetime": func(t time.Time) string { return t.Local().Format("15:04 02/01/2006") },
	}
	// Parse một lần lúc khởi động; template lỗi thì chương trình dừng ngay (Must).
	tmpl := template.Must(template.New("").Funcs(funcs).ParseFS(files, "templates/*.html"))
	return &Handler{store: store, cache: c, tmpl: tmpl}
}

// Register gắn các route vào mux.
func (h *Handler) Register(mux *http.ServeMux) {
	static, _ := fs.Sub(files, "static")
	mux.Handle("GET /static/", http.StripPrefix("/static/", http.FileServerFS(static)))
	mux.HandleFunc("GET /status/{slug}", h.status)
}

// pageData là mọi thứ template cần.
type pageData struct {
	Monitor   monitor.Monitor
	Day       monitor.Stats
	Month     monitor.Stats
	Days      []monitor.DayStat
	Incidents []monitor.Incident
	Now       time.Time
}

func (h *Handler) status(w http.ResponseWriter, r *http.Request) {
	slug := r.PathValue("slug")
	key := "status:" + slug

	var data pageData
	found, _ := h.cache.Get(r.Context(), key, &data)
	if !found {
		var err error
		data, err = h.load(r.Context(), slug)
		if errors.Is(err, monitor.ErrNotFound) {
			http.NotFound(w, r)
			return
		}
		if err != nil {
			slog.Error("trang status lỗi", "slug", slug, "error", err)
			http.Error(w, "lỗi hệ thống", http.StatusInternalServerError)
			return
		}
		h.cache.Set(r.Context(), key, data, time.Minute)
	}

	w.Header().Set("Content-Type", "text/html; charset=utf-8")
	if err := h.tmpl.ExecuteTemplate(w, "status.html", data); err != nil {
		slog.Error("render lỗi", "error", err)
	}
}

func (h *Handler) load(ctx context.Context, slug string) (pageData, error) {
	m, err := h.store.GetBySlug(ctx, slug)
	if err != nil {
		return pageData{}, err
	}
	now := time.Now()
	day, err := h.store.Stats(ctx, m.ID, now.Add(-24*time.Hour))
	if err != nil {
		return pageData{}, err
	}
	month, err := h.store.Stats(ctx, m.ID, now.AddDate(0, 0, -30))
	if err != nil {
		return pageData{}, err
	}
	days, err := h.store.DailyUptime(ctx, m.ID, 90)
	if err != nil {
		return pageData{}, err
	}
	incidents, err := h.store.ListIncidents(ctx, m.ID, 10)
	if err != nil {
		return pageData{}, err
	}
	return pageData{Monitor: m, Day: day, Month: month, Days: days, Incidents: incidents, Now: now}, nil
}

// barClass chọn màu cho một ngày theo uptime.
func barClass(d monitor.DayStat) string {
	switch {
	case d.Total == 0:
		return "none"
	case d.UptimePercent >= 99:
		return "ok"
	case d.UptimePercent >= 90:
		return "warn"
	default:
		return "bad"
	}
}
