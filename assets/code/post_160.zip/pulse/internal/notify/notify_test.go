package notify

import (
	"context"
	"encoding/json"
	"errors"
	"net/http"
	"net/http/httptest"
	"testing"
	"time"

	"github.com/thachnguyenp/pulse/internal/monitor"
)

var sampleEvent = Event{
	Kind:     "down",
	Monitor:  monitor.Monitor{Name: "Shop", URL: "https://shop.vn"},
	Incident: monitor.Incident{Cause: "HTTP 503"},
}

func TestTelegramSend(t *testing.T) {
	var got map[string]string
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		json.NewDecoder(r.Body).Decode(&got)
		w.Write([]byte(`{"ok":true}`))
	}))
	defer srv.Close()

	tg := NewTelegram("token", "123")
	if err := tg.send(context.Background(), srv.URL, sampleEvent.Message()); err != nil {
		t.Fatal(err)
	}
	if got["chat_id"] != "123" {
		t.Errorf("chat_id = %q", got["chat_id"])
	}
	if got["text"] == "" {
		t.Error("text trống")
	}
}

func TestWebhookError(t *testing.T) {
	srv := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		http.Error(w, "nope", http.StatusBadGateway)
	}))
	defer srv.Close()

	err := NewWebhook(srv.URL).Notify(context.Background(), sampleEvent)
	if err == nil {
		t.Fatal("HTTP 502 phải trả lỗi")
	}
}

// flaky lỗi n lần đầu rồi mới thành công.
type flaky struct{ fails, calls int }

func (f *flaky) Notify(ctx context.Context, e Event) error {
	f.calls++
	if f.calls <= f.fails {
		return errors.New("tạm thời lỗi")
	}
	return nil
}

func TestRetry(t *testing.T) {
	f := &flaky{fails: 2}
	r := Retry{Notifier: f, Attempts: 3, Base: time.Millisecond}
	if err := r.Notify(context.Background(), sampleEvent); err != nil {
		t.Fatalf("phải thành công ở lần 3, nhận: %v", err)
	}
	if f.calls != 3 {
		t.Errorf("gọi %d lần, muốn 3", f.calls)
	}

	f = &flaky{fails: 10}
	r = Retry{Notifier: f, Attempts: 2, Base: time.Millisecond}
	if err := r.Notify(context.Background(), sampleEvent); err == nil {
		t.Error("lỗi mãi thì phải bỏ cuộc")
	}
}
