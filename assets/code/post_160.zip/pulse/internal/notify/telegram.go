package notify

import (
	"bytes"
	"context"
	"encoding/json"
	"fmt"
	"io"
	"net/http"
	"time"
)

// Telegram gửi tin nhắn qua Bot API. Tạo bot bằng @BotFather để lấy token.
type Telegram struct {
	Token  string
	ChatID string
	Client *http.Client
}

func NewTelegram(token, chatID string) *Telegram {
	return &Telegram{Token: token, ChatID: chatID, Client: &http.Client{Timeout: 10 * time.Second}}
}

func (t *Telegram) Notify(ctx context.Context, e Event) error {
	return t.send(ctx, "https://api.telegram.org/bot"+t.Token+"/sendMessage", e.Message())
}

// send tách riêng để test được bằng server giả (truyền URL khác).
func (t *Telegram) send(ctx context.Context, url, text string) error {
	body, _ := json.Marshal(map[string]string{"chat_id": t.ChatID, "text": text})
	req, err := http.NewRequestWithContext(ctx, http.MethodPost, url, bytes.NewReader(body))
	if err != nil {
		return err
	}
	req.Header.Set("Content-Type", "application/json")

	resp, err := t.Client.Do(req)
	if err != nil {
		return fmt.Errorf("telegram: %w", err)
	}
	defer resp.Body.Close()

	if resp.StatusCode != http.StatusOK {
		msg, _ := io.ReadAll(io.LimitReader(resp.Body, 1024))
		return fmt.Errorf("telegram: HTTP %d: %s", resp.StatusCode, msg)
	}
	return nil
}
