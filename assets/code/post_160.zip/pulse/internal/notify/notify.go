// Package notify gửi thông báo khi monitor sập hoặc hồi phục.
package notify

import (
	"context"
	"errors"
	"fmt"
	"log/slog"
	"time"

	"github.com/thachnguyenp/pulse/internal/monitor"
)

// Event là một việc đáng báo: monitor vừa sập hoặc vừa hồi phục.
type Event struct {
	Kind     string // "down" hoặc "up"
	Monitor  monitor.Monitor
	Incident monitor.Incident
}

// Message là nội dung ngắn gọn cho người đọc.
func (e Event) Message() string {
	switch e.Kind {
	case "down":
		return fmt.Sprintf("🔴 %s đang DOWN\n%s\nLý do: %s", e.Monitor.Name, e.Monitor.URL, e.Incident.Cause)
	case "up":
		return fmt.Sprintf("🟢 %s đã hoạt động lại\n%s\nSập trong: %s", e.Monitor.Name, e.Monitor.URL, e.Incident.Duration())
	}
	return ""
}

// Notifier gửi Event đi đâu đó: Telegram, webhook, log...
type Notifier interface {
	Notify(ctx context.Context, e Event) error
}

// Multi gửi tới nhiều Notifier, gom lỗi của tất cả.
type Multi []Notifier

func (m Multi) Notify(ctx context.Context, e Event) error {
	var errs []error
	for _, n := range m {
		if err := n.Notify(ctx, e); err != nil {
			errs = append(errs, err)
		}
	}
	return errors.Join(errs...)
}

// Log chỉ in ra log. Dùng khi chưa cấu hình kênh nào.
type Log struct{}

func (Log) Notify(ctx context.Context, e Event) error {
	slog.Warn("thông báo", "kind", e.Kind, "monitor", e.Monitor.Name, "url", e.Monitor.URL)
	return nil
}

// Retry bọc một Notifier, gửi lại khi lỗi với thời gian chờ tăng dần: 1s, 2s, 4s...
type Retry struct {
	Notifier Notifier
	Attempts int
	Base     time.Duration
}

func (r Retry) Notify(ctx context.Context, e Event) error {
	var err error
	for i := range r.Attempts {
		if err = r.Notifier.Notify(ctx, e); err == nil {
			return nil
		}
		wait := r.Base * (1 << i) // 1<<i là 2 mũ i
		slog.Warn("gửi thông báo lỗi, thử lại", "attempt", i+1, "wait", wait, "error", err)
		select {
		case <-time.After(wait):
		case <-ctx.Done():
			return ctx.Err()
		}
	}
	return fmt.Errorf("bỏ cuộc sau %d lần: %w", r.Attempts, err)
}
