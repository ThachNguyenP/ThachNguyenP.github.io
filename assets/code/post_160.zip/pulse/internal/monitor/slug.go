package monitor

import (
	"crypto/rand"
	"encoding/hex"
	"strings"
	"unicode"

	"golang.org/x/text/unicode/norm"
)

// NewSlug tạo slug từ tên, kèm đuôi ngẫu nhiên để không trùng:
// "Cửa hàng Đà Nẵng" -> "cua-hang-da-nang-3f9a1c".
func NewSlug(name string) string {
	suffix := make([]byte, 3)
	rand.Read(suffix)
	return slugify(name) + "-" + hex.EncodeToString(suffix)
}

// slugify bỏ dấu tiếng Việt, đổi chữ thường, thay mọi ký tự lạ bằng "-".
func slugify(s string) string {
	// NFD tách "ế" thành "e" + dấu; bỏ dấu (nhóm Mn) là còn "e".
	s = norm.NFD.String(strings.ToLower(s))
	var b strings.Builder
	lastDash := true
	for _, r := range s {
		switch {
		case unicode.Is(unicode.Mn, r):
			continue
		case r == 'đ':
			r = 'd'
		}
		if r >= 'a' && r <= 'z' || r >= '0' && r <= '9' {
			b.WriteRune(r)
			lastDash = false
		} else if !lastDash {
			b.WriteByte('-')
			lastDash = true
		}
	}
	out := strings.TrimRight(b.String(), "-")
	if len(out) > 40 {
		out = strings.TrimRight(out[:40], "-")
	}
	if out == "" {
		out = "monitor"
	}
	return out
}
