package monitor

import "time"

// Incident là một khoảng thời gian monitor bị down liên tục.
// ResolvedAt = nil nghĩa là đang còn down.
type Incident struct {
	ID         int64      `json:"id"`
	MonitorID  int64      `json:"monitor_id"`
	Cause      string     `json:"cause"`
	StartedAt  time.Time  `json:"started_at"`
	ResolvedAt *time.Time `json:"resolved_at"`
}

// Duration là thời gian sự cố kéo dài (tới giờ nếu chưa hết).
func (i Incident) Duration() time.Duration {
	end := time.Now()
	if i.ResolvedAt != nil {
		end = *i.ResolvedAt
	}
	return end.Sub(i.StartedAt).Round(time.Second)
}
