package monitor

import (
	"regexp"
	"testing"
)

func TestSlugify(t *testing.T) {
	tests := map[string]string{
		"Cửa hàng Đà Nẵng":   "cua-hang-da-nang",
		"  API  Production ": "api-production",
		"Shop!!! (v2)":       "shop-v2",
		"":                   "monitor",
		"日本語":                "monitor",
	}
	for in, want := range tests {
		if got := slugify(in); got != want {
			t.Errorf("slugify(%q) = %q, muốn %q", in, got, want)
		}
	}
}

func TestNewSlug(t *testing.T) {
	a, b := NewSlug("Shop"), NewSlug("Shop")
	if a == b {
		t.Error("hai slug cùng tên phải khác nhau nhờ đuôi ngẫu nhiên")
	}
	if !regexp.MustCompile(`^shop-[0-9a-f]{6}$`).MatchString(a) {
		t.Errorf("slug sai dạng: %s", a)
	}
}
