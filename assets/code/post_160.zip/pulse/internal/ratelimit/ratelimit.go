// Package ratelimit giới hạn số request trong một khoảng thời gian.
package ratelimit

import (
	"context"
	"time"

	"github.com/redis/go-redis/v9"
)

// Limiter cho phép tối đa `limit` lần trong mỗi `window` cho mỗi key (ví dụ mỗi IP).
// Dùng Redis nên nhiều pulsed chạy song song vẫn đếm chung một số.
type Limiter struct {
	rdb    *redis.Client
	limit  int
	window time.Duration
}

func New(rdb *redis.Client, limit int, window time.Duration) *Limiter {
	if rdb == nil {
		return nil
	}
	return &Limiter{rdb: rdb, limit: limit, window: window}
}

// Allow trả về true nếu key còn trong hạn mức. Không có Redis (receiver nil) thì luôn cho qua.
// Thuật toán "cửa sổ cố định": INCR một key, lần đầu thì đặt hạn = window.
func (l *Limiter) Allow(ctx context.Context, key string) (allowed bool, retryAfter time.Duration, err error) {
	if l == nil {
		return true, 0, nil
	}
	key = "ratelimit:" + key

	n, err := l.rdb.Incr(ctx, key).Result()
	if err != nil {
		return false, 0, err
	}
	if n == 1 {
		// Lần đầu trong cửa sổ: đặt hạn. Các lần sau giữ nguyên hạn cũ.
		if err := l.rdb.Expire(ctx, key, l.window).Err(); err != nil {
			return false, 0, err
		}
	}
	if n > int64(l.limit) {
		ttl, _ := l.rdb.TTL(ctx, key).Result()
		return false, ttl, nil
	}
	return true, 0, nil
}
