package store

import (
	"context"
	"errors"

	"github.com/jackc/pgx/v5"

	"github.com/thachnguyenp/pulse/internal/monitor"
)

func (s *Monitors) RecordFailure(ctx context.Context, monitorID int64) (int, error) {
	var failures int
	err := s.db.pool.QueryRow(ctx, `
		UPDATE monitors SET failures = failures + 1 WHERE id = $1 RETURNING failures`, monitorID,
	).Scan(&failures)
	return failures, err
}

func (s *Monitors) ResetFailures(ctx context.Context, monitorID int64) error {
	_, err := s.db.pool.Exec(ctx, `UPDATE monitors SET failures = 0 WHERE id = $1 AND failures <> 0`, monitorID)
	return err
}

// OpenIncident mở sự cố mới. Nhờ unique index "mỗi monitor một sự cố mở",
// ON CONFLICT DO NOTHING làm câu lệnh không trả dòng nào nếu đã có sự cố.
func (s *Monitors) OpenIncident(ctx context.Context, monitorID int64, cause string) (monitor.Incident, bool, error) {
	var inc monitor.Incident
	err := s.db.pool.QueryRow(ctx, `
		INSERT INTO incidents (monitor_id, cause)
		VALUES ($1, $2)
		ON CONFLICT DO NOTHING
		RETURNING id, monitor_id, cause, started_at, resolved_at`, monitorID, cause,
	).Scan(&inc.ID, &inc.MonitorID, &inc.Cause, &inc.StartedAt, &inc.ResolvedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return monitor.Incident{}, false, nil
	}
	return inc, err == nil, err
}

func (s *Monitors) ResolveIncident(ctx context.Context, monitorID int64) (monitor.Incident, bool, error) {
	var inc monitor.Incident
	err := s.db.pool.QueryRow(ctx, `
		UPDATE incidents SET resolved_at = now()
		WHERE monitor_id = $1 AND resolved_at IS NULL
		RETURNING id, monitor_id, cause, started_at, resolved_at`, monitorID,
	).Scan(&inc.ID, &inc.MonitorID, &inc.Cause, &inc.StartedAt, &inc.ResolvedAt)
	if errors.Is(err, pgx.ErrNoRows) {
		return monitor.Incident{}, false, nil
	}
	return inc, err == nil, err
}

func (s *Monitors) ListIncidents(ctx context.Context, monitorID int64, limit int) ([]monitor.Incident, error) {
	rows, err := s.db.pool.Query(ctx, `
		SELECT id, monitor_id, cause, started_at, resolved_at
		FROM incidents
		WHERE monitor_id = $1
		ORDER BY started_at DESC
		LIMIT $2`, monitorID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	list := []monitor.Incident{}
	for rows.Next() {
		var inc monitor.Incident
		if err := rows.Scan(&inc.ID, &inc.MonitorID, &inc.Cause, &inc.StartedAt, &inc.ResolvedAt); err != nil {
			return nil, err
		}
		list = append(list, inc)
	}
	return list, rows.Err()
}
