-- +goose Up
ALTER TABLE monitors
    ADD COLUMN failures INTEGER NOT NULL DEFAULT 0;

CREATE TABLE incidents (
    id          BIGSERIAL PRIMARY KEY,
    monitor_id  BIGINT      NOT NULL REFERENCES monitors(id) ON DELETE CASCADE,
    cause       TEXT        NOT NULL,
    started_at  TIMESTAMPTZ NOT NULL DEFAULT now(),
    resolved_at TIMESTAMPTZ
);

-- Mỗi monitor chỉ có tối đa một sự cố đang mở (resolved_at IS NULL).
CREATE UNIQUE INDEX incidents_open_idx ON incidents (monitor_id) WHERE resolved_at IS NULL;
CREATE INDEX incidents_monitor_id_started_at_idx ON incidents (monitor_id, started_at DESC);

-- +goose Down
DROP TABLE incidents;
ALTER TABLE monitors DROP COLUMN failures;
