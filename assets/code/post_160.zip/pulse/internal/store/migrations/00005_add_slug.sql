-- +goose Up
ALTER TABLE monitors ADD COLUMN slug TEXT;
UPDATE monitors SET slug = 'monitor-' || id;
ALTER TABLE monitors ALTER COLUMN slug SET NOT NULL;
CREATE UNIQUE INDEX monitors_slug_idx ON monitors (slug);

-- +goose Down
ALTER TABLE monitors DROP COLUMN slug;
