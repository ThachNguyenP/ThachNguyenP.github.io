package store

import (
	"context"
	"time"

	"github.com/thachnguyenp/pulse/internal/monitor"
)

// SaveCheck lưu kết quả và cập nhật last_status của monitor trong cùng một transaction.
func (s *Monitors) SaveCheck(ctx context.Context, c *monitor.Check) error {
	tx, err := s.db.pool.Begin(ctx)
	if err != nil {
		return err
	}
	defer tx.Rollback(ctx) // không có tác dụng nếu đã Commit

	err = tx.QueryRow(ctx, `
		INSERT INTO checks (monitor_id, status, status_code, latency_ms, error, checked_at)
		VALUES ($1, $2, $3, $4, $5, $6)
		RETURNING id`,
		c.MonitorID, c.Status, c.StatusCode, c.LatencyMS, c.Error, c.CheckedAt,
	).Scan(&c.ID)
	if err != nil {
		return err
	}

	_, err = tx.Exec(ctx, `UPDATE monitors SET last_status = $1 WHERE id = $2`, c.Status, c.MonitorID)
	if err != nil {
		return err
	}
	return tx.Commit(ctx)
}

func (s *Monitors) ListChecks(ctx context.Context, monitorID int64, limit int) ([]monitor.Check, error) {
	rows, err := s.db.pool.Query(ctx, `
		SELECT id, monitor_id, status, status_code, latency_ms, error, checked_at
		FROM checks
		WHERE monitor_id = $1
		ORDER BY checked_at DESC
		LIMIT $2`, monitorID, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	list := []monitor.Check{}
	for rows.Next() {
		var c monitor.Check
		if err := rows.Scan(&c.ID, &c.MonitorID, &c.Status, &c.StatusCode, &c.LatencyMS, &c.Error, &c.CheckedAt); err != nil {
			return nil, err
		}
		list = append(list, c)
	}
	return list, rows.Err()
}

// Stats tính uptime và độ trễ trung bình từ thời điểm `since` tới giờ.
// Tính ngay trong SQL, không kéo hàng nghìn dòng về Go để cộng.
func (s *Monitors) Stats(ctx context.Context, monitorID int64, since time.Time) (monitor.Stats, error) {
	var st monitor.Stats
	err := s.db.pool.QueryRow(ctx, `
		SELECT count(*),
		       coalesce(avg(CASE WHEN status = 'up' THEN 100.0 ELSE 0 END), 0),
		       coalesce(avg(latency_ms), 0),
		       max(checked_at)
		FROM checks
		WHERE monitor_id = $1 AND checked_at >= $2`, monitorID, since,
	).Scan(&st.TotalChecks, &st.UptimePercent, &st.AvgLatencyMS, &st.LastCheckedAt)
	return st, err
}

// DailyUptime trả về đúng `days` phần tử, cũ nhất trước, ngày không có dữ liệu thì Total = 0.
// Ngày tính theo UTC ở cả hai phía (SQL và Go) để khớp nhau.
func (s *Monitors) DailyUptime(ctx context.Context, monitorID int64, days int) ([]monitor.DayStat, error) {
	today := time.Now().UTC().Truncate(24 * time.Hour)
	from := today.AddDate(0, 0, -(days - 1))

	rows, err := s.db.pool.Query(ctx, `
		SELECT date_trunc('day', checked_at AT TIME ZONE 'UTC') AS day,
		       count(*),
		       count(*) FILTER (WHERE status = 'up')
		FROM checks
		WHERE monitor_id = $1 AND checked_at >= $2
		GROUP BY day`, monitorID, from)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	byDay := map[time.Time]monitor.DayStat{}
	for rows.Next() {
		var d monitor.DayStat
		if err := rows.Scan(&d.Day, &d.Total, &d.Up); err != nil {
			return nil, err
		}
		if d.Total > 0 {
			d.UptimePercent = float64(d.Up) * 100 / float64(d.Total)
		}
		byDay[d.Day.UTC()] = d
	}
	if err := rows.Err(); err != nil {
		return nil, err
	}

	// Điền đủ 90 ngày, kể cả ngày trống, để trang status vẽ đủ 90 cột.
	list := make([]monitor.DayStat, 0, days)
	for i := range days {
		day := from.AddDate(0, 0, i)
		d, ok := byDay[day]
		if !ok {
			d = monitor.DayStat{Day: day}
		}
		list = append(list, d)
	}
	return list, nil
}
