package api

import (
	"log/slog"
	"net"
	"net/http"
	"strconv"
)

// rateLimit chặn client gọi quá nhiều, tính theo IP. Dùng cho đăng nhập, đăng ký.
func (s *Server) rateLimit(next http.HandlerFunc) http.HandlerFunc {
	return func(w http.ResponseWriter, r *http.Request) {
		allowed, retryAfter, err := s.limiter.Allow(r.Context(), clientIP(r))
		if err != nil {
			// Redis lỗi thì cho qua, có log; đừng để toàn bộ đăng nhập chết theo Redis.
			slog.Error("rate limit lỗi", "error", err)
			allowed = true
		}
		if !allowed {
			w.Header().Set("Retry-After", strconv.Itoa(int(retryAfter.Seconds())+1))
			writeError(w, http.StatusTooManyRequests, "bạn thao tác quá nhanh, thử lại sau ít phút")
			return
		}
		next(w, r)
	}
}

// clientIP lấy IP của client. Khi đứng sau reverse proxy (nginx, Cloudflare)
// IP thật nằm trong X-Forwarded-For; chỉ tin header này khi bạn chắc có proxy.
func clientIP(r *http.Request) string {
	host, _, err := net.SplitHostPort(r.RemoteAddr)
	if err != nil {
		return r.RemoteAddr
	}
	return host
}
