package api

import (
	"errors"
	"fmt"
	"log/slog"
	"net/http"
	"strconv"
	"time"

	"github.com/thachnguyenp/pulse/internal/auth"
	"github.com/thachnguyenp/pulse/internal/monitor"
)

func (s *Server) listMonitors(w http.ResponseWriter, r *http.Request) {
	userID, _ := auth.UserID(r.Context())
	list, err := s.monitors.List(r.Context(), userID)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "không lấy được danh sách")
		return
	}
	writeJSON(w, http.StatusOK, list)
}

func (s *Server) createMonitor(w http.ResponseWriter, r *http.Request) {
	var m monitor.Monitor
	if err := readJSON(r, &m); err != nil {
		writeError(w, http.StatusBadRequest, err.Error())
		return
	}
	if problems := m.Validate(); len(problems) > 0 {
		writeValidation(w, problems)
		return
	}
	m.UserID, _ = auth.UserID(r.Context())
	if err := s.monitors.Create(r.Context(), &m); err != nil {
		writeError(w, http.StatusInternalServerError, "không lưu được")
		return
	}
	writeJSON(w, http.StatusCreated, m)
}

func (s *Server) getMonitor(w http.ResponseWriter, r *http.Request) {
	m, ok := s.findMonitor(w, r)
	if !ok {
		return
	}
	writeJSON(w, http.StatusOK, m)
}

func (s *Server) deleteMonitor(w http.ResponseWriter, r *http.Request) {
	m, ok := s.findMonitor(w, r)
	if !ok {
		return
	}
	if err := s.monitors.Delete(r.Context(), m.UserID, m.ID); err != nil {
		writeError(w, http.StatusInternalServerError, "không xóa được")
		return
	}
	w.WriteHeader(http.StatusNoContent)
}

// checkMonitor kiểm tra ngay lập tức, không chờ lịch, và lưu kết quả như bình thường.
func (s *Server) checkMonitor(w http.ResponseWriter, r *http.Request) {
	m, ok := s.findMonitor(w, r)
	if !ok {
		return
	}
	result := s.checker.Check(r.Context(), m.URL)
	c := monitor.CheckFromResult(m.ID, result)
	if err := s.monitors.SaveCheck(r.Context(), &c); err != nil {
		writeError(w, http.StatusInternalServerError, "không lưu được kết quả")
		return
	}
	// Có kết quả mới thì số liệu cũ trong cache đã sai, xóa đi.
	s.cache.Delete(r.Context(), statsKey(m.ID))
	writeJSON(w, http.StatusOK, c)
}

// listChecks trả về các lần kiểm tra gần nhất, mới nhất trước. ?limit=20 (tối đa 500).
func (s *Server) listChecks(w http.ResponseWriter, r *http.Request) {
	m, ok := s.findMonitor(w, r)
	if !ok {
		return
	}
	limit := 20
	if v, err := strconv.Atoi(r.URL.Query().Get("limit")); err == nil && v > 0 && v <= 500 {
		limit = v
	}
	checks, err := s.monitors.ListChecks(r.Context(), m.ID, limit)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "lỗi đọc dữ liệu")
		return
	}
	writeJSON(w, http.StatusOK, checks)
}

func statsKey(monitorID int64) string {
	return fmt.Sprintf("stats:%d", monitorID)
}

// monitorStats trả về uptime và độ trễ trung bình 24 giờ qua.
// Kiểu "cache-aside": có trong cache thì trả luôn, không thì tính rồi cất vào cache.
func (s *Server) monitorStats(w http.ResponseWriter, r *http.Request) {
	m, ok := s.findMonitor(w, r)
	if !ok {
		return
	}

	var stats monitor.Stats
	found, err := s.cache.Get(r.Context(), statsKey(m.ID), &stats)
	if err != nil {
		slog.Error("đọc cache lỗi", "error", err) // cache hỏng thì coi như miss
	}
	if found {
		w.Header().Set("X-Cache", "HIT")
		writeJSON(w, http.StatusOK, stats)
		return
	}

	stats, err = s.monitors.Stats(r.Context(), m.ID, time.Now().Add(-24*time.Hour))
	if err != nil {
		writeError(w, http.StatusInternalServerError, "lỗi đọc dữ liệu")
		return
	}
	s.cache.Set(r.Context(), statsKey(m.ID), stats, 30*time.Second)
	w.Header().Set("X-Cache", "MISS")
	writeJSON(w, http.StatusOK, stats)
}

// findMonitor đọc {id} trên URL và tìm monitor. Tự trả lỗi 400/404 nếu cần.
func (s *Server) findMonitor(w http.ResponseWriter, r *http.Request) (monitor.Monitor, bool) {
	id, err := strconv.ParseInt(r.PathValue("id"), 10, 64)
	if err != nil {
		writeError(w, http.StatusBadRequest, "id phải là số")
		return monitor.Monitor{}, false
	}
	userID, _ := auth.UserID(r.Context())
	m, err := s.monitors.Get(r.Context(), userID, id)
	if errors.Is(err, monitor.ErrNotFound) {
		writeError(w, http.StatusNotFound, "không có monitor này")
		return monitor.Monitor{}, false
	}
	if err != nil {
		writeError(w, http.StatusInternalServerError, "lỗi đọc dữ liệu")
		return monitor.Monitor{}, false
	}
	return m, true
}

// listIncidents trả về các sự cố gần nhất, đang mở xếp trước.
func (s *Server) listIncidents(w http.ResponseWriter, r *http.Request) {
	m, ok := s.findMonitor(w, r)
	if !ok {
		return
	}
	list, err := s.monitors.ListIncidents(r.Context(), m.ID, 50)
	if err != nil {
		writeError(w, http.StatusInternalServerError, "lỗi đọc dữ liệu")
		return
	}
	writeJSON(w, http.StatusOK, list)
}
