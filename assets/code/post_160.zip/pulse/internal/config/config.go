// Package config đọc cấu hình từ biến môi trường (và file .env khi chạy local).
package config

import (
	"fmt"
	"os"
	"strconv"
	"time"

	"github.com/joho/godotenv"
)

// Config là toàn bộ cấu hình của pulsed.
type Config struct {
	Addr         string
	DatabaseURL  string
	RedisURL     string // để trống nếu không dùng Redis
	CheckTimeout time.Duration
	Workers      int
	JWTSecret    string
	TokenTTL     time.Duration

	DownThreshold int    // số lần down liên tiếp mới báo
	TelegramToken string // để trống nếu không dùng
	TelegramChat  string
	WebhookURL    string
}

// Load đọc .env (nếu có) rồi đọc biến môi trường.
func Load() (Config, error) {
	// Trên production không có file .env, biến môi trường được set sẵn. Không có file thì bỏ qua.
	_ = godotenv.Load()

	cfg := Config{
		Addr:         getenv("ADDR", ":3000"),
		DatabaseURL:  os.Getenv("DATABASE_URL"),
		RedisURL:     os.Getenv("REDIS_URL"),
		CheckTimeout: 10 * time.Second,
		Workers:      10,
		JWTSecret:    os.Getenv("JWT_SECRET"),
		TokenTTL:     24 * time.Hour,

		DownThreshold: 3,
		TelegramToken: os.Getenv("TELEGRAM_BOT_TOKEN"),
		TelegramChat:  os.Getenv("TELEGRAM_CHAT_ID"),
		WebhookURL:    os.Getenv("WEBHOOK_URL"),
	}
	if cfg.DatabaseURL == "" {
		return cfg, fmt.Errorf("thiếu biến môi trường DATABASE_URL")
	}
	if len(cfg.JWTSecret) < 32 {
		return cfg, fmt.Errorf("JWT_SECRET phải có ít nhất 32 ký tự")
	}
	if v := os.Getenv("CHECK_TIMEOUT"); v != "" {
		d, err := time.ParseDuration(v)
		if err != nil {
			return cfg, fmt.Errorf("CHECK_TIMEOUT không hợp lệ: %w", err)
		}
		cfg.CheckTimeout = d
	}
	if v := os.Getenv("DOWN_THRESHOLD"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 {
			return cfg, fmt.Errorf("DOWN_THRESHOLD phải là số nguyên dương")
		}
		cfg.DownThreshold = n
	}
	if v := os.Getenv("WORKERS"); v != "" {
		n, err := strconv.Atoi(v)
		if err != nil || n < 1 {
			return cfg, fmt.Errorf("WORKERS phải là số nguyên dương")
		}
		cfg.Workers = n
	}
	return cfg, nil
}

func getenv(key, fallback string) string {
	if v := os.Getenv(key); v != "" {
		return v
	}
	return fallback
}
