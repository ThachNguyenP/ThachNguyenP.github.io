// Package cache lưu tạm dữ liệu tính toán tốn kém vào Redis.
package cache

import (
	"context"
	"encoding/json"
	"errors"
	"fmt"
	"time"

	"github.com/redis/go-redis/v9"
)

// Cache bọc kết nối Redis. Mọi phương thức chấp nhận receiver nil:
// không cấu hình Redis thì cache coi như luôn "miss", chương trình vẫn chạy.
type Cache struct {
	rdb *redis.Client
}

// Connect mở kết nối tới Redis theo URL dạng redis://host:6379/0.
func Connect(ctx context.Context, url string) (*Cache, error) {
	opt, err := redis.ParseURL(url)
	if err != nil {
		return nil, fmt.Errorf("REDIS_URL không hợp lệ: %w", err)
	}
	rdb := redis.NewClient(opt)
	if err := rdb.Ping(ctx).Err(); err != nil {
		return nil, fmt.Errorf("không kết nối được Redis: %w", err)
	}
	return &Cache{rdb: rdb}, nil
}

// Client trả về kết nối Redis thô cho các package khác (rate limit).
func (c *Cache) Client() *redis.Client {
	if c == nil {
		return nil
	}
	return c.rdb
}

func (c *Cache) Close() error {
	if c == nil {
		return nil
	}
	return c.rdb.Close()
}

// Get đọc key và giải mã JSON vào v. found=false nếu không có hoặc đã hết hạn.
func (c *Cache) Get(ctx context.Context, key string, v any) (found bool, err error) {
	if c == nil {
		return false, nil
	}
	data, err := c.rdb.Get(ctx, key).Bytes()
	if errors.Is(err, redis.Nil) {
		return false, nil
	}
	if err != nil {
		return false, err
	}
	return true, json.Unmarshal(data, v)
}

// Set mã hóa v thành JSON và lưu với thời hạn ttl.
func (c *Cache) Set(ctx context.Context, key string, v any, ttl time.Duration) error {
	if c == nil {
		return nil
	}
	data, err := json.Marshal(v)
	if err != nil {
		return err
	}
	return c.rdb.Set(ctx, key, data, ttl).Err()
}

// Delete xóa các key, dùng khi dữ liệu gốc vừa đổi.
func (c *Cache) Delete(ctx context.Context, keys ...string) error {
	if c == nil || len(keys) == 0 {
		return nil
	}
	return c.rdb.Del(ctx, keys...).Err()
}
