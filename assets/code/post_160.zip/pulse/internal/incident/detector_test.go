package incident

import (
	"context"
	"testing"

	"github.com/thachnguyenp/pulse/internal/checker"
	"github.com/thachnguyenp/pulse/internal/monitor"
	"github.com/thachnguyenp/pulse/internal/notify"
)

// fakeStore giữ mọi thứ trong bộ nhớ, đủ để test logic của Detector.
type fakeStore struct {
	failures int
	open     *monitor.Incident
}

func (f *fakeStore) RecordFailure(ctx context.Context, id int64) (int, error) {
	f.failures++
	return f.failures, nil
}
func (f *fakeStore) ResetFailures(ctx context.Context, id int64) error { f.failures = 0; return nil }
func (f *fakeStore) OpenIncident(ctx context.Context, id int64, cause string) (monitor.Incident, bool, error) {
	if f.open != nil {
		return *f.open, false, nil
	}
	f.open = &monitor.Incident{ID: 1, MonitorID: id, Cause: cause}
	return *f.open, true, nil
}
func (f *fakeStore) ResolveIncident(ctx context.Context, id int64) (monitor.Incident, bool, error) {
	if f.open == nil {
		return monitor.Incident{}, false, nil
	}
	inc := *f.open
	f.open = nil
	return inc, true, nil
}

// recorder ghi lại các Event đã nhận.
type recorder struct{ events []notify.Event }

func (r *recorder) Notify(ctx context.Context, e notify.Event) error {
	r.events = append(r.events, e)
	return nil
}

func TestDetector(t *testing.T) {
	store := &fakeStore{}
	rec := &recorder{}
	d := New(store, rec, 3)
	m := monitor.Monitor{ID: 1, Name: "Shop"}
	ctx := context.Background()

	down := monitor.Check{Status: checker.StatusDown, Error: "HTTP 503"}
	up := monitor.Check{Status: checker.StatusUp}

	// 2 lần down: chưa đủ ngưỡng, im lặng.
	d.Handle(ctx, m, down)
	d.Handle(ctx, m, down)
	if len(rec.events) != 0 {
		t.Fatalf("chưa đủ 3 lần mà đã báo: %+v", rec.events)
	}

	// Lần 3: mở sự cố, báo "down".
	d.Handle(ctx, m, down)
	if len(rec.events) != 1 || rec.events[0].Kind != "down" {
		t.Fatalf("muốn 1 event down, nhận %+v", rec.events)
	}

	// Vẫn down tiếp: không báo lại.
	d.Handle(ctx, m, down)
	if len(rec.events) != 1 {
		t.Fatalf("down tiếp không được báo lại, nhận %d event", len(rec.events))
	}

	// Up: đóng sự cố, báo "up".
	d.Handle(ctx, m, up)
	if len(rec.events) != 2 || rec.events[1].Kind != "up" {
		t.Fatalf("muốn event up, nhận %+v", rec.events)
	}

	// Up tiếp: không có gì để báo.
	d.Handle(ctx, m, up)
	if len(rec.events) != 2 {
		t.Error("up khi không có sự cố thì không báo")
	}
}
