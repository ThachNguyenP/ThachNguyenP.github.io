// lib/products.ts
import { prisma } from "./db";
import type { Product } from "@prisma/client";

export type { Product };

export async function getProducts(query?: string): Promise<Product[]> {
  return prisma.product.findMany({
    where: query ? { OR: [{ name: { contains: query, mode: "insensitive" as const } }, { brand: { contains: query, mode: "insensitive" as const } }] } : undefined,
    orderBy: { createdAt: "asc" },
  });
}

export async function getProduct(slug: string): Promise<Product | null> {
  return prisma.product.findUnique({ where: { slug } });
}

export async function getRelatedProducts(product: Product): Promise<Product[]> {
  return prisma.product.findMany({
    where: { category: product.category, slug: { not: product.slug } },
    take: 3,
  });
}

export const formatPrice = (amount: number) => amount.toLocaleString("vi-VN") + "đ";
