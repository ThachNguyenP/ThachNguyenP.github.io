import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  output: "standalone", // build ra thư mục tự chạy, dùng cho Docker (bài 149)
  // Đảm bảo engine của Prisma được copy vào thư mục standalone
  outputFileTracingIncludes: { "/**/*": ["./node_modules/.prisma/client/**/*"] },
};

export default nextConfig;
