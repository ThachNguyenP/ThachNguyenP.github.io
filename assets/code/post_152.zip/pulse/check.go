package main

import (
	"context"
	"net/http"
	"sync"
	"time"
)

// Status là kết quả của một lần kiểm tra.
type Status string

const (
	StatusUp   Status = "up"
	StatusDown Status = "down"
)

// Result là mọi thứ ta biết sau khi gọi vào một URL.
type Result struct {
	URL        string    `json:"url"`
	Status     Status    `json:"status"`
	StatusCode int       `json:"status_code"`
	LatencyMS  int64     `json:"latency_ms"`
	Error      string    `json:"error,omitempty"`
	CheckedAt  time.Time `json:"checked_at"`
}

// check gọi vào url và trả về Result. Không bao giờ panic, lỗi nằm trong Result.
// ctx bị hủy (Ctrl+C) thì request đang chạy bị cắt ngay.
func check(ctx context.Context, client *http.Client, url string) Result {
	r := Result{URL: url, CheckedAt: time.Now()}

	req, err := http.NewRequestWithContext(ctx, http.MethodGet, url, nil)
	if err != nil {
		r.Status = StatusDown
		r.Error = err.Error()
		return r
	}

	start := time.Now()
	resp, err := client.Do(req)
	r.LatencyMS = time.Since(start).Milliseconds()
	if err != nil {
		r.Status = StatusDown
		r.Error = err.Error()
		return r
	}
	defer resp.Body.Close()

	r.StatusCode = resp.StatusCode
	if resp.StatusCode >= 200 && resp.StatusCode < 400 {
		r.Status = StatusUp
	} else {
		r.Status = StatusDown
		r.Error = "HTTP " + resp.Status
	}
	return r
}

// checkAll kiểm tra nhiều URL cùng lúc với tối đa `workers` request song song.
// Kết quả trả về theo đúng thứ tự của urls.
func checkAll(ctx context.Context, client *http.Client, urls []string, workers int) []Result {
	type job struct {
		index int
		url   string
	}
	jobs := make(chan job)
	results := make([]Result, len(urls))

	var wg sync.WaitGroup
	for range workers {
		wg.Add(1)
		go func() {
			defer wg.Done()
			for j := range jobs {
				results[j.index] = check(ctx, client, j.url)
			}
		}()
	}

send:
	for i, url := range urls {
		select {
		case jobs <- job{i, url}:
		case <-ctx.Done():
			break send // người dùng bấm Ctrl+C: ngừng phát việc mới
		}
	}
	close(jobs)
	wg.Wait()

	// URL chưa kịp kiểm tra (do Ctrl+C) vẫn còn giá trị zero, điền cho đủ.
	for i := range results {
		if results[i].Status == "" {
			results[i] = Result{URL: urls[i], Status: StatusDown, Error: "bị hủy"}
		}
	}
	return results
}
