package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

// readSites đọc danh sách URL từ file, mỗi dòng một URL.
// Bỏ qua dòng trống, dòng bắt đầu bằng # và URL trùng.
func readSites(path string) ([]string, error) {
	f, err := os.Open(path)
	if err != nil {
		return nil, fmt.Errorf("đọc danh sách: %w", err)
	}
	defer f.Close()

	var urls []string
	seen := map[string]bool{}

	scanner := bufio.NewScanner(f)
	for scanner.Scan() {
		line := strings.TrimSpace(scanner.Text())
		if line == "" || strings.HasPrefix(line, "#") {
			continue
		}
		if !strings.HasPrefix(line, "http://") && !strings.HasPrefix(line, "https://") {
			line = "https://" + line
		}
		if seen[line] {
			continue
		}
		seen[line] = true
		urls = append(urls, line)
	}
	if err := scanner.Err(); err != nil {
		return nil, fmt.Errorf("đọc danh sách: %w", err)
	}
	if len(urls) == 0 {
		return nil, fmt.Errorf("file %s không có URL nào", path)
	}
	return urls, nil
}
