package main

import (
	"context"
	"errors"
	"flag"
	"fmt"
	"io/fs"
	"net/http"
	"os"
	"os/signal"
	"time"
)

func main() {
	file := flag.String("file", "sites.txt", "file chứa danh sách URL")
	timeout := flag.Duration("timeout", 5*time.Second, "thời gian chờ tối đa mỗi request")
	workers := flag.Int("workers", 10, "số request chạy song song")
	jsonOut := flag.String("json", "", "ghi kết quả ra file JSON")
	csvOut := flag.String("csv", "", "ghi kết quả ra file CSV")
	flag.Parse()

	urls, err := readSites(*file)
	if err != nil {
		if errors.Is(err, fs.ErrNotExist) {
			fmt.Printf("Không thấy file %s. Tạo file với mỗi dòng một URL rồi chạy lại.\n", *file)
		} else {
			fmt.Println("Lỗi:", err)
		}
		os.Exit(1)
	}

	// ctx bị hủy khi người dùng bấm Ctrl+C.
	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt)
	defer stop()

	client := &http.Client{Timeout: *timeout}

	start := time.Now()
	results := checkAll(ctx, client, urls, *workers)
	elapsed := time.Since(start)

	printTable(results)
	printSummary(results)
	fmt.Printf("Xong trong %s với %d workers\n", elapsed.Round(time.Millisecond), *workers)

	if *jsonOut != "" {
		if err := writeJSON(*jsonOut, results); err != nil {
			fmt.Println("Lỗi ghi JSON:", err)
			os.Exit(1)
		}
	}
	if *csvOut != "" {
		if err := writeCSV(*csvOut, results); err != nil {
			fmt.Println("Lỗi ghi CSV:", err)
			os.Exit(1)
		}
	}
}
