package main

import (
	"encoding/csv"
	"encoding/json"
	"fmt"
	"os"
	"strconv"
)

// printTable in kết quả ra màn hình dạng bảng.
func printTable(results []Result) {
	fmt.Printf("%-6s %-5s %7s  %s\n", "STATUS", "CODE", "LATENCY", "URL")
	for _, r := range results {
		code := "-"
		if r.StatusCode != 0 {
			code = strconv.Itoa(r.StatusCode)
		}
		fmt.Printf("%-6s %-5s %5dms  %s", r.Status, code, r.LatencyMS, r.URL)
		if r.Error != "" {
			fmt.Printf("  (%s)", r.Error)
		}
		fmt.Println()
	}
}

// printSummary đếm số lượng theo trạng thái.
func printSummary(results []Result) {
	count := map[Status]int{}
	for _, r := range results {
		count[r.Status]++
	}
	fmt.Printf("\n%d sites: %d up, %d down\n", len(results), count[StatusUp], count[StatusDown])
}

// writeJSON ghi kết quả ra file JSON.
func writeJSON(path string, results []Result) error {
	data, err := json.MarshalIndent(results, "", "  ")
	if err != nil {
		return err
	}
	return os.WriteFile(path, data, 0o644)
}

// writeCSV ghi kết quả ra file CSV, mở được bằng Excel.
func writeCSV(path string, results []Result) error {
	f, err := os.Create(path)
	if err != nil {
		return err
	}
	defer f.Close()

	w := csv.NewWriter(f)
	w.Write([]string{"url", "status", "status_code", "latency_ms", "error", "checked_at"})
	for _, r := range results {
		w.Write([]string{
			r.URL,
			string(r.Status),
			strconv.Itoa(r.StatusCode),
			strconv.FormatInt(r.LatencyMS, 10),
			r.Error,
			r.CheckedAt.Format("2006-01-02 15:04:05"),
		})
	}
	w.Flush()
	return w.Error()
}
