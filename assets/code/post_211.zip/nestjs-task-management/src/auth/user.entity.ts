import {
  Column,
  CreateDateColumn,
  Entity,
  OneToMany,
  PrimaryGeneratedColumn,
} from 'typeorm';
import { Task } from '../tasks/task.entity';

@Entity('users')
export class User {
  // One user has many tasks. Not loaded unless asked for (no "eager").
  @OneToMany(() => Task, (task) => task.user)
  tasks: Task[];

  @PrimaryGeneratedColumn()
  id: number;

  @Column({ unique: true })
  username: string;

  // Never the raw password: only the bcrypt hash is stored.
  @Column()
  passwordHash: string;

  @CreateDateColumn()
  createdAt: Date;
}
