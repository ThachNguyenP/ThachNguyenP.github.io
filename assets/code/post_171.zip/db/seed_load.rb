# Dữ liệu lớn để load test: 50 khách, mỗi khách 400 đơn (20.000 đơn), sản phẩm tồn kho rất lớn.
# Chạy: bundle exec ruby db/seed_load.rb
require_relative "../lib/shop"

Shop.db = DB.new(ENV.fetch("DB", "shop.db"), Shop::SCHEMA)
%w[order_items orders users products].each { |t| Shop.db.execute("DELETE FROM #{t}") }

Shop::Users.create(email: "admin@example.com", password: "admin-pass-1", role: "admin")
30.times { |i| Shop.db.execute("INSERT INTO products (name, price, stock) VALUES (?, ?, ?)", ["Sản phẩm #{i + 1}", (i + 1) * 50_000, 1_000_000]) }

Shop.db.transaction do
  50.times do |u|
    uid = Shop::Users.create(email: "khach#{u}@example.com", password: "khach-pass-#{u}")
    400.times do |o|
      pid = (o % 30) + 1
      Shop.db.execute("INSERT INTO orders (user_id, total) VALUES (?, ?)", [uid, pid * 50_000])
      Shop.db.execute("INSERT INTO order_items (order_id, product_id, qty, price) VALUES (?, ?, 1, ?)",
                      [Shop.db.last_insert_row_id, pid, pid * 50_000])
    end
  end
end
puts "orders: #{Shop.db.get_first_value('SELECT COUNT(*) FROM orders')}, order_items: #{Shop.db.get_first_value('SELECT COUNT(*) FROM order_items')}"
