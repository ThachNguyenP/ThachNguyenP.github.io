# Test hiệu năng dạng "đếm câu SQL": số câu không được tăng theo số đơn. Bắt N+1 trước khi nó lên production.
require_relative "../spec_helper"

RSpec.describe "Shop::Orders.for_user_with_items" do
  def count_queries
    n = 0
    Shop.db.connection.trace { n += 1 }
    yield
    n
  ensure
    Shop.db.connection.trace(nil)
  end

  it "chạy đúng 2 câu SQL dù khách có 50 đơn" do
    user_id = create_user
    product_id = create_product(stock: 1000)
    50.times { Shop::Orders.create(user_id: user_id, product_id: product_id, qty: 1) }

    orders = nil
    n = count_queries { orders = Shop::Orders.for_user_with_items(user_id) }
    expect(orders.size).to eq(50)
    expect(orders.first["items"].first["name"]).to eq("Bàn gỗ")
    expect(n).to eq(2)
  end
end
