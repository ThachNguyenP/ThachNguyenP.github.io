// Package api là HTTP API của pulsed.
package api

import (
	"net/http"

	"github.com/thachnguyenp/pulse/internal/checker"
	"github.com/thachnguyenp/pulse/internal/monitor"
)

// Server gom mọi thứ handler cần: store, checker...
type Server struct {
	monitors monitor.Store
	checker  *checker.Checker
}

// New tạo Server với các phụ thuộc được truyền vào.
func New(monitors monitor.Store, checker *checker.Checker) *Server {
	return &Server{monitors: monitors, checker: checker}
}

// Handler trả về http.Handler với toàn bộ route và middleware.
func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()

	mux.HandleFunc("GET /healthz", s.healthz)

	mux.HandleFunc("GET /monitors", s.listMonitors)
	mux.HandleFunc("POST /monitors", s.createMonitor)
	mux.HandleFunc("GET /monitors/{id}", s.getMonitor)
	mux.HandleFunc("DELETE /monitors/{id}", s.deleteMonitor)
	mux.HandleFunc("POST /monitors/{id}/check", s.checkMonitor)
	mux.HandleFunc("GET /monitors/{id}/checks", s.listChecks)
	mux.HandleFunc("GET /monitors/{id}/stats", s.monitorStats)

	return recoverPanic(logging(mux))
}

func (s *Server) healthz(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}
