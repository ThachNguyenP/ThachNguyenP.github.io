// Package store lưu dữ liệu vào PostgreSQL.
package store

import (
	"context"
	"embed"
	"fmt"

	"github.com/jackc/pgx/v5/pgxpool"
	"github.com/jackc/pgx/v5/stdlib"
	"github.com/pressly/goose/v3"
)

//go:embed migrations/*.sql
var migrations embed.FS

// Postgres giữ pool kết nối. Một pool dùng chung cho cả chương trình.
type Postgres struct {
	pool *pgxpool.Pool
}

// NewPostgres kết nối tới database và kiểm tra kết nối.
func NewPostgres(ctx context.Context, url string) (*Postgres, error) {
	pool, err := pgxpool.New(ctx, url)
	if err != nil {
		return nil, fmt.Errorf("cấu hình kết nối: %w", err)
	}
	if err := pool.Ping(ctx); err != nil {
		pool.Close()
		return nil, fmt.Errorf("không kết nối được database: %w", err)
	}
	return &Postgres{pool: pool}, nil
}

// Close đóng mọi kết nối. Gọi khi tắt chương trình.
func (s *Postgres) Close() {
	s.pool.Close()
}

// Migrate chạy các file SQL trong thư mục migrations chưa được chạy.
func (s *Postgres) Migrate(ctx context.Context) error {
	goose.SetBaseFS(migrations)
	goose.SetLogger(goose.NopLogger())
	if err := goose.SetDialect("postgres"); err != nil {
		return err
	}
	db := stdlib.OpenDBFromPool(s.pool)
	defer db.Close()
	return goose.UpContext(ctx, db, "migrations")
}
