package store

import (
	"context"
	"errors"

	"github.com/jackc/pgx/v5"

	"github.com/thachnguyenp/pulse/internal/monitor"
)

const monitorColumns = `id, name, url, interval_seconds, last_status, next_check_at, created_at`

func scanMonitor(row pgx.Row) (monitor.Monitor, error) {
	var m monitor.Monitor
	err := row.Scan(&m.ID, &m.Name, &m.URL, &m.Interval, &m.LastStatus, &m.NextCheckAt, &m.CreatedAt)
	return m, err
}

func (s *Postgres) Create(ctx context.Context, m *monitor.Monitor) error {
	created, err := scanMonitor(s.pool.QueryRow(ctx, `
		INSERT INTO monitors (name, url, interval_seconds)
		VALUES ($1, $2, $3)
		RETURNING `+monitorColumns,
		m.Name, m.URL, m.Interval,
	))
	if err != nil {
		return err
	}
	*m = created
	return nil
}

func (s *Postgres) List(ctx context.Context) ([]monitor.Monitor, error) {
	rows, err := s.pool.Query(ctx, `SELECT `+monitorColumns+` FROM monitors ORDER BY id`)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	list := []monitor.Monitor{}
	for rows.Next() {
		m, err := scanMonitor(rows)
		if err != nil {
			return nil, err
		}
		list = append(list, m)
	}
	return list, rows.Err()
}

func (s *Postgres) Get(ctx context.Context, id int64) (monitor.Monitor, error) {
	m, err := scanMonitor(s.pool.QueryRow(ctx, `SELECT `+monitorColumns+` FROM monitors WHERE id = $1`, id))
	if errors.Is(err, pgx.ErrNoRows) {
		return monitor.Monitor{}, monitor.ErrNotFound
	}
	return m, err
}

func (s *Postgres) Delete(ctx context.Context, id int64) error {
	tag, err := s.pool.Exec(ctx, `DELETE FROM monitors WHERE id = $1`, id)
	if err != nil {
		return err
	}
	if tag.RowsAffected() == 0 {
		return monitor.ErrNotFound
	}
	return nil
}

// ClaimDue lấy tối đa `limit` monitor đã tới giờ kiểm tra và dời lịch của chúng
// sang lần sau ngay trong cùng một câu lệnh. Nhờ FOR UPDATE SKIP LOCKED, nhiều
// pulsed chạy cùng lúc cũng không lấy trùng monitor.
func (s *Postgres) ClaimDue(ctx context.Context, limit int) ([]monitor.Monitor, error) {
	rows, err := s.pool.Query(ctx, `
		UPDATE monitors
		SET next_check_at = now() + interval_seconds * interval '1 second'
		WHERE id IN (
			SELECT id FROM monitors
			WHERE next_check_at <= now()
			ORDER BY next_check_at
			LIMIT $1
			FOR UPDATE SKIP LOCKED
		)
		RETURNING `+monitorColumns, limit)
	if err != nil {
		return nil, err
	}
	defer rows.Close()

	var list []monitor.Monitor
	for rows.Next() {
		m, err := scanMonitor(rows)
		if err != nil {
			return nil, err
		}
		list = append(list, m)
	}
	return list, rows.Err()
}
