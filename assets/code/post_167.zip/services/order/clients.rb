# Client HTTP tới catalog và payment, có timeout, retry (chỉ cho GET) và circuit breaker.
require "net/http"
require "json"
require_relative "../../lib/breaker"

# Bọc mọi lỗi mà service bên kia trả về (4xx, 5xx).
class RemoteError < StandardError
  attr_reader :service, :status, :remote_message

  def initialize(service, status, remote_message)
    @service = service
    @status = status
    @remote_message = remote_message
    super("#{service} trả về #{status}: #{remote_message}")
  end

  # Lỗi do dữ liệu (4xx), không phải do mạng hay service sập.
  def client_error? = status < 500
end

# Gom các "lưới an toàn" khi gọi một service khác.
class RemoteClient
  TIMEOUT = 2 # giây: không bao giờ chờ vô hạn

  def initialize(name)
    @name = name
    @breaker = Breaker.new(threshold: 3, cooldown: 5) # service kia hỏng thì ngắt sớm
  end

  # Retry tối đa 3 lần nhưng CHỈ với GET: POST lặp lại có thể trừ tiền hai lần.
  def call(method, url, body = nil)
    tries = method == :get ? 3 : 1
    attempt = 0
    begin
      attempt += 1
      @breaker.call { once(method, url, body) }
    rescue RemoteError => e
      raise if e.client_error? || attempt >= tries # lỗi dữ liệu thì thử lại cũng vô ích
      retry_after(attempt, e)
      retry
    rescue Breaker::Open
      raise
    rescue StandardError => e
      raise if attempt >= tries
      retry_after(attempt, e)
      retry
    end
  end

  private

  def retry_after(attempt, error)
    Log.warn("thử lại", target: @name, lần: attempt + 1, err: error.message)
    sleep attempt * 0.2
  end

  def once(method, url, body)
    uri = URI(url)
    req = (method == :get ? Net::HTTP::Get : Net::HTTP::Post).new(uri)
    req["Content-Type"] = "application/json"
    req["X-Request-ID"] = Log.request_id # chuyền request id sang service kia
    req.body = JSON.generate(body) if body
    res = Net::HTTP.start(uri.host, uri.port, open_timeout: TIMEOUT, read_timeout: TIMEOUT) { |http| http.request(req) }
    data = JSON.parse(res.body) rescue {}
    raise RemoteError.new(@name, res.code.to_i, data["error"] || res.message) if res.code.to_i >= 400

    data
  rescue SystemCallError, IOError, Net::OpenTimeout, Net::ReadTimeout => e
    raise "gọi #{@name}: #{e.message}"
  end
end

class CatalogClient
  def initialize(url)
    @url = url
    @c = RemoteClient.new("catalog")
  end

  def get(id) = @c.call(:get, "#{@url}/products/#{id}")
  def reserve(id, qty) = @c.call(:post, "#{@url}/products/#{id}/reserve", { qty: qty })
  def release(id, qty) = @c.call(:post, "#{@url}/products/#{id}/release", { qty: qty })
end

class PaymentClient
  def initialize(url)
    @url = url
    @c = RemoteClient.new("payment")
  end

  def charge(card, amount) = @c.call(:post, "#{@url}/charges", { card: card, amount: amount })
end
