# Order service: tạo đơn hàng bằng cách GỌI catalog và payment qua HTTP. Chạy: ruby services/order/app.rb
require "sinatra"
require_relative "../../lib/db"
require_relative "../../lib/web"
require_relative "store"
require_relative "clients"

Log.service = "order"
set :server, :puma
set :port, ENV.fetch("PORT", 8082).to_i
set :logging, false
set :show_exceptions, :after_handler
use Web::RequestLog
helpers Web::Helpers

get "/healthz" do
  json_body 200, status: "ok"
end

class Invalid < StandardError; end

class OrderService
  def initialize(db, catalog, payment)
    @db = db
    @catalog = catalog
    @payment = payment
  end

  # Không còn transaction nào bao trùm cả ba bước. Bước sau lỗi thì
  # phải TỰ hoàn tác bước trước (release), đó là ý tưởng của saga.
  def create(product_id:, qty:, email:, card:)
    raise Invalid, "thiếu qty, email hoặc card" if qty.to_i <= 0 || email.to_s.empty? || card.to_s.empty?

    product = @catalog.get(product_id)
    @catalog.reserve(product["id"], qty)
    total = product["price"] * qty
    begin
      charge = @payment.charge(card, total)
    rescue StandardError => e
      release(product["id"], qty) # bước bù trừ: trả lại hàng đã giữ
      raise e
    end
    OrderStore.insert(@db, "product_id" => product["id"], "qty" => qty, "total" => total,
                           "email" => email, "status" => "paid", "charge_id" => charge["id"])
  end

  def get(id) = OrderStore.get(@db, id)

  private

  def release(product_id, qty)
    @catalog.release(product_id, qty)
  rescue StandardError => e
    # Không bù trừ được: tồn kho đang lệch thật, phải làm cho người vận hành thấy.
    Log.error("release thất bại, tồn kho đang lệch", product: product_id, qty: qty, err: e.message)
  end
end

DBH = DB.new(ENV.fetch("DB", "order.db"), OrderStore::SCHEMA)
ORDERS = OrderService.new(
  DBH,
  CatalogClient.new(ENV.fetch("CATALOG_URL", "http://localhost:8081")),
  PaymentClient.new(ENV.fetch("PAYMENT_URL", "http://localhost:8083"))
)

post "/orders" do
  input = read_json
  order = ORDERS.create(product_id: input["product_id"], qty: input["qty"].to_i, email: input["email"], card: input["card"])
  json_body 201, order
end

# Feed sự kiện cho các service khác kéo về. Order service không cần biết ai đang đọc.
get "/events" do
  after = params[:after].to_i
  limit = params[:limit].to_i
  limit = 100 if limit <= 0 || limit > 1000
  json_body 200, OrderStore.events(DBH, after, limit)
end

get "/orders/:id" do
  json_body 200, ORDERS.get(params[:id])
end

error Invalid do json_error 400, env["sinatra.error"].message end
error OrderStore::NotFound do json_error 404, env["sinatra.error"].message end
error RemoteError do
  e = env["sinatra.error"]
  # 4xx từ service khác là lỗi dữ liệu: trả nguyên status và lời nhắn cho khách. 5xx hay lỗi mạng: 502.
  e.client_error? ? json_error(e.status, e.remote_message) : json_error(502, e.message)
end
error Breaker::Open do json_error 503, env["sinatra.error"].message end # service phía sau đang hỏng, trả lời ngay
error RuntimeError do json_error 502, env["sinatra.error"].message end
