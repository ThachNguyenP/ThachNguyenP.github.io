# Report service: đọc cùng feed sự kiện, tự giữ bảng doanh thu theo sản phẩm, trả về GET /report.
# Đây là cách lấy lại câu JOIN đã mất khi tách database. Chạy: ruby services/report.rb
require "sinatra"
require "net/http"
require_relative "../lib/db"
require_relative "../lib/web"
require_relative "../lib/events"

Log.service = "report"
set :server, :puma
set :port, ENV.fetch("PORT", 8085).to_i
set :logging, false
set :show_exceptions, :after_handler
use Web::RequestLog
helpers Web::Helpers

get "/healthz" do
  json_body 200, status: "ok"
end

SCHEMA = <<~SQL
  CREATE TABLE IF NOT EXISTS sales (
    product_id INTEGER PRIMARY KEY,
    orders     INTEGER NOT NULL DEFAULT 0,
    revenue    INTEGER NOT NULL DEFAULT 0
  );
SQL

DBH = DB.new(ENV.fetch("DB", "report.db"), SCHEMA + Events::CONSUMER_SCHEMA)
CATALOG_URL = ENV.fetch("CATALOG_URL", "http://localhost:8081")

# Cập nhật bảng sales bằng chính transaction của consumer: cursor và dữ liệu luôn khớp nhau.
consumer = Events::Consumer.new(name: "report", feed: ENV.fetch("ORDER_URL", "http://localhost:8082") + "/events", db: DBH) do |db, ev|
  next unless ev["type"] == "order.paid"

  o = ev["payload"]
  db.execute(<<~SQL, [o["product_id"], o["total"]])
    INSERT INTO sales (product_id, orders, revenue) VALUES (?, 1, ?)
    ON CONFLICT (product_id) DO UPDATE SET orders = orders + 1, revenue = revenue + excluded.revenue
  SQL
end
Thread.new { consumer.run } # consumer chạy nền, cạnh HTTP server

get "/report" do
  # Tên sản phẩm không có ở đây: hỏi catalog lúc đọc (API composition).
  names = begin
    JSON.parse(Net::HTTP.get(URI("#{CATALOG_URL}/products"))).to_h { |p| [p["id"], p["name"]] }
  rescue StandardError
    {}
  end
  rows = DBH.execute("SELECT product_id, orders, revenue FROM sales ORDER BY product_id")
  json_body 200, rows.map { |r| { product: names.fetch(r["product_id"], "##{r['product_id']}"), orders: r["orders"], revenue: r["revenue"] } }
end
