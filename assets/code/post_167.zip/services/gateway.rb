# API gateway: cửa duy nhất cho bên ngoài. Chỉ mở những route công khai, gắn request id, rồi chuyển tiếp.
# Chạy: ruby services/gateway.rb
require "sinatra"
require "net/http"
require_relative "../lib/web"

Log.service = "gateway"
set :server, :puma
set :port, ENV.fetch("PORT", 8080).to_i
set :logging, false
use Web::RequestLog
helpers Web::Helpers

CATALOG = ENV.fetch("CATALOG_URL", "http://localhost:8081")
ORDER = ENV.fetch("ORDER_URL", "http://localhost:8082")
REPORT = ENV.fetch("REPORT_URL", "http://localhost:8085")

helpers do
  # Chuyển tiếp request hiện tại sang service phía sau, trả nguyên status và body.
  def forward(base)
    uri = URI(base + request.fullpath)
    req = (request.get? ? Net::HTTP::Get : Net::HTTP::Post).new(uri)
    req["Content-Type"] = request.content_type if request.content_type
    req["X-Request-ID"] = env["HTTP_X_REQUEST_ID"]
    req.body = request.body.read if request.post?
    res = Net::HTTP.start(uri.host, uri.port, open_timeout: 2, read_timeout: 10) { |http| http.request(req) }
    content_type :json
    halt res.code.to_i, res.body
  rescue SystemCallError, Net::OpenTimeout, Net::ReadTimeout => e
    json_error 502, "service phía sau không trả lời: #{e.message}"
  end
end

get "/healthz" do
  json_body 200, status: "ok"
end

# Chỉ những route này ra ngoài. /products/:id/reserve hay /events là chuyện nội bộ.
get("/products") { forward CATALOG }
get("/products/:id") { forward CATALOG }
post("/orders") { forward ORDER }
get("/orders/:id") { forward ORDER }
get("/report") { forward REPORT }

not_found do
  json_error 404, "không có route này"
end
