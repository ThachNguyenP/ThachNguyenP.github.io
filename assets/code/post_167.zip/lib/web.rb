# Vài thứ dùng chung cho mọi service: log dạng key=value có service và request id, helper JSON cho Sinatra.
require "json"
require "logger"
require "securerandom"

module Log
  $stdout.sync = true
  LOGGER = Logger.new($stdout)
  LOGGER.formatter = ->(level, time, _prog, msg) { "time=#{time.strftime('%H:%M:%S.%L')} level=#{level} #{msg}\n" }

  def self.service=(name)
    @service = name
  end

  # Request id của request đang xử lý trên thread này (Puma: mỗi request một thread).
  def self.request_id = Thread.current[:request_id]

  def self.request_id=(id)
    Thread.current[:request_id] = id
  end

  # Log.info("request", method: "GET") -> msg=request service=catalog rid=abc method=GET
  %i[info warn error].each do |level|
    define_singleton_method(level) do |msg, **kv|
      fields = { msg: msg, service: @service, rid: request_id }.merge(kv).compact
      LOGGER.public_send(level, fields.map { |k, v| "#{k}=#{v.to_s =~ /[\s"]/ ? v.to_s.inspect : v}" }.join(" "))
    end
  end
end

module Web
  module Helpers
    def json_body(status, obj)
      content_type :json
      halt status, JSON.generate(obj)
    end

    def json_error(status, msg)
      json_body status, error: msg
    end

    # Đọc JSON từ body; sai định dạng thì trả 400 luôn.
    def read_json
      JSON.parse(request.body.read)
    rescue JSON::ParserError => e
      json_error 400, "JSON sai: #{e.message}"
    end
  end

  # Middleware: lấy (hoặc sinh) X-Request-ID, nhớ nó cho thread này, trả lại trong response,
  # và ghi một dòng log cho mỗi request.
  class RequestLog
    def initialize(app) = @app = app

    def call(env)
      rid = env["HTTP_X_REQUEST_ID"].to_s.empty? ? SecureRandom.hex(8) : env["HTTP_X_REQUEST_ID"]
      env["HTTP_X_REQUEST_ID"] = rid
      Log.request_id = rid
      start = Process.clock_gettime(Process::CLOCK_MONOTONIC)
      status, headers, body = @app.call(env)
      ms = ((Process.clock_gettime(Process::CLOCK_MONOTONIC) - start) * 1000).round
      Log.info("request", method: env["REQUEST_METHOD"], path: env["PATH_INFO"], status: status, ms: ms)
      [status, headers.merge("x-request-id" => rid), body]
    ensure
      Log.request_id = nil
    end
  end
end
