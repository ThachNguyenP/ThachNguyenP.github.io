# Circuit breaker tối giản. Sau N lỗi liên tiếp thì "mở", từ chối ngay mọi lời gọi trong một khoảng nghỉ;
# hết khoảng nghỉ cho MỘT lời gọi thử, thành công thì "đóng" lại.
class Breaker
  class Open < StandardError; end

  def initialize(threshold: 3, cooldown: 5)
    @threshold = threshold
    @cooldown = cooldown
    @failures = 0
    @opened_at = nil
    @probing = false
    @mutex = Mutex.new # nhiều thread (nhiều request) dùng chung một breaker
  end

  # Chạy block nếu breaker cho phép, và ghi nhận kết quả.
  def call
    allow!
    result = yield
    record(nil)
    result
  rescue Open
    raise
  rescue StandardError => e
    record(e)
    raise
  end

  private

  def allow!
    @mutex.synchronize do
      return if @failures < @threshold # đóng: cho qua
      if Time.now - @opened_at < @cooldown || @probing
        raise Open, "circuit breaker đang mở" # mở: từ chối ngay, không tốn thời gian chờ
      end

      @probing = true # nửa mở: cho đúng một lời gọi thử
    end
  end

  def record(error)
    @mutex.synchronize do
      @probing = false
      if error.nil?
        @failures = 0
        return
      end
      @failures += 1
      @failures = @threshold if @failures > @threshold # lời gọi thử thất bại: mở thêm một khoảng nữa
      @opened_at = Time.now if @failures == @threshold
    end
  end
end
