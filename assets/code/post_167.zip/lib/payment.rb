# Payment giả lập cổng thanh toán: thẻ 4242 luôn được, thẻ 4000 luôn bị từ chối, thẻ 5000 mất 5 giây mới trả lời.
module Payment
  class Declined < StandardError; end

  # Trừ tiền trên thẻ. Thật ra chỉ nhìn 4 số đầu để quyết định.
  def self.charge(card, amount)
    raise Declined, "thẻ bị từ chối" if card.start_with?("4000")
    sleep 5 if card.start_with?("5000") # cổng thanh toán "đang chậm"

    { "id" => format("ch_%06d", rand(1_000_000)), "amount" => amount }
  end
end
