// app/actions/admin.ts
"use server";

import { revalidatePath } from "next/cache";
import { z } from "zod";
import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/session";

const ORDER_STATUSES = ["pending", "shipping", "done", "cancelled"] as const;

export async function updateOrderStatus(formData: FormData) {
  await requireAdmin(); // action là endpoint công khai, phải kiểm tra quyền ở đây, không chỉ ở layout

  const id = Number(formData.get("id"));
  const status = z.enum(ORDER_STATUSES).parse(formData.get("status"));

  await prisma.order.update({ where: { id }, data: { status } });
  revalidatePath("/admin/orders");
  revalidatePath(`/orders/${id}`);
}

const productSchema = z.object({
  id: z.coerce.number().int(),
  price: z.coerce.number().int().min(1000),
  stock: z.coerce.number().int().min(0),
});

export async function updateProduct(formData: FormData) {
  await requireAdmin();

  const { id, price, stock } = productSchema.parse(Object.fromEntries(formData));
  const product = await prisma.product.update({ where: { id }, data: { price, stock } });

  // Trang sản phẩm là tĩnh (bài 141): phải xóa cache để giá mới hiện ra ngay
  revalidatePath("/");
  revalidatePath("/products");
  revalidatePath(`/products/${product.slug}`);
  revalidatePath("/admin/products");
}
