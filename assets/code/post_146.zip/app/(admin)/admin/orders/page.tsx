import { updateOrderStatus } from "@/app/actions/admin";
import { prisma } from "@/lib/db";
import { formatPrice } from "@/lib/products";
import { requireAdmin } from "@/lib/session";
import styles from "../admin.module.css";

export default async function AdminOrdersPage() {
  await requireAdmin();

  const orders = await prisma.order.findMany({
    orderBy: { createdAt: "desc" },
    include: { items: { include: { product: true } }, user: { select: { email: true } } },
  });

  return (
    <>
      <h1 className={styles.title}>Đơn hàng ({orders.length})</h1>
      <div className={styles.wrap}>
        <table className={styles.table}>
          <thead>
            <tr><th>Mã</th><th>Khách</th><th>Sản phẩm</th><th>Tổng</th><th>Trạng thái</th></tr>
          </thead>
          <tbody>
            {orders.map((order) => (
              <tr key={order.id}>
                <td>#{order.id}<br /><span className={styles.muted}>{order.createdAt.toLocaleDateString("vi-VN")}</span></td>
                <td>{order.customerName}<br /><span className={styles.muted}>{order.phone} · {order.user?.email ?? "khách"}</span></td>
                <td>{order.items.map((i) => `${i.product.name} ×${i.quantity}`).join(", ")}</td>
                <td>{formatPrice(order.total)}</td>
                <td>
                  <form action={updateOrderStatus} className={styles.inline}>
                    <input type="hidden" name="id" value={order.id} />
                    <select name="status" defaultValue={order.status}>
                      <option value="pending">Chờ xác nhận</option>
                      <option value="shipping">Đang giao</option>
                      <option value="done">Đã giao</option>
                      <option value="cancelled">Đã hủy</option>
                    </select>
                    <button type="submit">Lưu</button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
