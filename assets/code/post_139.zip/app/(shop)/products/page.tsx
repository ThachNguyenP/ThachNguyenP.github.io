import ProductCard from "@/components/product-card";
import { products } from "@/lib/products";
import styles from "./page.module.css";

export default function ProductsPage() {
  return (
    <>
      <h1 className={styles.title}>Tất cả sản phẩm ({products.length})</h1>
      <div className={styles.grid}>
        {products.map((product) => (
          <ProductCard key={product.slug} product={product} />
        ))}
      </div>
    </>
  );
}
