import Link from "next/link";
import { notFound } from "next/navigation";
import { formatPrice, products } from "@/lib/products";
import styles from "./page.module.css";

export default async function ProductPage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = products.find((p) => p.slug === slug);

  if (!product) notFound();

  return (
    <article className={styles.product}>
      <div className={styles.media}>{product.emoji}</div>
      <div>
        <Link href="/products" className={styles.back}>← Tất cả sản phẩm</Link>
        <p className={styles.brand}>{product.brand}</p>
        <h1 className={styles.name}>{product.name}</h1>
        <p className={styles.price}>
          {formatPrice(product.price)}
          {product.oldPrice && <s className={styles.old}>{formatPrice(product.oldPrice)}</s>}
        </p>
        <p className={styles.desc}>{product.description}</p>
        <p className={styles.stock}>{product.stock > 0 ? `Còn ${product.stock} sản phẩm` : "Hết hàng"}</p>
      </div>
    </article>
  );
}
