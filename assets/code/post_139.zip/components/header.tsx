import Link from "next/link";
import styles from "./header.module.css";

export default function Header() {
  return (
    <header className={styles.header}>
      <div className={`container ${styles.inner}`}>
        <Link href="/" className={styles.logo}>TechShop</Link>
        <nav className={styles.nav}>
          <Link href="/products">Sản phẩm</Link>
          <Link href="/about">Về chúng tôi</Link>
          <Link href="/cart">🛒 Giỏ hàng</Link>
        </nav>
      </div>
    </header>
  );
}
