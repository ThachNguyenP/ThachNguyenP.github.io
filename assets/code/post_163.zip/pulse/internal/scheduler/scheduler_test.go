package scheduler

import (
	"context"
	"net/http"
	"net/http/httptest"
	"sync"
	"testing"
	"time"

	"github.com/thachnguyenp/pulse/internal/checker"
	"github.com/thachnguyenp/pulse/internal/monitor"
)

// fakeStore trả về danh sách monitor "tới giờ" đúng một lần, rồi rỗng.
type fakeStore struct {
	mu    sync.Mutex
	due   []monitor.Monitor
	saved []monitor.Check
}

func (f *fakeStore) ClaimDue(ctx context.Context, limit int) ([]monitor.Monitor, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	due := f.due
	f.due = nil
	return due, nil
}

func (f *fakeStore) SaveCheck(ctx context.Context, c *monitor.Check) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.saved = append(f.saved, *c)
	return nil
}

type fakeHandler struct {
	mu    sync.Mutex
	calls int
}

func (h *fakeHandler) Handle(ctx context.Context, m monitor.Monitor, c monitor.Check) error {
	h.mu.Lock()
	defer h.mu.Unlock()
	h.calls++
	return nil
}

func TestSchedulerRun(t *testing.T) {
	target := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("ok"))
	}))
	defer target.Close()

	store := &fakeStore{due: []monitor.Monitor{
		{ID: 1, Name: "A", URL: target.URL},
		{ID: 2, Name: "B", URL: target.URL},
	}}
	handler := &fakeHandler{}
	s := New(store, checker.New(time.Second), handler, 2)

	// Chạy 2.5 giây rồi hủy: đủ cho ticker 1 giây bắn ít nhất một lần.
	ctx, cancel := context.WithTimeout(context.Background(), 2500*time.Millisecond)
	defer cancel()
	if err := s.Run(ctx); err != nil {
		t.Fatal(err)
	}

	store.mu.Lock()
	defer store.mu.Unlock()
	if len(store.saved) != 2 {
		t.Fatalf("lưu %d kết quả, muốn 2", len(store.saved))
	}
	for _, c := range store.saved {
		if c.Status != checker.StatusUp {
			t.Errorf("monitor %d: %s", c.MonitorID, c.Status)
		}
	}
	if handler.calls != 2 {
		t.Errorf("handler được gọi %d lần, muốn 2", handler.calls)
	}
}
