// Package metrics khai báo các số đo Prometheus của pulsed.
package metrics

import (
	"github.com/prometheus/client_golang/prometheus"
	"github.com/prometheus/client_golang/prometheus/promauto"
)

// promauto tự đăng ký với registry mặc định; /metrics đọc từ đó.
var (
	HTTPRequests = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "pulse_http_requests_total",
		Help: "Số request HTTP, theo route và mã trả về.",
	}, []string{"route", "status"})

	HTTPDuration = promauto.NewHistogramVec(prometheus.HistogramOpts{
		Name:    "pulse_http_request_duration_seconds",
		Help:    "Thời gian xử lý request HTTP.",
		Buckets: []float64{.005, .01, .025, .05, .1, .25, .5, 1, 2.5},
	}, []string{"route"})

	Checks = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "pulse_checks_total",
		Help: "Số lần kiểm tra monitor, theo kết quả.",
	}, []string{"status"})

	CheckLatency = promauto.NewHistogram(prometheus.HistogramOpts{
		Name:    "pulse_check_latency_seconds",
		Help:    "Thời gian website được theo dõi phản hồi.",
		Buckets: []float64{.05, .1, .25, .5, 1, 2.5, 5, 10},
	})

	Notifications = promauto.NewCounterVec(prometheus.CounterOpts{
		Name: "pulse_notifications_total",
		Help: "Số thông báo đã gửi, theo kết quả.",
	}, []string{"result"})
)
