package api

import (
	"context"
	"crypto/rand"
	"encoding/hex"
	"log/slog"
	"net/http"
	"strconv"
	"time"

	"github.com/thachnguyenp/pulse/internal/metrics"
)

// statusRecorder nhớ lại mã HTTP mà handler đã ghi, để log được.
type statusRecorder struct {
	http.ResponseWriter
	status int
}

func (r *statusRecorder) WriteHeader(code int) {
	r.status = code
	r.ResponseWriter.WriteHeader(code)
}

type requestIDKey struct{}

// RequestID lấy id của request từ context, để handler ghi log kèm id.
func RequestID(ctx context.Context) string {
	id, _ := ctx.Value(requestIDKey{}).(string)
	return id
}

// requestID gắn cho mỗi request một id ngẫu nhiên, trả về trong header
// để khi khách báo lỗi, ta tìm đúng dòng log.
func requestID(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		id := r.Header.Get("X-Request-ID")
		if id == "" {
			b := make([]byte, 8)
			rand.Read(b)
			id = hex.EncodeToString(b)
		}
		w.Header().Set("X-Request-ID", id)
		next.ServeHTTP(w, r.WithContext(context.WithValue(r.Context(), requestIDKey{}, id)))
	})
}

// logging ghi một dòng log và cập nhật metrics cho mỗi request.
func logging(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		start := time.Now()
		rec := &statusRecorder{ResponseWriter: w, status: http.StatusOK}

		next.ServeHTTP(rec, r)

		elapsed := time.Since(start)
		// r.Pattern là mẫu route đã khớp ("GET /monitors/{id}"), không phải path thật,
		// nên số nhãn metric không phình theo số id.
		route := r.Pattern
		if route == "" {
			route = "unmatched"
		}
		metrics.HTTPRequests.WithLabelValues(route, strconv.Itoa(rec.status)).Inc()
		metrics.HTTPDuration.WithLabelValues(route).Observe(elapsed.Seconds())

		slog.Info("request",
			"request_id", RequestID(r.Context()),
			"method", r.Method,
			"path", r.URL.Path,
			"status", rec.status,
			"duration_ms", float64(elapsed.Microseconds())/1000,
		)
	})
}

// recoverPanic bắt panic trong handler, trả 500 thay vì làm sập cả server.
func recoverPanic(next http.Handler) http.Handler {
	return http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		defer func() {
			if err := recover(); err != nil {
				slog.Error("panic", "request_id", RequestID(r.Context()), "error", err, "path", r.URL.Path)
				writeError(w, http.StatusInternalServerError, "lỗi hệ thống")
			}
		}()
		next.ServeHTTP(w, r)
	})
}
