package api

import (
	"bytes"
	"context"
	"encoding/json"
	"net/http"
	"net/http/httptest"
	"sort"
	"sync"
	"testing"
	"time"

	"github.com/thachnguyenp/pulse/internal/auth"
	"github.com/thachnguyenp/pulse/internal/checker"
	"github.com/thachnguyenp/pulse/internal/monitor"
	"github.com/thachnguyenp/pulse/internal/user"
)

// ---- Store giả trong bộ nhớ: đủ cho handler chạy, không cần PostgreSQL ----

type fakeMonitors struct {
	mu     sync.Mutex
	nextID int64
	items  map[int64]monitor.Monitor
	checks map[int64][]monitor.Check
}

func newFakeMonitors() *fakeMonitors {
	return &fakeMonitors{nextID: 1, items: map[int64]monitor.Monitor{}, checks: map[int64][]monitor.Check{}}
}

func (f *fakeMonitors) Create(ctx context.Context, m *monitor.Monitor) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	m.ID = f.nextID
	f.nextID++
	m.Slug = monitor.NewSlug(m.Name)
	m.CreatedAt = time.Now()
	f.items[m.ID] = *m
	return nil
}

func (f *fakeMonitors) List(ctx context.Context, userID int64) ([]monitor.Monitor, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	list := []monitor.Monitor{}
	for _, m := range f.items {
		if m.UserID == userID {
			list = append(list, m)
		}
	}
	sort.Slice(list, func(i, j int) bool { return list[i].ID < list[j].ID })
	return list, nil
}

func (f *fakeMonitors) Get(ctx context.Context, userID, id int64) (monitor.Monitor, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	m, ok := f.items[id]
	if !ok || m.UserID != userID {
		return monitor.Monitor{}, monitor.ErrNotFound
	}
	return m, nil
}

func (f *fakeMonitors) Delete(ctx context.Context, userID, id int64) error {
	if _, err := f.Get(ctx, userID, id); err != nil {
		return err
	}
	f.mu.Lock()
	defer f.mu.Unlock()
	delete(f.items, id)
	return nil
}

func (f *fakeMonitors) SaveCheck(ctx context.Context, c *monitor.Check) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	f.checks[c.MonitorID] = append(f.checks[c.MonitorID], *c)
	return nil
}

func (f *fakeMonitors) ListChecks(ctx context.Context, id int64, limit int) ([]monitor.Check, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	return f.checks[id], nil
}

func (f *fakeMonitors) Stats(ctx context.Context, id int64, since time.Time) (monitor.Stats, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	st := monitor.Stats{TotalChecks: len(f.checks[id])}
	for _, c := range f.checks[id] {
		if c.Status == checker.StatusUp {
			st.UptimePercent += 100
		}
	}
	if st.TotalChecks > 0 {
		st.UptimePercent /= float64(st.TotalChecks)
	}
	return st, nil
}

func (f *fakeMonitors) ListIncidents(ctx context.Context, id int64, limit int) ([]monitor.Incident, error) {
	return []monitor.Incident{}, nil
}

func (f *fakeMonitors) GetBySlug(ctx context.Context, slug string) (monitor.Monitor, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	for _, m := range f.items {
		if m.Slug == slug {
			return m, nil
		}
	}
	return monitor.Monitor{}, monitor.ErrNotFound
}

func (f *fakeMonitors) DailyUptime(ctx context.Context, id int64, days int) ([]monitor.DayStat, error) {
	return make([]monitor.DayStat, days), nil
}

type fakeUsers struct {
	mu    sync.Mutex
	items map[string]user.User
}

func (f *fakeUsers) Create(ctx context.Context, u *user.User) error {
	f.mu.Lock()
	defer f.mu.Unlock()
	if _, ok := f.items[u.Email]; ok {
		return user.ErrEmailTaken
	}
	u.ID = int64(len(f.items) + 1)
	f.items[u.Email] = *u
	return nil
}

func (f *fakeUsers) GetByEmail(ctx context.Context, email string) (user.User, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	u, ok := f.items[email]
	if !ok {
		return user.User{}, user.ErrNotFound
	}
	return u, nil
}

func (f *fakeUsers) Get(ctx context.Context, id int64) (user.User, error) {
	f.mu.Lock()
	defer f.mu.Unlock()
	for _, u := range f.items {
		if u.ID == id {
			return u, nil
		}
	}
	return user.User{}, user.ErrNotFound
}

// ---- Bộ đồ nghề cho test ----

// newTestServer dựng Server với store giả, chạy trên httptest.Server.
func newTestServer(t *testing.T) *httptest.Server {
	t.Helper()
	s := New(Deps{
		Monitors: newFakeMonitors(),
		Users:    &fakeUsers{items: map[string]user.User{}},
		Checker:  checker.New(time.Second),
		Tokens:   auth.NewTokens("test-secret-test-secret-test-secret-12", time.Hour),
	})
	srv := httptest.NewServer(s.Handler())
	t.Cleanup(srv.Close)
	return srv
}

// do gửi một request JSON, trả về mã HTTP và body đã giải mã vào out (nếu khác nil).
func do(t *testing.T, method, url, token string, body any, out any) int {
	t.Helper()
	var buf bytes.Buffer
	if body != nil {
		json.NewEncoder(&buf).Encode(body)
	}
	req, _ := http.NewRequest(method, url, &buf)
	if token != "" {
		req.Header.Set("Authorization", "Bearer "+token)
	}
	resp, err := http.DefaultClient.Do(req)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if out != nil {
		json.NewDecoder(resp.Body).Decode(out)
	}
	return resp.StatusCode
}

// signup đăng ký + đăng nhập, trả về token.
func signup(t *testing.T, base, email string) string {
	t.Helper()
	creds := map[string]string{"email": email, "password": "matkhau123"}
	if code := do(t, "POST", base+"/auth/register", "", creds, nil); code != 201 {
		t.Fatalf("register: %d", code)
	}
	var res struct{ Token string }
	if code := do(t, "POST", base+"/auth/login", "", creds, &res); code != 200 {
		t.Fatalf("login: %d", code)
	}
	return res.Token
}

// ---- Test ----

func TestHealthz(t *testing.T) {
	srv := newTestServer(t)
	var body map[string]string
	if code := do(t, "GET", srv.URL+"/healthz", "", nil, &body); code != 200 || body["status"] != "ok" {
		t.Fatalf("healthz: %d %v", code, body)
	}
}

func TestAuth(t *testing.T) {
	srv := newTestServer(t)

	t.Run("đăng ký sai dữ liệu", func(t *testing.T) {
		var body map[string]any
		code := do(t, "POST", srv.URL+"/auth/register", "", map[string]string{"email": "x", "password": "1"}, &body)
		if code != 422 {
			t.Fatalf("muốn 422, nhận %d", code)
		}
		fields := body["fields"].(map[string]any)
		if fields["email"] == nil || fields["password"] == nil {
			t.Errorf("phải báo lỗi cả email lẫn password: %v", fields)
		}
	})

	t.Run("email trùng", func(t *testing.T) {
		creds := map[string]string{"email": "a@b.com", "password": "matkhau123"}
		do(t, "POST", srv.URL+"/auth/register", "", creds, nil)
		if code := do(t, "POST", srv.URL+"/auth/register", "", creds, nil); code != 409 {
			t.Errorf("muốn 409, nhận %d", code)
		}
	})

	t.Run("sai mật khẩu", func(t *testing.T) {
		creds := map[string]string{"email": "a@b.com", "password": "sai-roi"}
		if code := do(t, "POST", srv.URL+"/auth/login", "", creds, nil); code != 401 {
			t.Errorf("muốn 401, nhận %d", code)
		}
	})

	t.Run("chưa đăng nhập", func(t *testing.T) {
		if code := do(t, "GET", srv.URL+"/monitors", "", nil, nil); code != 401 {
			t.Errorf("muốn 401, nhận %d", code)
		}
		if code := do(t, "GET", srv.URL+"/monitors", "token-rac", nil, nil); code != 401 {
			t.Errorf("token rác muốn 401, nhận %d", code)
		}
	})
}

func TestMonitorsCRUD(t *testing.T) {
	srv := newTestServer(t)
	token := signup(t, srv.URL, "an@example.com")

	var created monitor.Monitor
	code := do(t, "POST", srv.URL+"/monitors", token,
		map[string]any{"name": "Shop", "url": "https://shop.vn", "interval_seconds": 30}, &created)
	if code != 201 || created.ID == 0 || created.Slug == "" {
		t.Fatalf("create: %d %+v", code, created)
	}

	var list []monitor.Monitor
	if code := do(t, "GET", srv.URL+"/monitors", token, nil, &list); code != 200 || len(list) != 1 {
		t.Fatalf("list: %d, %d phần tử", code, len(list))
	}

	code = do(t, "POST", srv.URL+"/monitors", token, map[string]any{"name": "", "url": "shop.vn"}, nil)
	if code != 422 {
		t.Errorf("dữ liệu sai muốn 422, nhận %d", code)
	}

	if code := do(t, "DELETE", srv.URL+"/monitors/1", token, nil, nil); code != 204 {
		t.Errorf("delete: %d", code)
	}
	if code := do(t, "GET", srv.URL+"/monitors/1", token, nil, nil); code != 404 {
		t.Errorf("sau khi xóa muốn 404, nhận %d", code)
	}
}

func TestMonitorsIsolation(t *testing.T) {
	srv := newTestServer(t)
	an := signup(t, srv.URL, "an@example.com")
	binh := signup(t, srv.URL, "binh@example.com")

	var m monitor.Monitor
	do(t, "POST", srv.URL+"/monitors", an, map[string]any{"name": "Của An", "url": "https://an.vn"}, &m)

	if code := do(t, "GET", srv.URL+"/monitors/1", binh, nil, nil); code != 404 {
		t.Errorf("Bình xem monitor của An phải 404, nhận %d", code)
	}
	if code := do(t, "DELETE", srv.URL+"/monitors/1", binh, nil, nil); code != 404 {
		t.Errorf("Bình xóa monitor của An phải 404, nhận %d", code)
	}
	var list []monitor.Monitor
	do(t, "GET", srv.URL+"/monitors", binh, nil, &list)
	if len(list) != 0 {
		t.Errorf("danh sách của Bình phải rỗng, có %d", len(list))
	}
}

func TestCheckNow(t *testing.T) {
	srv := newTestServer(t)
	token := signup(t, srv.URL, "an@example.com")

	// Một web giả để monitor trỏ tới.
	target := httptest.NewServer(http.HandlerFunc(func(w http.ResponseWriter, r *http.Request) {
		w.Write([]byte("ok"))
	}))
	defer target.Close()

	var m monitor.Monitor
	do(t, "POST", srv.URL+"/monitors", token, map[string]any{"name": "Target", "url": target.URL}, &m)

	var c monitor.Check
	if code := do(t, "POST", srv.URL+"/monitors/1/check", token, nil, &c); code != 200 {
		t.Fatalf("check: %d", code)
	}
	if c.Status != checker.StatusUp || c.StatusCode != 200 {
		t.Errorf("kết quả %+v", c)
	}

	var st monitor.Stats
	do(t, "GET", srv.URL+"/monitors/1/stats", token, nil, &st)
	if st.TotalChecks != 1 || st.UptimePercent != 100 {
		t.Errorf("stats %+v", st)
	}
}

func TestStatusPage(t *testing.T) {
	srv := newTestServer(t)
	token := signup(t, srv.URL, "an@example.com")
	var m monitor.Monitor
	do(t, "POST", srv.URL+"/monitors", token, map[string]any{"name": "Shop", "url": "https://shop.vn"}, &m)

	resp, err := http.Get(srv.URL + "/status/" + m.Slug)
	if err != nil {
		t.Fatal(err)
	}
	defer resp.Body.Close()
	if resp.StatusCode != 200 {
		t.Fatalf("status page: %d", resp.StatusCode)
	}
	var buf bytes.Buffer
	buf.ReadFrom(resp.Body)
	if !bytes.Contains(buf.Bytes(), []byte("Shop")) {
		t.Error("trang không có tên monitor")
	}

	if resp, _ := http.Get(srv.URL + "/status/khong-co"); resp.StatusCode != 404 {
		t.Errorf("slug lạ muốn 404, nhận %d", resp.StatusCode)
	}
}
