package store

import (
	"context"
	"os"
	"testing"
	"time"

	"github.com/thachnguyenp/pulse/internal/checker"
	"github.com/thachnguyenp/pulse/internal/monitor"
	"github.com/thachnguyenp/pulse/internal/user"
)

// testDB kết nối tới database test (TEST_DATABASE_URL), chạy migration và dọn sạch bảng.
// Không có biến môi trường thì bỏ qua test: máy nào cũng chạy được `go test ./...`.
func testDB(t *testing.T) *DB {
	t.Helper()
	url := os.Getenv("TEST_DATABASE_URL")
	if url == "" {
		t.Skip("đặt TEST_DATABASE_URL để chạy test với PostgreSQL thật")
	}
	ctx := context.Background()
	db, err := Connect(ctx, url)
	if err != nil {
		t.Fatal(err)
	}
	t.Cleanup(db.Close)
	if err := db.Migrate(ctx); err != nil {
		t.Fatal(err)
	}
	// Xóa sạch trước mỗi test để test không phụ thuộc nhau. CASCADE kéo theo checks, incidents.
	if _, err := db.pool.Exec(ctx, `TRUNCATE users, monitors RESTART IDENTITY CASCADE`); err != nil {
		t.Fatal(err)
	}
	return db
}

func newUser(t *testing.T, db *DB, email string) user.User {
	t.Helper()
	u := user.User{Email: email, PasswordHash: "x"}
	if err := NewUsers(db).Create(context.Background(), &u); err != nil {
		t.Fatal(err)
	}
	return u
}

func TestUsers(t *testing.T) {
	db := testDB(t)
	ctx := context.Background()
	users := NewUsers(db)

	u := newUser(t, db, "an@example.com")
	if u.ID == 0 || u.CreatedAt.IsZero() {
		t.Fatalf("thiếu id/created_at: %+v", u)
	}

	dup := user.User{Email: "an@example.com", PasswordHash: "y"}
	if err := users.Create(ctx, &dup); err != user.ErrEmailTaken {
		t.Errorf("email trùng muốn ErrEmailTaken, nhận %v", err)
	}

	got, err := users.GetByEmail(ctx, "an@example.com")
	if err != nil || got.ID != u.ID {
		t.Errorf("GetByEmail: %v %+v", err, got)
	}
	if _, err := users.Get(ctx, 999); err != user.ErrNotFound {
		t.Errorf("id lạ muốn ErrNotFound, nhận %v", err)
	}
}

func TestMonitorsCRUD(t *testing.T) {
	db := testDB(t)
	ctx := context.Background()
	monitors := NewMonitors(db)
	an := newUser(t, db, "an@example.com")
	binh := newUser(t, db, "binh@example.com")

	m := monitor.Monitor{UserID: an.ID, Name: "Shop", URL: "https://shop.vn", Interval: 60}
	if err := monitors.Create(ctx, &m); err != nil {
		t.Fatal(err)
	}
	if m.ID == 0 || m.Slug == "" || m.LastStatus != "pending" {
		t.Fatalf("sau Create: %+v", m)
	}

	if _, err := monitors.Get(ctx, binh.ID, m.ID); err != monitor.ErrNotFound {
		t.Errorf("Bình đọc monitor của An muốn ErrNotFound, nhận %v", err)
	}
	if got, err := monitors.GetBySlug(ctx, m.Slug); err != nil || got.ID != m.ID {
		t.Errorf("GetBySlug: %v", err)
	}

	list, _ := monitors.List(ctx, an.ID)
	if len(list) != 1 {
		t.Errorf("List của An: %d", len(list))
	}
	if err := monitors.Delete(ctx, an.ID, m.ID); err != nil {
		t.Errorf("Delete: %v", err)
	}
	if err := monitors.Delete(ctx, an.ID, m.ID); err != monitor.ErrNotFound {
		t.Errorf("xóa lần 2 muốn ErrNotFound, nhận %v", err)
	}
}

func TestClaimDueAndChecks(t *testing.T) {
	db := testDB(t)
	ctx := context.Background()
	monitors := NewMonitors(db)
	an := newUser(t, db, "an@example.com")

	m := monitor.Monitor{UserID: an.ID, Name: "Shop", URL: "https://shop.vn", Interval: 60}
	monitors.Create(ctx, &m)

	// Vừa tạo xong là tới giờ (next_check_at = now()).
	due, err := monitors.ClaimDue(ctx, 10)
	if err != nil || len(due) != 1 {
		t.Fatalf("ClaimDue lần 1: %v, %d monitor", err, len(due))
	}
	// Lấy xong thì lịch đã dời 60 giây: gọi lại phải rỗng.
	due, _ = monitors.ClaimDue(ctx, 10)
	if len(due) != 0 {
		t.Fatalf("ClaimDue lần 2 phải rỗng, nhận %d", len(due))
	}

	now := time.Now()
	for i, st := range []checker.Status{checker.StatusUp, checker.StatusUp, checker.StatusDown, checker.StatusUp} {
		c := monitor.Check{MonitorID: m.ID, Status: st, StatusCode: 200, LatencyMS: 100, CheckedAt: now.Add(time.Duration(i) * time.Second)}
		if err := monitors.SaveCheck(ctx, &c); err != nil {
			t.Fatal(err)
		}
	}

	got, _ := monitors.Get(ctx, an.ID, m.ID)
	if got.LastStatus != "up" {
		t.Errorf("last_status = %s, muốn up", got.LastStatus)
	}

	checks, _ := monitors.ListChecks(ctx, m.ID, 2)
	if len(checks) != 2 || !checks[0].CheckedAt.After(checks[1].CheckedAt) {
		t.Errorf("ListChecks phải mới nhất trước và tôn trọng limit: %+v", checks)
	}

	st, err := monitors.Stats(ctx, m.ID, now.Add(-time.Hour))
	if err != nil || st.TotalChecks != 4 || st.UptimePercent != 75 || st.AvgLatencyMS != 100 {
		t.Errorf("Stats: %v %+v", err, st)
	}

	days, _ := monitors.DailyUptime(ctx, m.ID, 7)
	if len(days) != 7 || days[6].Total != 4 {
		t.Errorf("DailyUptime: %d ngày, hôm nay %+v", len(days), days[len(days)-1])
	}
}

func TestIncidents(t *testing.T) {
	db := testDB(t)
	ctx := context.Background()
	monitors := NewMonitors(db)
	an := newUser(t, db, "an@example.com")
	m := monitor.Monitor{UserID: an.ID, Name: "Shop", URL: "https://shop.vn", Interval: 60}
	monitors.Create(ctx, &m)

	n, _ := monitors.RecordFailure(ctx, m.ID)
	n, _ = monitors.RecordFailure(ctx, m.ID)
	if n != 2 {
		t.Errorf("failures = %d, muốn 2", n)
	}

	inc, opened, err := monitors.OpenIncident(ctx, m.ID, "HTTP 503")
	if err != nil || !opened || inc.ID == 0 {
		t.Fatalf("OpenIncident: %v %v %+v", err, opened, inc)
	}
	if _, opened, _ := monitors.OpenIncident(ctx, m.ID, "HTTP 503"); opened {
		t.Error("đang có sự cố mở thì không mở thêm")
	}

	resolved, ok, _ := monitors.ResolveIncident(ctx, m.ID)
	if !ok || resolved.ResolvedAt == nil {
		t.Errorf("ResolveIncident: %v %+v", ok, resolved)
	}
	if _, ok, _ := monitors.ResolveIncident(ctx, m.ID); ok {
		t.Error("không còn sự cố mở thì không resolve được")
	}

	monitors.ResetFailures(ctx, m.ID)
	list, _ := monitors.ListIncidents(ctx, m.ID, 10)
	if len(list) != 1 {
		t.Errorf("ListIncidents: %d", len(list))
	}
}
