// Package incident quyết định khi nào một monitor được coi là "sập" và "hồi phục".
package incident

import (
	"context"
	"fmt"
	"log/slog"

	"github.com/thachnguyenp/pulse/internal/checker"
	"github.com/thachnguyenp/pulse/internal/metrics"
	"github.com/thachnguyenp/pulse/internal/monitor"
	"github.com/thachnguyenp/pulse/internal/notify"
)

// Store là những gì detector cần từ database.
type Store interface {
	// RecordFailure tăng số lần lỗi liên tiếp và trả về số mới.
	RecordFailure(ctx context.Context, monitorID int64) (int, error)
	// ResetFailures đưa số lần lỗi liên tiếp về 0.
	ResetFailures(ctx context.Context, monitorID int64) error
	// OpenIncident mở sự cố mới. Trả về ok=false nếu đã có sự cố đang mở.
	OpenIncident(ctx context.Context, monitorID int64, cause string) (monitor.Incident, bool, error)
	// ResolveIncident đóng sự cố đang mở. Trả về ok=false nếu không có sự cố nào.
	ResolveIncident(ctx context.Context, monitorID int64) (monitor.Incident, bool, error)
}

// Detector xem từng kết quả kiểm tra và quyết định có báo động không.
type Detector struct {
	store     Store
	notifier  notify.Notifier
	threshold int // số lần down liên tiếp mới coi là sự cố
}

func New(store Store, notifier notify.Notifier, threshold int) *Detector {
	return &Detector{store: store, notifier: notifier, threshold: threshold}
}

// Handle được scheduler gọi sau mỗi lần kiểm tra.
func (d *Detector) Handle(ctx context.Context, m monitor.Monitor, c monitor.Check) error {
	if c.Status == checker.StatusUp {
		return d.handleUp(ctx, m)
	}
	return d.handleDown(ctx, m, c)
}

func (d *Detector) handleDown(ctx context.Context, m monitor.Monitor, c monitor.Check) error {
	failures, err := d.store.RecordFailure(ctx, m.ID)
	if err != nil {
		return err
	}
	// Một lần lỗi lẻ có thể do mạng chập chờn. Đủ ngưỡng mới báo.
	if failures < d.threshold {
		return nil
	}
	inc, opened, err := d.store.OpenIncident(ctx, m.ID, c.Error)
	if err != nil || !opened {
		return err // đã có sự cố đang mở thì không báo lại
	}
	slog.Warn("monitor sập", "monitor", m.ID, "name", m.Name, "cause", c.Error)
	return d.notify(ctx, notify.Event{Kind: "down", Monitor: m, Incident: inc})
}

func (d *Detector) handleUp(ctx context.Context, m monitor.Monitor) error {
	if err := d.store.ResetFailures(ctx, m.ID); err != nil {
		return err
	}
	inc, resolved, err := d.store.ResolveIncident(ctx, m.ID)
	if err != nil || !resolved {
		return err // không có sự cố nào đang mở, up là chuyện bình thường
	}
	slog.Info("monitor hồi phục", "monitor", m.ID, "name", m.Name, "downtime", inc.Duration())
	return d.notify(ctx, notify.Event{Kind: "up", Monitor: m, Incident: inc})
}

func (d *Detector) notify(ctx context.Context, e notify.Event) error {
	if err := d.notifier.Notify(ctx, e); err != nil {
		metrics.Notifications.WithLabelValues("error").Inc()
		return fmt.Errorf("gửi thông báo: %w", err)
	}
	metrics.Notifications.WithLabelValues("ok").Inc()
	return nil
}
