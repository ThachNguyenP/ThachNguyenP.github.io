# Pulse

Giám sát website bằng Go: kiểm tra URL định kỳ, lưu lịch sử, báo Telegram/webhook khi sập, trang status công khai.
Dự án của series "Go cho người mới" tại thachnguyenp.github.io.

## Chạy local

```sh
cp .env.example .env        # sửa JWT_SECRET
docker compose up -d        # PostgreSQL + Redis
make run                    # http://localhost:3000
make fakeweb                # web giả để thử: http://localhost:8080
```

## Lệnh

```sh
make test       # test nhanh
make test-db    # test với PostgreSQL thật
make lint
make build      # bin/pulsed
make release    # bin/pulsed-linux-amd64, arm64
make docker     # image pulse:<version>
```

## Deploy

- **Docker**: `POSTGRES_PASSWORD=... VERSION=1.0.0 docker compose -f docker-compose.prod.yml up -d --build`
- **Binary + systemd**: copy `bin/pulsed-linux-amd64` và `.env` vào `/opt/pulse`, cài `deploy/pulsed.service`
- **HTTPS**: `deploy/Caddyfile`

## API

| Method | Path | Ghi chú |
|---|---|---|
| POST | /auth/register | `{email, password}` |
| POST | /auth/login | trả `{token}` |
| GET | /me | Bearer token |
| GET/POST | /monitors | |
| GET/DELETE | /monitors/{id} | |
| POST | /monitors/{id}/check | kiểm tra ngay |
| GET | /monitors/{id}/checks?limit=20 | |
| GET | /monitors/{id}/stats | 24 giờ, có cache |
| GET | /monitors/{id}/incidents | |
| GET | /status/{slug} | trang HTML công khai |
| GET | /healthz, /metrics | |
