# Bảng orders của riêng order service. Không còn bảng products ở đây.
module OrderStore
  SCHEMA = <<~SQL
    CREATE TABLE IF NOT EXISTS orders (
      id         INTEGER PRIMARY KEY,
      product_id INTEGER NOT NULL,
      qty        INTEGER NOT NULL,
      total      INTEGER NOT NULL,
      email      TEXT    NOT NULL,
      status     TEXT    NOT NULL,
      charge_id  TEXT
    );
  SQL

  class NotFound < StandardError; end

  def self.insert(db, order)
    db.execute(
      "INSERT INTO orders (product_id, qty, total, email, status, charge_id) VALUES (?, ?, ?, ?, ?, ?)",
      order.values_at("product_id", "qty", "total", "email", "status", "charge_id")
    )
    get(db, db.last_insert_row_id)
  end

  def self.get(db, id)
    db.get_first_row("SELECT * FROM orders WHERE id = ?", id) or raise NotFound, "không có đơn hàng"
  end
end
