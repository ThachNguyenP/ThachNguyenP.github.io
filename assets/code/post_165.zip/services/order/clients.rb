# Client HTTP tới catalog và payment. Order service chỉ biết URL của họ, không biết database của họ.
require "net/http"
require "json"

# Bọc mọi lỗi mà service bên kia trả về (4xx, 5xx).
class RemoteError < StandardError
  attr_reader :service, :status, :remote_message

  def initialize(service, status, remote_message)
    @service = service
    @status = status
    @remote_message = remote_message
    super("#{service} trả về #{status}: #{remote_message}")
  end

  # Lỗi do dữ liệu (4xx), không phải do mạng hay service sập.
  def client_error? = status < 500
end

module Remote
  # Gửi một request JSON, giải mã câu trả lời. Lỗi mạng (không kết nối được) sẽ raise lỗi của Net::HTTP.
  def self.call(service, method, url, body = nil)
    uri = URI(url)
    req = (method == :get ? Net::HTTP::Get : Net::HTTP::Post).new(uri)
    req["Content-Type"] = "application/json"
    req.body = JSON.generate(body) if body
    res = Net::HTTP.start(uri.host, uri.port) { |http| http.request(req) }
    data = JSON.parse(res.body) rescue {}
    raise RemoteError.new(service, res.code.to_i, data["error"] || res.message) if res.code.to_i >= 400

    data
  rescue SystemCallError, IOError, Net::OpenTimeout, Net::ReadTimeout => e
    raise "gọi #{service}: #{e.message}"
  end
end

class CatalogClient
  def initialize(url) = @url = url

  def get(id) = Remote.call("catalog", :get, "#{@url}/products/#{id}")
  def reserve(id, qty) = Remote.call("catalog", :post, "#{@url}/products/#{id}/reserve", { qty: qty })
  def release(id, qty) = Remote.call("catalog", :post, "#{@url}/products/#{id}/release", { qty: qty })
end

class PaymentClient
  def initialize(url) = @url = url

  def charge(card, amount) = Remote.call("payment", :post, "#{@url}/charges", { card: card, amount: amount })
end
