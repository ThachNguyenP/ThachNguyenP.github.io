# Payment service: cổng thanh toán giả. Chạy: ruby services/payment.rb
require "sinatra"
require_relative "../lib/web"
require_relative "../lib/payment"

Log.service = "payment"
set :server, :puma
set :port, ENV.fetch("PORT", 8083).to_i
set :logging, false
set :show_exceptions, :after_handler
use Web::RequestLog
helpers Web::Helpers

post "/charges" do
  input = read_json
  json_error 400, "cần card và amount > 0" if input["card"].to_s.empty? || input["amount"].to_i <= 0
  json_body 201, Payment.charge(input["card"], input["amount"].to_i)
end

error Payment::Declined do json_error 422, env["sinatra.error"].message end
