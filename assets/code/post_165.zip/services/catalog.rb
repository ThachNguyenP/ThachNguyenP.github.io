# Catalog service: sản phẩm và tồn kho. Database riêng (catalog.db), cổng riêng (8081).
# Chạy: ruby services/catalog.rb
require "sinatra"
require_relative "../lib/db"
require_relative "../lib/web"
require_relative "../lib/catalog"

Log.service = "catalog"
set :server, :puma
set :port, ENV.fetch("PORT", 8081).to_i
set :logging, false
set :show_exceptions, :after_handler
use Web::RequestLog
helpers Web::Helpers

DBH = DB.new(ENV.fetch("DB", "catalog.db"), Catalog::SCHEMA)
Catalog.seed(DBH)

get "/products" do
  json_body 200, Catalog.list(DBH)
end

get "/products/:id" do
  json_body 200, Catalog.get(DBH, params[:id])
end

# reserve và release là hai nửa của một "transaction" trải qua nhiều service.
# reserve trừ kho, release cộng lại (reserve với qty âm).
post "/products/:id/reserve" do
  qty = read_json["qty"].to_i
  json_error 400, "qty phải > 0" if qty <= 0
  Catalog.reserve(DBH, params[:id], qty)
  json_body 200, Catalog.get(DBH, params[:id])
end

post "/products/:id/release" do
  qty = read_json["qty"].to_i
  json_error 400, "qty phải > 0" if qty <= 0
  Catalog.reserve(DBH, params[:id], -qty)
  json_body 200, Catalog.get(DBH, params[:id])
end

error Catalog::NotFound do json_error 404, env["sinatra.error"].message end
error Catalog::OutOfStock do json_error 422, env["sinatra.error"].message end
