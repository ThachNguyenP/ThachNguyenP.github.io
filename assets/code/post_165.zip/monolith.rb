# Monolith: một process, một database, một cổng. Chạy: ruby monolith.rb
require "sinatra"
require_relative "lib/db"
require_relative "lib/web"
require_relative "lib/order"

Log.service = "monolith"
set :server, :puma
set :port, 8080
set :logging, false
set :show_exceptions, :after_handler # để các khối error bên dưới được chạy
use Web::RequestLog
helpers Web::Helpers

DBH = DB.new("shop.db", Catalog::SCHEMA + Order::SCHEMA)
Catalog.seed(DBH)
ORDERS = Order::Service.new(DBH)

get "/products" do
  json_body 200, Catalog.list(DBH)
end

post "/orders" do
  input = read_json
  order = ORDERS.create(product_id: input["product_id"], qty: input["qty"], email: input["email"], card: input["card"])
  json_body 201, order
end

get "/orders/:id" do
  json_body 200, ORDERS.get(params[:id])
end

get "/report" do
  json_body 200, ORDERS.report
end

error Order::Invalid do json_error 400, env["sinatra.error"].message end
error Catalog::NotFound, Order::NotFound do json_error 404, env["sinatra.error"].message end
error Catalog::OutOfStock, Payment::Declined do json_error 422, env["sinatra.error"].message end
