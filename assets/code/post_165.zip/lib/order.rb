# Order tạo đơn hàng: kiểm tra giá và tồn kho, thu tiền, lưu đơn. Tất cả trong MỘT transaction.
require_relative "catalog"
require_relative "payment"
require_relative "notify"

module Order
  SCHEMA = <<~SQL
    CREATE TABLE IF NOT EXISTS orders (
      id         INTEGER PRIMARY KEY,
      product_id INTEGER NOT NULL,
      qty        INTEGER NOT NULL,
      total      INTEGER NOT NULL,
      email      TEXT    NOT NULL,
      status     TEXT    NOT NULL,
      charge_id  TEXT
    );
  SQL

  class NotFound < StandardError; end
  class Invalid < StandardError; end

  class Service
    def initialize(db) = @db = db

    # Mọi bước nằm trong một transaction: bước nào lỗi thì rollback,
    # tồn kho tự quay về như cũ, không cần dọn dẹp gì.
    def create(product_id:, qty:, email:, card:)
      raise Invalid, "thiếu qty, email hoặc card" if qty.to_i <= 0 || email.to_s.empty? || card.to_s.empty?

      order = @db.transaction do
        product = Catalog.get(@db, product_id)
        Catalog.reserve(@db, product["id"], qty)
        total = product["price"] * qty
        charge = Payment.charge(card, total) # raise Declined -> rollback: tồn kho vừa trừ được trả lại
        @db.execute(
          "INSERT INTO orders (product_id, qty, total, email, status, charge_id) VALUES (?, ?, ?, ?, 'paid', ?)",
          [product["id"], qty, total, email, charge["id"]]
        )
        get(@db.last_insert_row_id)
      end
      Notify.order_paid(order)
      order
    end

    def get(id)
      @db.get_first_row("SELECT * FROM orders WHERE id = ?", id) or raise NotFound, "không có đơn hàng"
    end

    # Loại truy vấn monolith làm rất dễ: JOIN hai bảng của hai module.
    def report
      @db.execute(<<~SQL)
        SELECT p.name AS product, count(o.id) AS orders, coalesce(sum(o.total), 0) AS revenue
        FROM products p LEFT JOIN orders o ON o.product_id = p.id AND o.status = 'paid'
        GROUP BY p.id ORDER BY p.id
      SQL
    end
  end
end
