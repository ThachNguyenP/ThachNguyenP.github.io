# Notify "gửi email" bằng cách ghi log. Đủ cho demo.
module Notify
  def self.order_paid(order)
    Log.info("gửi email", to: order["email"], subject: "Đơn hàng đã thanh toán", order: order["id"], total: order["total"])
  end
end
