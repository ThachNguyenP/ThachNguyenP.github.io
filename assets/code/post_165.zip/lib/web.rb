# Vài thứ dùng chung cho mọi service: log dạng key=value, helper JSON cho Sinatra.
require "json"
require "logger"

module Log
  $stdout.sync = true
  LOGGER = Logger.new($stdout)
  LOGGER.formatter = ->(level, time, _prog, msg) { "time=#{time.strftime('%H:%M:%S.%L')} level=#{level} #{msg}\n" }

  def self.service=(name)
    @service = name
  end

  # Log.info("request", method: "GET", path: "/products") -> msg=request service=catalog method=GET path=/products
  %i[info warn error].each do |level|
    define_singleton_method(level) do |msg, **kv|
      fields = { msg: msg, service: @service }.merge(kv).map { |k, v| "#{k}=#{v.to_s =~ /[\s"]/ ? v.to_s.inspect : v}" }
      LOGGER.public_send(level, fields.join(" "))
    end
  end
end

module Web
  module Helpers
    def json_body(status, obj)
      content_type :json
      halt status, JSON.generate(obj)
    end

    def json_error(status, msg)
      json_body status, error: msg
    end

    # Đọc JSON từ body; sai định dạng thì trả 400 luôn.
    def read_json
      JSON.parse(request.body.read)
    rescue JSON::ParserError => e
      json_error 400, "JSON sai: #{e.message}"
    end
  end

  # Middleware ghi một dòng log cho mỗi request.
  class RequestLog
    def initialize(app) = @app = app

    def call(env)
      start = Process.clock_gettime(Process::CLOCK_MONOTONIC)
      status, headers, body = @app.call(env)
      ms = ((Process.clock_gettime(Process::CLOCK_MONOTONIC) - start) * 1000).round
      Log.info("request", method: env["REQUEST_METHOD"], path: env["PATH_INFO"], status: status, ms: ms)
      [status, headers, body]
    end
  end
end
