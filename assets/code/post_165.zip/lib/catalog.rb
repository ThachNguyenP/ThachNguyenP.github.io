# Catalog: sản phẩm và tồn kho.
module Catalog
  SCHEMA = <<~SQL
    CREATE TABLE IF NOT EXISTS products (
      id    INTEGER PRIMARY KEY,
      name  TEXT    NOT NULL,
      price INTEGER NOT NULL,
      stock INTEGER NOT NULL CHECK (stock >= 0)
    );
  SQL

  class NotFound < StandardError; end
  class OutOfStock < StandardError; end

  # Thêm vài sản phẩm mẫu nếu bảng đang trống.
  def self.seed(db)
    return if db.get_first_value("SELECT count(*) FROM products") > 0

    db.execute(<<~SQL)
      INSERT INTO products (name, price, stock) VALUES
        ('Bàn phím cơ', 1200000, 10), ('Chuột không dây', 450000, 5), ('Tai nghe', 2500000, 2)
    SQL
  end

  def self.list(db)
    db.execute("SELECT id, name, price, stock FROM products ORDER BY id")
  end

  def self.get(db, id)
    db.get_first_row("SELECT id, name, price, stock FROM products WHERE id = ?", id) or
      raise NotFound, "không có sản phẩm"
  end

  # Trừ tồn kho bằng MỘT câu UPDATE có điều kiện: hai người cùng mua món cuối thì chỉ một người được.
  def self.reserve(db, id, qty)
    db.execute("UPDATE products SET stock = stock - ? WHERE id = ? AND stock >= ?", [qty, id, qty])
    return if db.changes == 1

    get(db, id) # không có sản phẩm thì raise NotFound
    raise OutOfStock, "hết hàng"
  end
end
