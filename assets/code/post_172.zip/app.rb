# App web của shop: trang HTML cho người mua, một API JSON nhỏ, và /healthz cho hệ thống giám sát.
require "sinatra"
require "json"
require_relative "lib/shop"
require_relative "lib/login_guard"

set :server, :puma
set :server_settings, { Threads: "0:16" }   # mặc định 5 thread là quá ít khi client dùng keep-alive
set :port, ENV.fetch("PORT", 8080)
set :show_exceptions, :after_handler
set :erb, escape_html: true                 # mọi <%= %> đều được escape; chỗ nào cố ý in HTML thì dùng <%== %>
set :sessions, httponly: true, same_site: :lax, expire_after: 86_400
set :session_secret, ENV.fetch("SESSION_SECRET") { "dev-secret-" * 8 }
use Rack::Protection::AuthenticityToken     # mọi request không phải GET phải kèm token của form
use Rack::Protection::ContentSecurityPolicy, default_src: "'self'", style_src: "'self' 'unsafe-inline'"
use Rack::Protection::ReferrerPolicy

Shop.db = DB.new(ENV.fetch("DB", "shop.db"), Shop::SCHEMA)

helpers do
  def current_user
    @current_user ||= Shop::Users.get(session[:user_id]) if session[:user_id]
  end

  def require_login!
    redirect "/login?next=#{request.path}" unless current_user
  end

  def require_admin!
    require_login!
    halt 403, erb(:error, locals: { message: "Chỉ admin mới xem được trang này" }) unless current_user["role"] == "admin"
  end

  def money(n) = n.to_s.reverse.scan(/\d{1,3}/).join(".").reverse + " đ"

  def csrf_token = Rack::Protection::AuthenticityToken.token(session)

  # Chỉ nhận đường dẫn nội bộ: "/orders" được, "//example.org" (protocol-relative) hay "https://..." thì không.
  def safe_path(p) = p.to_s.start_with?("/") && !p.to_s.start_with?("//") ? p : "/"
end

# ---- Trang cho người mua ----
get "/" do
  @q = params[:q]
  @products = Shop::Products.list(@q)
  erb :index
end

get "/products/:id" do
  @product = Shop::Products.get(params[:id])
  erb :product
end

# ---- Đăng ký, đăng nhập ----
get("/register") { erb :register }
post "/register" do
  id = Shop::Users.create(email: params[:email], password: params[:password])
  session[:user_id] = id
  redirect "/"
end

get("/login") { erb :login, locals: { login_error: nil } }
post "/login" do
  email = params[:email].to_s
  halt 429, erb(:login, locals: { login_error: "Sai quá nhiều lần, thử lại sau 10 phút" }) if LoginGuard.blocked?(email)
  user = Shop::Users.authenticate(email, params[:password])
  unless user
    LoginGuard.fail!(email)
    halt 401, erb(:login, locals: { login_error: "Sai email hoặc mật khẩu" })
  end
  LoginGuard.clear(email)
  session[:user_id] = user["id"]
  redirect safe_path(params[:next])
end

post "/logout" do
  session.clear
  redirect "/"
end

# ---- Đơn hàng ----
post "/orders" do
  require_login!
  id = Shop::Orders.create(user_id: current_user["id"], product_id: params[:product_id], qty: params[:qty])
  redirect "/orders/#{id}"
end

get "/orders" do
  require_login!
  @page = [params[:page].to_i, 1].max
  @orders = Shop::Orders.for_user_with_items(current_user["id"], page: @page)
  erb :orders
end

get "/orders/:id" do
  require_login!
  @order = Shop::Orders.get_for_user(params[:id], current_user)   # đơn của người khác -> 404
  @items = Shop::Orders.items(@order["id"])
  erb :order
end

get "/admin/orders" do
  require_admin!
  @orders = Shop::Orders.all.map { |o| o.merge("user" => Shop::Users.get(o["user_id"])) }
  erb :admin_orders
end

# ---- API JSON và health check ----
get "/api/products" do
  content_type :json
  JSON.generate(Shop::Products.list(params[:q]))
end

get "/healthz" do
  content_type :json
  Shop.db.get_first_value("SELECT 1")
  JSON.generate(status: "ok", products: Shop.db.get_first_value("SELECT COUNT(*) FROM products"))
end

# ---- Lỗi ----
error Shop::NotFound do |e| halt 404, erb(:error, locals: { message: e.message }) end
error Shop::Invalid, Shop::OutOfStock do |e| halt 422, erb(:error, locals: { message: e.message }) end
not_found { erb :error, locals: { message: "Không có trang này" } }
