# Chặn đoán mật khẩu: sau LIMIT lần sai liên tiếp với một email, từ chối mọi lần đăng nhập email đó trong WINDOW giây.
# Đếm trong bộ nhớ của process: đủ cho một instance. Nhiều instance thì chuyển sang Redis (INCR + EXPIRE), logic y hệt.
module LoginGuard
  LIMIT = 5
  WINDOW = 600

  @fails = Hash.new { |h, k| h[k] = [] }
  @mutex = Mutex.new

  def self.blocked?(email) = recent(email).size >= LIMIT

  def self.fail!(email)
    @mutex.synchronize { @fails[email] << Time.now }
  end

  def self.clear(email)
    @mutex.synchronize { @fails.delete(email) }
  end

  def self.recent(email)
    @mutex.synchronize do
      @fails[email].select! { |t| t > Time.now - WINDOW }
      @fails[email].dup
    end
  end
end
