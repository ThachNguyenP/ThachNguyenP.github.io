# Unit test bảo mật (hộp trắng, chỉ cho bản Ruby): mật khẩu phải được băm, không lưu thô.
require_relative "../spec_helper"

RSpec.describe Shop::Users do
  it "lưu mật khẩu dưới dạng bcrypt, không lưu mật khẩu thô" do
    create_user(email: "an@example.com", password: "an-pass-123")
    digest = Shop.db.get_first_value("SELECT password_digest FROM users WHERE email = 'an@example.com'")
    expect(digest).to start_with("$2a$")
    expect(digest).not_to include("an-pass-123")
  end

  it "xác thực đúng và sai mật khẩu" do
    create_user(email: "an@example.com", password: "an-pass-123")
    expect(described_class.authenticate("an@example.com", "an-pass-123")).to include("email" => "an@example.com")
    expect(described_class.authenticate("an@example.com", "an-pass-124")).to be_nil
  end
end
