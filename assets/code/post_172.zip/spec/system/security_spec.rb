# Kiểm thử bảo mật cho CHÍNH app của mình, qua HTTP như mọi system test khác. Mỗi test là một yêu cầu
# mà bất kỳ bản cài đặt nào (Ruby, Go, NestJS) cũng phải đạt; test đỏ nghĩa là có việc phải sửa.
require_relative "system_helper"

RSpec.describe "Bảo mật" do
  describe "header phòng thủ" do
    before { client.get("/") }

    it "chặn đoán kiểu nội dung (nosniff)" do
      expect(client.last["x-content-type-options"]).to eq("nosniff")
    end

    it "không cho site khác nhúng vào iframe" do
      expect(client.last["x-frame-options"]).to match(/DENY|SAMEORIGIN/i)
    end

    it "có Content-Security-Policy" do
      expect(client.last["content-security-policy"]).to include("default-src")
    end

    it "không rò URL nội bộ qua Referer" do
      expect(client.last["referrer-policy"]).not_to be_nil
    end
  end

  describe "cookie phiên đăng nhập" do
    it "có HttpOnly và SameSite" do
      login("an@example.com", "an-pass-123")
      cookie = client.last.get_fields("set-cookie").join("; ")
      expect(cookie.downcase).to include("httponly")
      expect(cookie.downcase).to include("samesite=lax").or include("samesite=strict")
    end
  end

  describe "dữ liệu người dùng nhập vào" do
    it "được escape khi hiển thị lại (ô tìm kiếm)" do
      client.get("/?q=#{URI.encode_www_form_component('<b>abc</b>')}")
      expect(client.last.body).not_to include("<b>abc</b>")                     # không được in thô
      expect(client.last.body).to include("&lt;b&gt;abc&lt;/b&gt;") if client.last.body.include?("abc")
    end

    it "tham số next khi đăng nhập không đưa người dùng sang site khác" do
      login("an@example.com", "an-pass-123", next: "//example.org/")
      location = client.last["location"].to_s
      expect(location).not_to include("example.org")
    end

    it "không cho tự phong admin khi đăng ký" do
      client.get("/register")
      client.submit("/register", email: "t#{SecureRandom.hex(4)}@example.com", password: "mat-khau-moi", role: "admin")
      client.get("/admin/orders")
      expect(client.last.code).to eq("403")
    end
  end

  describe "phân quyền trên dữ liệu" do
    it "khách này không xem được đơn của khách khác" do
      register
      buy(3, 1)
      order_path = URI(client.last["location"]).path

      other = Client.new
      register(client: other)
      other.get(order_path)
      expect(other.last.code).to eq("404").or eq("403")
    end
  end

  describe "CSRF" do
    it "POST tạo đơn từ form không có token bị từ chối" do
      register
      client.post("/orders", product_id: 3, qty: 1)   # Client này không gửi token
      expect(client.last.code).to eq("403")
    end
  end

  describe "đoán mật khẩu" do
    it "sau nhiều lần sai liên tiếp thì bị chặn tạm thời (429)" do
      email = register
      codes = 8.times.map { |i| login(email, "sai-#{i}", client: Client.new).code }
      expect(codes).to include("429")
      expect(login(email, "mat-khau-moi", client: Client.new).code).to eq("429")   # đúng mật khẩu cũng phải chờ
    end
  end
end
