# Đăng ký, đăng nhập, phân quyền: qua HTTP thuần, chỉ nhìn status, header và nội dung trả về.
require_relative "system_helper"

RSpec.describe "Đăng nhập và phân quyền" do
  it "chưa đăng nhập thì /orders chuyển sang /login và nhớ trang muốn vào" do
    client.get("/orders")
    expect(client.last).to be_a(Net::HTTPRedirection)
    expect(client.last["location"]).to end_with("/login?next=/orders")
  end

  it "sai mật khẩu: 401, có thông báo, và vẫn chưa được coi là đã đăng nhập" do
    login("an@example.com", "sai-roi")
    expect(client.last.code).to eq("401")
    expect(client.last.body).to include("Sai email hoặc mật khẩu")
    client.get("/orders")
    expect(client.last).to be_a(Net::HTTPRedirection)   # không kiểm tra cookie: mỗi framework đặt cookie một kiểu
  end

  it "đăng ký rồi đăng nhập được, /orders mở ra" do
    email = register(password: "mat-khau-moi")
    other = Client.new
    login(email, "mat-khau-moi", client: other)
    expect(other.last).to be_a(Net::HTTPRedirection)
    other.get("/orders")
    expect(other.last.code).to eq("200")
    expect(other.last.body).to include("Chưa có đơn nào")
  end

  it "đăng ký trùng email bị từ chối" do
    email = register
    other = Client.new
    other.get("/register")
    other.submit("/register", email: email, password: "mat-khau-moi")
    expect(other.last.code).to eq("422")
  end

  it "khách thường không vào được trang admin" do
    register
    client.get("/admin/orders")
    expect(client.last.code).to eq("403")
  end

  it "admin vào được trang admin" do
    login("admin@example.com", "admin-pass-1")
    client.get("/admin/orders")
    expect(client.last.code).to eq("200")
    expect(client.last.body).to include("Tất cả đơn hàng")
  end

  it "đăng xuất xong thì /orders lại đòi đăng nhập" do
    register
    client.get("/")
    client.submit("/logout")
    client.get("/orders")
    expect(client.last).to be_a(Net::HTTPRedirection)
  end
end
