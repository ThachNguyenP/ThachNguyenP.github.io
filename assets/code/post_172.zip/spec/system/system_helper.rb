# Cấu hình cho SYSTEM test: không nạp code của app, chỉ biết một BASE_URL. Hệ thống phía sau URL đó viết bằng gì
# (Ruby, Go, NestJS...) không quan trọng. Chạy: BASE_URL=http://localhost:8080 bundle exec rspec spec/system
require "net/http"
require "json"
require "securerandom"

BASE_URL = ENV.fetch("BASE_URL", "http://localhost:8080")

# Client HTTP tối giản: giữ cookie giữa các request (để đăng nhập), không tự theo redirect (để test được redirect),
# nhớ CSRF token của form vừa GET để gửi kèm khi submit.
class Client
  attr_reader :last, :token

  def initialize(base = BASE_URL)
    @base = URI(base)
    @cookies = {}
  end

  def get(path, headers = {})  = request(Net::HTTP::Get.new(path, headers))

  def post(path, form = {}, headers = {})
    req = Net::HTTP::Post.new(path, headers)
    req.set_form_data(form)
    request(req)
  end

  # Gửi form như trình duyệt: kèm token lấy từ trang form đã GET trước đó (nếu trang có).
  def submit(path, form = {})
    post(path, token ? form.merge(authenticity_token: token) : form)
  end

  def json = JSON.parse(last.body)

  private

  def request(req)
    req["Cookie"] = @cookies.map { |k, v| "#{k}=#{v}" }.join("; ") unless @cookies.empty?
    @last = Net::HTTP.start(@base.host, @base.port, use_ssl: @base.scheme == "https") { |h| h.request(req) }
    @last.body&.force_encoding("UTF-8")
    @token = @last.body[/name="authenticity_token" value="([^"]+)"/, 1] if req.is_a?(Net::HTTP::Get) && @last.body
    @last.get_fields("set-cookie")&.each { |c| k, v = c.split(";").first.split("=", 2); @cookies[k] = v }
    @last
  end
end

module SystemHelpers
  def client = @client ||= Client.new

  # Mỗi test tự tạo user riêng (email ngẫu nhiên) để không dẫm lên dữ liệu của test khác và chạy lại bao nhiêu lần cũng được.
  def register(password: "mat-khau-moi", client: self.client)
    email = "t#{SecureRandom.hex(4)}@example.com"
    client.get("/register")
    client.submit("/register", email: email, password: password)
    expect(client.last).to be_a(Net::HTTPRedirection)
    email
  end

  def login(email, password, client: self.client, **extra)
    client.get("/login")
    client.submit("/login", { email: email, password: password }.merge(extra))
  end

  # Mua hàng như người dùng: mở trang sản phẩm (có form) rồi bấm Mua.
  def buy(product_id, qty, client: self.client)
    client.get("/products/#{product_id}")
    client.submit("/orders", product_id: product_id, qty: qty)
  end

  def product(id) = client.get("/api/products") && client.json.find { |p| p["id"] == id }
end

RSpec.configure do |c|
  c.include SystemHelpers
  c.before(:suite) do
    Net::HTTP.get_response(URI("#{BASE_URL}/healthz"))
  rescue StandardError => e
    abort "Không gọi được #{BASE_URL}/healthz (#{e.class}). Hãy bật hệ thống cần test trước."
  end
end
