export default function HomePage() {
  const now = new Date().toLocaleTimeString("vi-VN");

  return (
    <main className="container">
      <h1>Xin chào, Next.js!</h1>
      <p>Trang này được render lúc {now} trên server.</p>
    </main>
  );
}
