# Notify service: đọc sự kiện order.paid và "gửi email". Không có HTTP server, chỉ là một consumer.
# Chạy: ruby services/notify.rb
require_relative "../lib/db"
require_relative "../lib/web"
require_relative "../lib/events"

Log.service = "notify"
db = DB.new(ENV.fetch("DB", "notify.db"), Events::CONSUMER_SCHEMA)
feed = ENV.fetch("ORDER_URL", "http://localhost:8082") + "/events"

consumer = Events::Consumer.new(name: "notify", feed: feed, db: db) do |_db, ev|
  next unless ev["type"] == "order.paid"

  o = ev["payload"]
  Log.info("gửi email", to: o["email"], subject: "Đơn hàng đã thanh toán", order: o["id"], total: o["total"])
end

Log.info("notify chạy, đang đọc", feed: feed)
consumer.run
