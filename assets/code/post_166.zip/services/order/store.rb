# Bảng orders và bảng outbox của order service. Đơn hàng và sự kiện "order.paid" được ghi trong cùng một transaction.
require "json"

module OrderStore
  SCHEMA = <<~SQL
    CREATE TABLE IF NOT EXISTS orders (
      id         INTEGER PRIMARY KEY,
      product_id INTEGER NOT NULL,
      qty        INTEGER NOT NULL,
      total      INTEGER NOT NULL,
      email      TEXT    NOT NULL,
      status     TEXT    NOT NULL,
      charge_id  TEXT
    );
    CREATE TABLE IF NOT EXISTS outbox (
      id         INTEGER PRIMARY KEY,
      type       TEXT    NOT NULL,
      payload    TEXT    NOT NULL,
      created_at TEXT    NOT NULL DEFAULT (datetime('now'))
    );
  SQL

  class NotFound < StandardError; end

  # Lưu đơn hàng VÀ sự kiện vào outbox. Cùng một transaction nên không thể có
  # đơn mà không có sự kiện, hay có sự kiện mà không có đơn.
  def self.insert(db, order)
    db.transaction do
      db.execute(
        "INSERT INTO orders (product_id, qty, total, email, status, charge_id) VALUES (?, ?, ?, ?, ?, ?)",
        order.values_at("product_id", "qty", "total", "email", "status", "charge_id")
      )
      saved = get(db, db.last_insert_row_id)
      db.execute("INSERT INTO outbox (type, payload) VALUES ('order.paid', ?)", JSON.generate(saved))
      saved
    end
  end

  # Tối đa limit sự kiện có id > after, theo thứ tự id tăng dần.
  def self.events(db, after, limit)
    db.execute("SELECT id, type, payload FROM outbox WHERE id > ? ORDER BY id LIMIT ?", [after, limit])
      .map { |e| e.merge("payload" => JSON.parse(e["payload"])) }
  end

  def self.get(db, id)
    db.get_first_row("SELECT * FROM orders WHERE id = ?", id) or raise NotFound, "không có đơn hàng"
  end
end
