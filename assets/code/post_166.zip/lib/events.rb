# Events::Consumer đọc feed sự kiện theo kiểu "kéo" (poll), gọi handler cho mỗi sự kiện MỘT lần,
# và lưu tiến độ vào database của chính consumer.
require "net/http"
require "json"

module Events
  # Mỗi consumer nhớ mình đã đọc tới đâu (cursor) và đã xử lý sự kiện nào (done).
  CONSUMER_SCHEMA = <<~SQL
    CREATE TABLE IF NOT EXISTS events_cursor (name TEXT PRIMARY KEY, position INTEGER NOT NULL);
    CREATE TABLE IF NOT EXISTS events_done   (event_id INTEGER PRIMARY KEY);
  SQL

  class Consumer
    # feed: ví dụ http://localhost:8082/events. Block nhận (db, event) và được gọi trong transaction.
    def initialize(name:, feed:, db:, &handler)
      @name = name
      @feed = feed
      @db = db
      @handler = handler
    end

    # Lặp mãi: mỗi giây hỏi feed "có gì mới sau vị trí N không?".
    def run
      loop do
        n = poll
        sleep 1 if n.zero? # không có gì mới (hoặc lỗi): nghỉ một chút
      end
    end

    private

    def poll
      position = @db.get_first_value("SELECT position FROM events_cursor WHERE name = ?", @name) || 0
      res = Net::HTTP.get_response(URI("#{@feed}?after=#{position}&limit=100"))
      events = JSON.parse(res.body)
      events.each { |ev| handle_once(ev) }
      events.size
    rescue StandardError => e
      Log.warn("poll lỗi, thử lại sau", consumer: @name, err: e.message)
      0
    end

    # Đánh dấu done + xử lý + dời cursor trong MỘT transaction của DB consumer.
    # Sự kiện đã done (do chạy lại, do cursor bị reset) thì bỏ qua: đó là idempotency.
    def handle_once(ev)
      @db.transaction do
        @db.execute("INSERT OR IGNORE INTO events_done (event_id) VALUES (?)", ev["id"])
        if @db.changes == 1
          @handler.call(@db, ev)
        else
          Log.info("bỏ qua event đã xử lý", consumer: @name, event: ev["id"])
        end
        @db.execute(<<~SQL, [@name, ev["id"]])
          INSERT INTO events_cursor (name, position) VALUES (?, ?)
          ON CONFLICT (name) DO UPDATE SET position = excluded.position
        SQL
      end
    end
  end
end
