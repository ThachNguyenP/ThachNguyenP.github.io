// Package api là HTTP API của pulsed.
package api

import (
	"net/http"

	"github.com/thachnguyenp/pulse/internal/auth"
	"github.com/thachnguyenp/pulse/internal/cache"
	"github.com/thachnguyenp/pulse/internal/checker"
	"github.com/thachnguyenp/pulse/internal/monitor"
	"github.com/thachnguyenp/pulse/internal/ratelimit"
	"github.com/thachnguyenp/pulse/internal/user"
)

// Deps là mọi thứ handler cần. Cache và Limiter có thể nil (không dùng Redis).
type Deps struct {
	Monitors monitor.Store
	Users    user.Store
	Checker  *checker.Checker
	Tokens   *auth.Tokens
	Cache    *cache.Cache
	Limiter  *ratelimit.Limiter
}

// Server giữ các phụ thuộc, mỗi handler là một phương thức của nó.
type Server struct {
	monitors monitor.Store
	users    user.Store
	checker  *checker.Checker
	tokens   *auth.Tokens
	cache    *cache.Cache
	limiter  *ratelimit.Limiter
}

// New tạo Server với các phụ thuộc được truyền vào.
func New(d Deps) *Server {
	return &Server{
		monitors: d.Monitors, users: d.Users, checker: d.Checker,
		tokens: d.Tokens, cache: d.Cache, limiter: d.Limiter,
	}
}

// Handler trả về http.Handler với toàn bộ route và middleware.
func (s *Server) Handler() http.Handler {
	mux := http.NewServeMux()

	mux.HandleFunc("GET /healthz", s.healthz)
	mux.HandleFunc("POST /auth/register", s.rateLimit(s.register))
	mux.HandleFunc("POST /auth/login", s.rateLimit(s.login))

	// Các route dưới đây bắt buộc đăng nhập.
	protected := func(pattern string, h http.HandlerFunc) {
		mux.Handle(pattern, s.requireAuth(h))
	}
	protected("GET /me", s.me)
	protected("GET /monitors", s.listMonitors)
	protected("POST /monitors", s.createMonitor)
	protected("GET /monitors/{id}", s.getMonitor)
	protected("DELETE /monitors/{id}", s.deleteMonitor)
	protected("POST /monitors/{id}/check", s.checkMonitor)
	protected("GET /monitors/{id}/checks", s.listChecks)
	protected("GET /monitors/{id}/stats", s.monitorStats)
	protected("GET /monitors/{id}/incidents", s.listIncidents)

	return recoverPanic(logging(mux))
}

func (s *Server) healthz(w http.ResponseWriter, r *http.Request) {
	writeJSON(w, http.StatusOK, map[string]string{"status": "ok"})
}
