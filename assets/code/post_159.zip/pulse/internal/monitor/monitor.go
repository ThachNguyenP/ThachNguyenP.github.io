// Package monitor định nghĩa "monitor": một URL cần theo dõi định kỳ.
package monitor

import (
	"context"
	"errors"
	"net/url"
	"strings"
	"time"

	"github.com/thachnguyenp/pulse/internal/checker"
)

// ErrNotFound trả về khi không có monitor với id đó.
var ErrNotFound = errors.New("monitor not found")

// Monitor là một URL cần kiểm tra mỗi Interval giây.
type Monitor struct {
	ID          int64     `json:"id"`
	UserID      int64     `json:"-"`
	Name        string    `json:"name"`
	URL         string    `json:"url"`
	Interval    int       `json:"interval_seconds"`
	LastStatus  string    `json:"last_status"`
	NextCheckAt time.Time `json:"next_check_at"`
	CreatedAt   time.Time `json:"created_at"`
}

// Check là kết quả một lần kiểm tra, đã lưu vào database.
type Check struct {
	ID         int64          `json:"id"`
	MonitorID  int64          `json:"monitor_id"`
	Status     checker.Status `json:"status"`
	StatusCode int            `json:"status_code"`
	LatencyMS  int64          `json:"latency_ms"`
	Error      string         `json:"error,omitempty"`
	CheckedAt  time.Time      `json:"checked_at"`
}

// CheckFromResult chuyển kết quả của checker thành Check để lưu.
func CheckFromResult(monitorID int64, r checker.Result) Check {
	return Check{
		MonitorID:  monitorID,
		Status:     r.Status,
		StatusCode: r.StatusCode,
		LatencyMS:  r.LatencyMS,
		Error:      r.Error,
		CheckedAt:  r.CheckedAt,
	}
}

// Stats là số liệu tổng hợp của một monitor trong một khoảng thời gian.
type Stats struct {
	TotalChecks   int        `json:"total_checks"`
	UptimePercent float64    `json:"uptime_percent"`
	AvgLatencyMS  float64    `json:"avg_latency_ms"`
	LastCheckedAt *time.Time `json:"last_checked_at"`
}

// Validate kiểm tra dữ liệu người dùng gửi lên. Trả về map rỗng nếu hợp lệ.
func (m *Monitor) Validate() map[string]string {
	problems := map[string]string{}

	m.Name = strings.TrimSpace(m.Name)
	if m.Name == "" {
		problems["name"] = "không được để trống"
	} else if len(m.Name) > 100 {
		problems["name"] = "tối đa 100 ký tự"
	}

	m.URL = strings.TrimSpace(m.URL)
	u, err := url.ParseRequestURI(m.URL)
	if err != nil || (u.Scheme != "http" && u.Scheme != "https") || u.Host == "" {
		problems["url"] = "phải là URL đầy đủ, bắt đầu bằng http:// hoặc https://"
	}

	if m.Interval == 0 {
		m.Interval = 60
	}
	if m.Interval < 10 || m.Interval > 3600 {
		problems["interval_seconds"] = "từ 10 đến 3600 giây"
	}
	return problems
}

// Store là nơi lưu monitor và kết quả kiểm tra.
type Store interface {
	Create(ctx context.Context, m *Monitor) error
	List(ctx context.Context, userID int64) ([]Monitor, error)
	Get(ctx context.Context, userID, id int64) (Monitor, error)
	Delete(ctx context.Context, userID, id int64) error

	SaveCheck(ctx context.Context, c *Check) error
	ListChecks(ctx context.Context, monitorID int64, limit int) ([]Check, error)
	Stats(ctx context.Context, monitorID int64, since time.Time) (Stats, error)
	ListIncidents(ctx context.Context, monitorID int64, limit int) ([]Incident, error)
}
