// app/api/products/route.ts
import { NextRequest, NextResponse } from "next/server";
import { prisma } from "@/lib/db";

// GET /api/products?q=apple&page=1
export async function GET(request: NextRequest) {
  const { searchParams } = request.nextUrl;
  const q = searchParams.get("q") ?? "";
  const page = Math.max(1, Number(searchParams.get("page")) || 1);
  const perPage = 6;

  const where = q ? { OR: [{ name: { contains: q } }, { brand: { contains: q } }] } : {};
  const [products, total] = await Promise.all([
    prisma.product.findMany({ where, orderBy: { createdAt: "asc" }, skip: (page - 1) * perPage, take: perPage }),
    prisma.product.count({ where }),
  ]);

  return NextResponse.json(
    { data: products, page, totalPages: Math.ceil(total / perPage), total },
    { headers: { "Cache-Control": "public, s-maxage=60, stale-while-revalidate=300" } }
  );
}
