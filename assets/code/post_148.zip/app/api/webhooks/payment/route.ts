// app/api/webhooks/payment/route.ts
import { createHmac, timingSafeEqual } from "crypto";
import { NextResponse } from "next/server";
import { prisma } from "@/lib/db";

// Cổng thanh toán gọi vào đây khi khách trả tiền xong:
// POST /api/webhooks/payment  body: {"orderId": 1, "status": "paid"}  header: x-signature: <HMAC-SHA256 của body>
export async function POST(request: Request) {
  const rawBody = await request.text(); // phải đọc body dạng chuỗi THÔ để kiểm tra chữ ký
  const signature = request.headers.get("x-signature") ?? "";
  const expected = createHmac("sha256", process.env.PAYMENT_WEBHOOK_SECRET ?? "").update(rawBody).digest("hex");

  const valid =
    signature.length === expected.length && timingSafeEqual(Buffer.from(signature), Buffer.from(expected));
  if (!valid) {
    return NextResponse.json({ error: "Chữ ký không hợp lệ" }, { status: 401 });
  }

  const payload = JSON.parse(rawBody) as { orderId: number; status: string };
  if (payload.status !== "paid") return NextResponse.json({ ok: true, ignored: true });

  // Idempotent: cổng thanh toán có thể gọi lại nhiều lần, chỉ đơn đang "pending" mới được chuyển
  const result = await prisma.order.updateMany({
    where: { id: payload.orderId, status: "pending" },
    data: { status: "paid" },
  });

  return NextResponse.json({ ok: true, updated: result.count });
}
