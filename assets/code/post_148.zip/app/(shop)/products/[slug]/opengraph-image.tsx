import { ImageResponse } from "next/og";
import { formatPrice, getProduct } from "@/lib/products";

export const size = { width: 1200, height: 630 };
export const contentType = "image/png";

export default async function OpenGraphImage({ params }: { params: Promise<{ slug: string }> }) {
  const { slug } = await params;
  const product = await getProduct(slug);

  return new ImageResponse(
    (
      <div style={{ width: "100%", height: "100%", display: "flex", alignItems: "center", gap: 48, padding: 64, background: "#134e4a", color: "#fff", fontFamily: "sans-serif" }}>
        <div style={{ fontSize: 220 }}>{product?.emoji ?? "🛒"}</div>
        <div style={{ display: "flex", flexDirection: "column", gap: 16 }}>
          <div style={{ fontSize: 28, opacity: 0.8 }}>{`TechShop · ${product?.brand ?? ""}`}</div>
          <div style={{ fontSize: 64, fontWeight: 700, lineHeight: 1.1 }}>{product?.name ?? "Sản phẩm"}</div>
          <div style={{ fontSize: 48, color: "#fbbf24" }}>{product ? formatPrice(product.price) : ""}</div>
        </div>
      </div>
    ),
    size
  );
}
