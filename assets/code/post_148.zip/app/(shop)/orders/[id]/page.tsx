import Link from "next/link";
import { notFound } from "next/navigation";
import { prisma } from "@/lib/db";
import { getSession } from "@/lib/session";
import { formatPrice } from "@/lib/products";
import styles from "./page.module.css";

export default async function OrderPage({ params }: { params: Promise<{ id: string }> }) {
  const { id } = await params;
  const order = await prisma.order.findUnique({
    where: { id: Number(id) },
    include: { items: { include: { product: true } } },
  });

  if (!order) notFound();

  // Đơn của tài khoản nào thì chỉ tài khoản đó xem được (đơn khách vãng lai thì ai có link cũng xem được)
  if (order.userId) {
    const session = await getSession();
    if (session?.user.id !== order.userId) notFound();
  }

  return (
    <div className={styles.box}>
      <p className={styles.icon}>✅</p>
      <h1 className={styles.title}>Đặt hàng thành công</h1>
      <p className={styles.sub}>Mã đơn <strong>#{order.id}</strong> · Chúng tôi sẽ gọi {order.phone} để xác nhận.</p>

      <ul className={styles.items}>
        {order.items.map((item) => (
          <li key={item.id} className={styles.item}>
            <span>{item.product.emoji} {item.product.name} × {item.quantity}</span>
            <span>{formatPrice(item.price * item.quantity)}</span>
          </li>
        ))}
      </ul>
      <p className={styles.total}>Tổng cộng <strong>{formatPrice(order.total)}</strong></p>
      <p className={styles.address}>Giao tới: {order.address}</p>

      <Link href="/products" className={styles.link}>Tiếp tục mua sắm</Link>
    </div>
  );
}
