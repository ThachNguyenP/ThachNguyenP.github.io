import { updateProduct } from "@/app/actions/admin";
import { prisma } from "@/lib/db";
import { requireAdmin } from "@/lib/session";
import styles from "../admin.module.css";

export default async function AdminProductsPage() {
  await requireAdmin();

  const products = await prisma.product.findMany({ orderBy: { name: "asc" } });

  return (
    <>
      <h1 className={styles.title}>Sản phẩm ({products.length})</h1>
      <div className={styles.wrap}>
        <table className={styles.table}>
          <thead>
            <tr><th>Sản phẩm</th><th>Giá (đ)</th><th>Tồn kho</th><th></th></tr>
          </thead>
          <tbody>
            {products.map((product) => (
              <tr key={product.id}>
                <td>{product.emoji} {product.name}<br /><span className={styles.muted}>{product.brand} · /{product.slug}</span></td>
                <td colSpan={3}>
                  <form action={updateProduct} className={styles.inline}>
                    <input type="hidden" name="id" value={product.id} />
                    <input type="number" name="price" defaultValue={product.price} step={1000} min={1000} aria-label="Giá" />
                    <input type="number" name="stock" defaultValue={product.stock} min={0} aria-label="Tồn kho" />
                    <button type="submit">Lưu</button>
                  </form>
                </td>
              </tr>
            ))}
          </tbody>
        </table>
      </div>
    </>
  );
}
