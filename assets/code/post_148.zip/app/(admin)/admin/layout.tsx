import Link from "next/link";
import { requireAdmin } from "@/lib/session";
import styles from "./layout.module.css";

export default async function AdminLayout({ children }: { children: React.ReactNode }) {
  const session = await requireAdmin();

  return (
    <div className={styles.app}>
      <aside className={styles.sidebar}>
        <p className={styles.logo}>TechShop Admin</p>
        <nav className={styles.menu}>
          <Link href="/admin">Tổng quan</Link>
          <Link href="/admin/orders">Đơn hàng</Link>
          <Link href="/admin/products">Sản phẩm</Link>
          <Link href="/">← Về cửa hàng</Link>
        </nav>
        <p className={styles.user}>{session.user.name}</p>
      </aside>
      <main className={styles.content}>{children}</main>
    </div>
  );
}
