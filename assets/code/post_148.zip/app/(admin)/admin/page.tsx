import { prisma } from "@/lib/db";
import { formatPrice } from "@/lib/products";
import { requireAdmin } from "@/lib/session";
import styles from "./admin.module.css";

export default async function AdminHomePage() {
  await requireAdmin();

  const [orderCount, pendingCount, revenue, lowStock] = await Promise.all([
    prisma.order.count(),
    prisma.order.count({ where: { status: "pending" } }),
    prisma.order.aggregate({ _sum: { total: true }, where: { status: { not: "cancelled" } } }),
    prisma.product.count({ where: { stock: { lte: 2 } } }),
  ]);

  return (
    <>
      <h1 className={styles.title}>Tổng quan</h1>
      <div className={styles.stats}>
        <div className={styles.stat}><span>Tổng đơn</span><strong>{orderCount}</strong></div>
        <div className={styles.stat}><span>Chờ xác nhận</span><strong>{pendingCount}</strong></div>
        <div className={styles.stat}><span>Doanh thu</span><strong>{formatPrice(revenue._sum.total ?? 0)}</strong></div>
        <div className={styles.stat}><span>Sắp hết hàng</span><strong>{lowStock}</strong></div>
      </div>
    </>
  );
}
