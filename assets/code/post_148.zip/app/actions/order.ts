// app/actions/order.ts
"use server";

import { revalidatePath } from "next/cache";
import { redirect } from "next/navigation";
import { getCartItems, writeCart } from "@/lib/cart";
import { prisma } from "@/lib/db";
import { getSession } from "@/lib/session";
import { checkoutSchema } from "@/lib/validation";

export type CheckoutState = {
  errors?: Record<string, string>;
  message?: string;
  values?: Record<string, string>;
};

export async function placeOrder(prevState: CheckoutState, formData: FormData): Promise<CheckoutState> {
  const raw = Object.fromEntries(formData) as Record<string, string>;

  // 1. Validate dữ liệu form
  const parsed = checkoutSchema.safeParse(raw);
  if (!parsed.success) {
    const errors: Record<string, string> = {};
    for (const issue of parsed.error.issues) errors[String(issue.path[0])] = issue.message;
    return { errors, values: raw };
  }

  // 2. Lấy giỏ hàng từ cookie + giá thật từ database
  const items = await getCartItems();
  if (items.length === 0) return { message: "Giỏ hàng trống", values: raw };

  const session = await getSession();

  let orderId: number;
  try {
    // 3. Trừ kho và tạo đơn trong MỘT transaction: hoặc tất cả, hoặc không gì cả
    orderId = await prisma.$transaction(async (tx) => {
      for (const { product, quantity } of items) {
        const updated = await tx.product.updateMany({
          where: { id: product.id, stock: { gte: quantity } },
          data: { stock: { decrement: quantity } },
        });
        if (updated.count === 0) throw new Error(`"${product.name}" không đủ hàng`);
      }

      const order = await tx.order.create({
        data: {
          ...parsed.data,
          userId: session?.user.id,
          total: items.reduce((sum, i) => sum + i.product.price * i.quantity, 0),
          items: {
            create: items.map((i) => ({ productId: i.product.id, quantity: i.quantity, price: i.product.price })),
          },
        },
      });
      return order.id;
    });
  } catch (e) {
    return { message: e instanceof Error ? e.message : "Không đặt được hàng, thử lại", values: raw };
  }

  // 4. Dọn giỏ, làm mới cache các trang sản phẩm (tồn kho đã đổi), chuyển tới trang đơn
  await writeCart({});
  revalidatePath("/products");
  for (const { product } of items) revalidatePath(`/products/${product.slug}`);
  redirect(`/orders/${orderId}`);
}
