// lib/session.ts
import { headers } from "next/headers";
import { redirect } from "next/navigation";
import { auth } from "./auth";
import { prisma } from "./db";

// Đọc phiên đăng nhập ở Server Component / Server Action. Trả về null nếu chưa đăng nhập.
export async function getSession() {
  return auth.api.getSession({ headers: await headers() });
}

// Dùng ở mọi trang và action của khu admin: chưa đăng nhập -> /login, không phải admin -> trang chủ
export async function requireAdmin() {
  const session = await getSession();
  if (!session) redirect("/login");

  const user = await prisma.user.findUnique({ where: { id: session.user.id }, select: { role: true } });
  if (user?.role !== "admin") redirect("/");

  return session;
}
