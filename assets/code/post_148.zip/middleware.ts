// middleware.ts  (ở thư mục gốc, cạnh package.json)
import { NextRequest, NextResponse } from "next/server";

export function middleware(request: NextRequest) {
  // Chặn sớm khu admin khi không có cookie phiên. Kiểm tra quyền thật vẫn nằm ở requireAdmin()
  const hasSession = request.cookies.has("better-auth.session_token");
  if (!hasSession) {
    const loginUrl = new URL("/login", request.url);
    loginUrl.searchParams.set("next", request.nextUrl.pathname);
    return NextResponse.redirect(loginUrl);
  }

  const response = NextResponse.next();
  response.headers.set("X-Frame-Options", "DENY");
  return response;
}

export const config = {
  matcher: ["/admin/:path*", "/orders/:path*"],
};
