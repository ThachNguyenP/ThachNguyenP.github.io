"use client";

import { useRouter } from "next/navigation";
import { useState } from "react";
import { signIn, signUp } from "@/lib/auth-client";
import styles from "./auth-form.module.css";

export default function AuthForm({ mode }: { mode: "login" | "register" }) {
  const router = useRouter();
  const [error, setError] = useState("");
  const [pending, setPending] = useState(false);

  async function handleSubmit(e: React.FormEvent<HTMLFormElement>) {
    e.preventDefault();
    setError("");
    setPending(true);

    const form = new FormData(e.currentTarget);
    const email = String(form.get("email"));
    const password = String(form.get("password"));

    const result =
      mode === "register"
        ? await signUp.email({ email, password, name: String(form.get("name")) })
        : await signIn.email({ email, password });

    setPending(false);
    if (result.error) {
      setError(result.error.message ?? "Có lỗi xảy ra");
      return;
    }
    router.push("/orders");
    router.refresh();
  }

  return (
    <form onSubmit={handleSubmit} className={styles.form}>
      <h1 className={styles.title}>{mode === "register" ? "Tạo tài khoản" : "Đăng nhập"}</h1>
      {error && <p className={styles.alert}>{error}</p>}

      {mode === "register" && (
        <label className={styles.field}>
          Họ tên
          <input name="name" required minLength={2} />
        </label>
      )}
      <label className={styles.field}>
        Email
        <input name="email" type="email" required autoComplete="email" />
      </label>
      <label className={styles.field}>
        Mật khẩu
        <input name="password" type="password" required minLength={8} autoComplete={mode === "register" ? "new-password" : "current-password"} />
      </label>

      <button className={styles.submit} type="submit" disabled={pending}>
        {pending ? "Đang xử lý..." : mode === "register" ? "Đăng ký" : "Đăng nhập"}
      </button>

      <p className={styles.switch}>
        {mode === "register" ? (
          <>Đã có tài khoản? <a href="/login">Đăng nhập</a></>
        ) : (
          <>Chưa có tài khoản? <a href="/register">Đăng ký miễn phí</a></>
        )}
      </p>
    </form>
  );
}
