"use client";

import Link from "next/link";
import { useRouter } from "next/navigation";
import { signOut, useSession } from "@/lib/auth-client";
import styles from "./user-menu.module.css";

export default function UserMenu() {
  const { data: session, isPending } = useSession();
  const router = useRouter();

  if (isPending) return <span className={styles.placeholder} />;

  if (!session) {
    return <Link href="/login" className={styles.login}>Đăng nhập</Link>;
  }

  return (
    <span className={styles.user}>
      <Link href="/orders">{session.user.name}</Link>
      <button
        type="button"
        className={styles.logout}
        onClick={async () => {
          await signOut();
          router.push("/");
          router.refresh();
        }}
      >
        Thoát
      </button>
    </span>
  );
}
