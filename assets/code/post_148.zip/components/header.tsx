import Link from "next/link";
import NavLinks from "./nav-links";
import UserMenu from "./user-menu";
import styles from "./header.module.css";

export default function Header() {
  return (
    <header className={styles.header}>
      <div className={`container ${styles.inner}`}>
        <Link href="/" className={styles.logo}>TechShop</Link>
        <NavLinks />
        <UserMenu />
      </div>
    </header>
  );
}
