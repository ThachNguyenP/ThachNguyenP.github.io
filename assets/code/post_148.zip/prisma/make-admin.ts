// prisma/make-admin.ts  —  npx tsx prisma/make-admin.ts email@example.com
import { PrismaClient } from "@prisma/client";

const prisma = new PrismaClient();
const email = process.argv[2];

if (!email) {
  console.error("Cách dùng: npx tsx prisma/make-admin.ts email@example.com");
  process.exit(1);
}

prisma.user
  .update({ where: { email }, data: { role: "admin" } })
  .then((u) => console.log(`${u.email} giờ là admin`))
  .catch(() => console.error("Không tìm thấy tài khoản"))
  .finally(() => prisma.$disconnect());
