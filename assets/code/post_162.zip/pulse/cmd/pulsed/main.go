// pulsed: server của Pulse, cung cấp HTTP API.
package main

import (
	"context"
	"errors"
	"log/slog"
	"net/http"
	_ "net/http/pprof" // đăng ký /debug/pprof/* vào http.DefaultServeMux
	"os"
	"os/signal"
	"strings"
	"syscall"
	"time"

	"golang.org/x/sync/errgroup"

	"github.com/thachnguyenp/pulse/internal/api"
	"github.com/thachnguyenp/pulse/internal/auth"
	"github.com/thachnguyenp/pulse/internal/cache"
	"github.com/thachnguyenp/pulse/internal/checker"
	"github.com/thachnguyenp/pulse/internal/config"
	"github.com/thachnguyenp/pulse/internal/incident"
	"github.com/thachnguyenp/pulse/internal/notify"
	"github.com/thachnguyenp/pulse/internal/ratelimit"
	"github.com/thachnguyenp/pulse/internal/scheduler"
	"github.com/thachnguyenp/pulse/internal/store"
)

func main() {
	if err := run(); err != nil {
		slog.Error("server dừng vì lỗi", "error", err)
		os.Exit(1)
	}
}

func run() error {
	cfg, err := config.Load()
	if err != nil {
		return err
	}
	setupLogger(cfg)

	ctx, stop := signal.NotifyContext(context.Background(), os.Interrupt, syscall.SIGTERM)
	defer stop()

	db, err := store.Connect(ctx, cfg.DatabaseURL)
	if err != nil {
		return err
	}
	defer db.Close()

	if err := db.Migrate(ctx); err != nil {
		return err
	}
	slog.Info("database sẵn sàng")

	// Redis là tùy chọn: không có thì cache và rate limit tự tắt.
	var rc *cache.Cache
	if cfg.RedisURL != "" {
		if rc, err = cache.Connect(ctx, cfg.RedisURL); err != nil {
			return err
		}
		defer rc.Close()
		slog.Info("redis sẵn sàng")
	}

	chk := checker.New(cfg.CheckTimeout)
	monitors := store.NewMonitors(db)
	tokens := auth.NewTokens(cfg.JWTSecret, cfg.TokenTTL)
	server := api.New(api.Deps{
		Monitors: monitors,
		Users:    store.NewUsers(db),
		Checker:  chk,
		Tokens:   tokens,
		Cache:    rc,
		Limiter:  ratelimit.New(rc.Client(), 10, time.Minute),
	})
	detector := incident.New(monitors, buildNotifier(cfg), cfg.DownThreshold)
	sched := scheduler.New(monitors, chk, detector, cfg.Workers)

	srv := &http.Server{
		Addr:              cfg.Addr,
		Handler:           server.Handler(),
		ReadHeaderTimeout: 5 * time.Second,
	}

	// errgroup chạy nhiều việc song song; một việc lỗi thì ctx của cả nhóm bị hủy.
	g, ctx := errgroup.WithContext(ctx)

	g.Go(func() error {
		return sched.Run(ctx)
	})

	g.Go(func() error {
		slog.Info("pulsed đang chạy", "addr", cfg.Addr)
		if err := srv.ListenAndServe(); !errors.Is(err, http.ErrServerClosed) {
			return err
		}
		return nil
	})

	if cfg.DebugAddr != "" {
		// pprof trên cổng riêng, chỉ mở trong mạng nội bộ, không bao giờ public.
		g.Go(func() error {
			slog.Info("pprof đang chạy", "addr", cfg.DebugAddr)
			return http.ListenAndServe(cfg.DebugAddr, http.DefaultServeMux)
		})
	}

	g.Go(func() error {
		<-ctx.Done() // chờ Ctrl+C hoặc một việc khác lỗi
		slog.Info("đang tắt, chờ request dở dang...")
		shutdownCtx, cancel := context.WithTimeout(context.Background(), 10*time.Second)
		defer cancel()
		return srv.Shutdown(shutdownCtx)
	})

	err = g.Wait()
	slog.Info("đã tắt")
	return err
}

// buildNotifier ghép các kênh đã cấu hình. Không có kênh nào thì chỉ ghi log.
func buildNotifier(cfg config.Config) notify.Notifier {
	var channels notify.Multi
	if cfg.TelegramToken != "" && cfg.TelegramChat != "" {
		channels = append(channels, notify.NewTelegram(cfg.TelegramToken, cfg.TelegramChat))
	}
	if cfg.WebhookURL != "" {
		channels = append(channels, notify.NewWebhook(cfg.WebhookURL))
	}
	if len(channels) == 0 {
		slog.Warn("chưa cấu hình TELEGRAM_BOT_TOKEN/TELEGRAM_CHAT_ID hay WEBHOOK_URL, thông báo chỉ ghi log")
		return notify.Log{}
	}
	return notify.Retry{Notifier: channels, Attempts: 3, Base: time.Second}
}

// setupLogger chọn định dạng log: text dễ đọc khi dev, JSON cho máy đọc trên production.
func setupLogger(cfg config.Config) {
	var level slog.Level
	if err := level.UnmarshalText([]byte(strings.ToUpper(cfg.LogLevel))); err != nil {
		level = slog.LevelInfo
	}
	opts := &slog.HandlerOptions{Level: level}

	var handler slog.Handler = slog.NewTextHandler(os.Stdout, opts)
	if cfg.LogFormat == "json" {
		handler = slog.NewJSONHandler(os.Stdout, opts)
	}
	slog.SetDefault(slog.New(handler))
}
